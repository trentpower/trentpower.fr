/*! trentpower.fr · verification map · generated · signed via /integrity.json */
window.TP_VERIFICATION_MAP = {
  "/en-au/": {
    "path": "/en-au/",
    "title": "Client Strategy & Growth Systems · Trent Power",
    "canonical": "https://trentpower.fr/en-au/",
    "route": "/en-au/",
    "file_type": "HTML",
    "source": "/source/en-au/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-gE3x5raTHOVqRp9fxLZn9khR+sBmsmzkjAMLVdREIno=",
    "sha256": "sha256-gE3x5raTHOVqRp9fxLZn9khR+sBmsmzkjAMLVdREIno=",
    "size_bytes": 36038,
    "size_label": "35 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Client Strategy & Growth Systems · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "profile",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-yx3uP/81tuAC2RbcrkIdzR/rthFIjERs+eEwI1U/YEo=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/": {
    "path": "/fr/",
    "title": "Stratégie Client & Systèmes de Croissance · Trent Power",
    "canonical": "https://trentpower.fr/fr/",
    "route": "/fr/",
    "file_type": "HTML",
    "source": "/source/fr/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-wCDt6RjGgVozuiPviLow8gq3IcuFNm92DsUYNzzyf1k=",
    "sha256": "sha256-wCDt6RjGgVozuiPviLow8gq3IcuFNm92DsUYNzzyf1k=",
    "size_bytes": 37353,
    "size_label": "36 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Stratégie Client & Systèmes de Croissance · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "profile",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-mgrLnPOK1JKcvv7NuK4u3mjdIcQOzdmnYZv1WOE9Bdw=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-39CwVFGGNvbHLssZWmLjH693ge9HFoApIS64Ip3vGRs="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/privacy/": {
    "path": "/en-au/privacy/",
    "title": "Privacy & Trust · Trent Power",
    "canonical": "https://trentpower.fr/en-au/privacy/",
    "route": "/en-au/privacy/",
    "file_type": "HTML",
    "source": "/source/en-au/privacy/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fprivacy%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-4AfT7s+iqtNmhW5/0JuQ4WEDX/lnelhgWICXfP7WYMU=",
    "sha256": "sha256-4AfT7s+iqtNmhW5/0JuQ4WEDX/lnelhgWICXfP7WYMU=",
    "size_bytes": 15464,
    "size_label": "15 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/privacy/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Privacy & Trust · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/privacy/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "trust-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-I4bXDLgIYIlD+yFj0pWU4/bWa3x29U3/PpUaUObVn+g=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/confidentialite/": {
    "path": "/fr/confidentialite/",
    "title": "Confidentialité & confiance · Trent Power",
    "canonical": "https://trentpower.fr/fr/confidentialite/",
    "route": "/fr/confidentialite/",
    "file_type": "HTML",
    "source": "/source/fr/confidentialite/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fconfidentialite%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-k5oYOvfUQEosmnVSwH1IoPVP2ILctqKTM7LDIGACpEM=",
    "sha256": "sha256-k5oYOvfUQEosmnVSwH1IoPVP2ILctqKTM7LDIGACpEM=",
    "size_bytes": 16183,
    "size_label": "15 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/confidentialite/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Confidentialité & confiance · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/confidentialite/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "trust-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-p986RgT1o2psa6fuCAwULTb3A0umJK98KxNMw1P+doI=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-agxllRyYV2699KbyGGyEgS2g8qtDR3A5Pnvj46fWf3Y="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/security/": {
    "path": "/en-au/security/",
    "title": "Security & Threat Model · Trent Power",
    "canonical": "https://trentpower.fr/en-au/security/",
    "route": "/en-au/security/",
    "file_type": "HTML",
    "source": "/source/en-au/security/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fsecurity%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-jZ+xyY7SZChCYxaon1KbKpW/rDSLexYJHofsVNirkbU=",
    "sha256": "sha256-jZ+xyY7SZChCYxaon1KbKpW/rDSLexYJHofsVNirkbU=",
    "size_bytes": 25350,
    "size_label": "24 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/security/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Security & Threat Model · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/security/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "trust-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-dR5Xydnh4vtgHtcKPcH1z4DHU7Y/JkEC1QF1xQJ7X5s=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/securite/": {
    "path": "/fr/securite/",
    "title": "Sécurité & modèle de menace · Trent Power",
    "canonical": "https://trentpower.fr/fr/securite/",
    "route": "/fr/securite/",
    "file_type": "HTML",
    "source": "/source/fr/securite/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fsecurite%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-nj2mYUgCUBxeMkMyvrlWkCMGgVvytJHFeahCBD12QFU=",
    "sha256": "sha256-nj2mYUgCUBxeMkMyvrlWkCMGgVvytJHFeahCBD12QFU=",
    "size_bytes": 26813,
    "size_label": "26 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/securite/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Sécurité & modèle de menace · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/securite/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "trust-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-Dvl7n5ne+kVmn26LkiN88lBVR8VoGM7oWWL1CVH0Yss=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-VQogR/W2xsz3fKMSee9CQYd4tR3K22j1Of9DSbRgWjI="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/security/acknowledgments/": {
    "path": "/en-au/security/acknowledgments/",
    "title": "Security acknowledgements · Trent Power",
    "canonical": "https://trentpower.fr/en-au/security/acknowledgments/",
    "route": "/en-au/security/acknowledgments/",
    "file_type": "HTML",
    "source": "/source/en-au/security/acknowledgments/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fsecurity%2Facknowledgments%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-8Woc7E6i2j96/6sbe6fniP4sT2Bu6SAJMu6JEcexJBQ=",
    "sha256": "sha256-8Woc7E6i2j96/6sbe6fniP4sT2Bu6SAJMu6JEcexJBQ=",
    "size_bytes": 14568,
    "size_label": "14 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/security/acknowledgments/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Security acknowledgements · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/security/acknowledgments/",
    "release": "/integrity/releases/2026-05-23/",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-TMWVG3bz7u1E7iChHojSm0S4JpruSQstGcZqAq1PEzU=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/securite/remerciements/": {
    "path": "/fr/securite/remerciements/",
    "title": "Remerciements de sécurité · Trent Power",
    "canonical": "https://trentpower.fr/fr/securite/remerciements/",
    "route": "/fr/securite/remerciements/",
    "file_type": "HTML",
    "source": "/source/fr/securite/remerciements/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fsecurite%2Fremerciements%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-ALhwgZzKjPl5qpoRcSmMowLUKmzJOfFKFZBj0MkGzzM=",
    "sha256": "sha256-ALhwgZzKjPl5qpoRcSmMowLUKmzJOfFKFZBj0MkGzzM=",
    "size_bytes": 15029,
    "size_label": "14 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/securite/remerciements/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Remerciements de sécurité · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/securite/remerciements/",
    "release": "/integrity/releases/2026-05-23/",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-9CoxRG1U2B/uW8CUv9vxcoFOBiubMp017ICO8wU7K8g=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-W1VSgqTRYwy1wcpiSgrchoij6bGRSud/zqeM5SdmQiE="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/integrity/": {
    "path": "/en-au/integrity/",
    "title": "Integrity · Trent Power",
    "canonical": "https://trentpower.fr/en-au/integrity/",
    "route": "/en-au/integrity/",
    "file_type": "HTML",
    "source": "/source/en-au/integrity/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fintegrity%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-EMFfBUE2TdmN9vOiV1+wY3e0WVSZ60EyCoSPpGOzuWg=",
    "sha256": "sha256-EMFfBUE2TdmN9vOiV1+wY3e0WVSZ60EyCoSPpGOzuWg=",
    "size_bytes": 19389,
    "size_label": "18 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/integrity/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Integrity · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/integrity/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "trust-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-6AyUcgv+1uuTdurQuyN3IlJVjqxZIdega78qM/Dqsks=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/integrite/": {
    "path": "/fr/integrite/",
    "title": "Intégrité · Trent Power",
    "canonical": "https://trentpower.fr/fr/integrite/",
    "route": "/fr/integrite/",
    "file_type": "HTML",
    "source": "/source/fr/integrite/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fintegrite%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-O1lf0cKxVb7DBSJPdfVWFRQlGar8+EputEftHnDPwF4=",
    "sha256": "sha256-O1lf0cKxVb7DBSJPdfVWFRQlGar8+EputEftHnDPwF4=",
    "size_bytes": 19854,
    "size_label": "19 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/integrite/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Intégrité · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/integrite/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "trust-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-08E77GtO9xee5fd8rz0Vg6KMFAh0T8x+bDHp/nkJqOw=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-Yc/WPRP4+Tfzgj5NCEYkBZEpF9EwqZs78t4uPnS6MPI="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/integrity/releases/": {
    "path": "/en-au/integrity/releases/",
    "title": "Releases · Trent Power",
    "canonical": "https://trentpower.fr/en-au/integrity/releases/",
    "route": "/en-au/integrity/releases/",
    "file_type": "HTML",
    "source": "/source/en-au/integrity/releases/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fintegrity%2Freleases%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-ygnY0/6pAwZsAv8Ylop8oE0rzMPB7sJ9Yo0z4czOBlE=",
    "sha256": "sha256-ygnY0/6pAwZsAv8Ylop8oE0rzMPB7sJ9Yo0z4czOBlE=",
    "size_bytes": 19468,
    "size_label": "19 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/integrity/releases/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Releases · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/integrity/releases/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-ml+lC96UdSWILLPkqvN26arVwDrteMmQpMuvqg/qzDA=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/integrite/archives/": {
    "path": "/fr/integrite/archives/",
    "title": "Éditions · Trent Power",
    "canonical": "https://trentpower.fr/fr/integrite/archives/",
    "route": "/fr/integrite/archives/",
    "file_type": "HTML",
    "source": "/source/fr/integrite/archives/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fintegrite%2Farchives%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-8mAX+NOKC3IdHK/sUKP8jJm6Ae2FkveGUPwB0EOlSZY=",
    "sha256": "sha256-8mAX+NOKC3IdHK/sUKP8jJm6Ae2FkveGUPwB0EOlSZY=",
    "size_bytes": 20004,
    "size_label": "19 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/integrite/archives/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Éditions · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/integrite/archives/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-DCCBsK4xoNPTX5ar3UlvUjRgs1BNCWR6YUQNOlM1Y1Y=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-2uzCLS5X8qibT4oDe/cxm1cdiOguFpWnrcIu9pV3yfg="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/integrity/verify-locally/": {
    "path": "/en-au/integrity/verify-locally/",
    "title": "Verify locally · Trent Power",
    "canonical": "https://trentpower.fr/en-au/integrity/verify-locally/",
    "route": "/en-au/integrity/verify-locally/",
    "file_type": "HTML",
    "source": "/source/en-au/integrity/verify-locally/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fintegrity%2Fverify-locally%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-L8pRdF+KQNfyDMJ5JeU7D20jkKmZNd/1PsnPeik3Nx8=",
    "sha256": "sha256-L8pRdF+KQNfyDMJ5JeU7D20jkKmZNd/1PsnPeik3Nx8=",
    "size_bytes": 15445,
    "size_label": "15 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/integrity/verify-locally/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Verify locally · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/integrity/verify-locally/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-+C3+DQk8Afw3k/x4FI1zMyzMj3Na4MQRbF1v9eVfnAc=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/integrite/verifier-localement/": {
    "path": "/fr/integrite/verifier-localement/",
    "title": "Vérifier localement · Trent Power",
    "canonical": "https://trentpower.fr/fr/integrite/verifier-localement/",
    "route": "/fr/integrite/verifier-localement/",
    "file_type": "HTML",
    "source": "/source/fr/integrite/verifier-localement/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fintegrite%2Fverifier-localement%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-8/LqrgimayPs/ixn4B5LyNDDCaS7qwuYSv+N3hF0LCw=",
    "sha256": "sha256-8/LqrgimayPs/ixn4B5LyNDDCaS7qwuYSv+N3hF0LCw=",
    "size_bytes": 15929,
    "size_label": "15 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/integrite/verifier-localement/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Vérifier localement · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/integrite/verifier-localement/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-mQ98qUmK6hHZ4V+8SybOoS4jGYvBcxgzRMU1wP9BVgw=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-AVyuPisN7M7GboHyDqdOktoYUX6u+2EzEDSUXbU0JQA="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/verify/": {
    "path": "/en-au/verify/",
    "title": "Verify this page · Trent Power",
    "canonical": "https://trentpower.fr/en-au/verify/",
    "route": "/en-au/verify/",
    "file_type": "HTML",
    "source": "/source/en-au/verify/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fverify%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-vTAZ2c5eJwP0vZZWEACubzCyidLXpCZghx/0pPrsHq4=",
    "sha256": "sha256-vTAZ2c5eJwP0vZZWEACubzCyidLXpCZghx/0pPrsHq4=",
    "size_bytes": 15419,
    "size_label": "15 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/verify/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Verify this page · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/verify/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-YMWgMkwp9RSF6boyz1CXtvnQUbbWMEhEyoyLc+Afy6Q=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/verifier/": {
    "path": "/fr/verifier/",
    "title": "Vérifier cette page · Trent Power",
    "canonical": "https://trentpower.fr/fr/verifier/",
    "route": "/fr/verifier/",
    "file_type": "HTML",
    "source": "/source/fr/verifier/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fverifier%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-2F8q7BZddUeSo0l2CwLmb7+3xkfW3/IF0/J2vSJfEDU=",
    "sha256": "sha256-2F8q7BZddUeSo0l2CwLmb7+3xkfW3/IF0/J2vSJfEDU=",
    "size_bytes": 15793,
    "size_label": "15 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/verifier/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Vérifier cette page · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/verifier/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-cn6ihXSuWaEInax9RGhft7E3KDQzkH9Mn6CliR9ce1Y=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-vepdGvwJeFTwLmTSOMVoGmXFoej3pFYLM8aXPxbkgpA="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/source/": {
    "path": "/en-au/source/",
    "title": "Source mirrors · Trent Power",
    "canonical": "https://trentpower.fr/en-au/source/",
    "route": "/en-au/source/",
    "file_type": "HTML",
    "source": "/source/en-au/source/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fsource%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": null,
    "sha256": "sha256-4b7j6vE1ZfqG6Eh1O9YYnQu8/FSUlvl3lJMRt65TLPw=",
    "size_bytes": 49098,
    "size_label": "47 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/source/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Source mirrors · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/source/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-CdcKqKvsH/7pxncbULTWKwEjagv11Q1yqfu8imd4SlM=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/source/": {
    "path": "/fr/source/",
    "title": "Miroirs source · Trent Power",
    "canonical": "https://trentpower.fr/fr/source/",
    "route": "/fr/source/",
    "file_type": "HTML",
    "source": "/source/fr/source/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fsource%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": null,
    "sha256": "sha256-fP+d7nG7+MNOyFlR0k187kVKyzRnc30Sv+WwszEQxVo=",
    "size_bytes": 49426,
    "size_label": "48 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/source/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Miroirs source · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/source/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-Tp9y3r89CpUR+onZFFvVH4KiKRC7A2mWNk3CTtRYBu8=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-ISIP5zXXTNx9ZCCj/KDZhiuhCFxwVIWK8LFTKGqgoU8="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/source/view/": {
    "path": "/en-au/source/view/",
    "title": "Source mirrors · Trent Power",
    "canonical": "https://trentpower.fr/en-au/source/view/",
    "route": "/en-au/source/view/",
    "file_type": "HTML",
    "source": "/source/en-au/source/view/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fsource%2Fview%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": null,
    "sha256": "sha256-ArV1nr+GALYpvAJWPcX+7K6/L2VkkG+NWQTGUr/Jd5A=",
    "size_bytes": 11498,
    "size_label": "11 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/source/view/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Source mirrors · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/source/view/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-4A2qt2H+HiRkcEfhTYxRIjq4UMmhNOQ6MBzjqBqEo3s=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/source/voir/": {
    "path": "/fr/source/voir/",
    "title": "Miroirs source · Trent Power",
    "canonical": "https://trentpower.fr/fr/source/voir/",
    "route": "/fr/source/voir/",
    "file_type": "HTML",
    "source": "/source/fr/source/voir/index.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fsource%2Fvoir%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": null,
    "sha256": "sha256-BjZrJyGFUGQMligwBYfAgOy+sZCnhL+Okk9OgLBl+Ao=",
    "size_bytes": 11765,
    "size_label": "11 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/source/voir/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Miroirs source · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/source/voir/",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-xMLauTR8R/HpPFEvY2Vi7ojmpF7Cq1+G6asB8XwnsCc=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-ZAIelCLTuf5ETZZLwNnLXqz2M/Z/VcLXkGsdG1vdCxk="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/en-au/403.html": {
    "path": "/en-au/403.html",
    "title": "Forbidden · Trent Power",
    "canonical": "https://trentpower.fr/en-au/403.html",
    "route": "/en-au/403.html",
    "file_type": "HTML",
    "source": "/source/en-au/403.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2F403.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-xvhO92l1EFdVf/yhJX6ooIP8vFPDViPSvVBQ2iEPPr4=",
    "sha256": "sha256-xvhO92l1EFdVf/yhJX6ooIP8vFPDViPSvVBQ2iEPPr4=",
    "size_bytes": 13367,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/403.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Forbidden · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/403.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-r3AcgYOzwWt6bR23fzTU/nuOK44kn/Ty12b6UslFh94=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/en-au/404.html": {
    "path": "/en-au/404.html",
    "title": "Page not found · Trent Power",
    "canonical": "https://trentpower.fr/en-au/404.html",
    "route": "/en-au/404.html",
    "file_type": "HTML",
    "source": "/source/en-au/404.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2F404.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-/LUOSg0q+gedA4+neu3r+wzJGbC4OFu3E4Dhd2PLnLQ=",
    "sha256": "sha256-/LUOSg0q+gedA4+neu3r+wzJGbC4OFu3E4Dhd2PLnLQ=",
    "size_bytes": 13241,
    "size_label": "12 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/404.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Page not found · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/404.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-FiL+2ffE9vB57Vg382E1+yOvR0xVigLZ+/Q1bzjCXY0=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/en-au/500.html": {
    "path": "/en-au/500.html",
    "title": "Something went wrong · Trent Power",
    "canonical": "https://trentpower.fr/en-au/500.html",
    "route": "/en-au/500.html",
    "file_type": "HTML",
    "source": "/source/en-au/500.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2F500.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-p40W3gzSizjZZTDTpG5sGWSPH9SALkK6YcKOzoAiOKo=",
    "sha256": "sha256-p40W3gzSizjZZTDTpG5sGWSPH9SALkK6YcKOzoAiOKo=",
    "size_bytes": 13387,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/500.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Something went wrong · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/500.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-AhVQxq8NJcLB9OjjBc06x4xQc9ZHT3gs5m2TlZKZPD0=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/en-au/maintenance.html": {
    "path": "/en-au/maintenance.html",
    "title": "Down for maintenance · Trent Power",
    "canonical": "https://trentpower.fr/en-au/maintenance.html",
    "route": "/en-au/maintenance.html",
    "file_type": "HTML",
    "source": "/source/en-au/maintenance.html.txt",
    "reader": "/en-au/source/view/?path=%2Fen-au%2Fmaintenance.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-N6Wj7uh0ajlO6sy24/zh9GUX0aNz0kHGQRvUlo4V+j4=",
    "sha256": "sha256-N6Wj7uh0ajlO6sy24/zh9GUX0aNz0kHGQRvUlo4V+j4=",
    "size_bytes": 13751,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/en-au/maintenance.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Down for maintenance · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/en-au/maintenance.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-hfdG6M5H+xXbRDfQ9gXIJaB2neSAknQ9lzKWmxDYbuE=",
        "current": true
      }
    ],
    "first_archived": "2026-05-23",
    "change_status": "first"
  },
  "/fr/403.html": {
    "path": "/fr/403.html",
    "title": "Accès refusé · Trent Power",
    "canonical": "https://trentpower.fr/fr/403.html",
    "route": "/fr/403.html",
    "file_type": "HTML",
    "source": "/source/fr/403.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2F403.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-XLrASwFTgn+WrTVdChsJ26DrA0XEtHmxomIYudueoow=",
    "sha256": "sha256-XLrASwFTgn+WrTVdChsJ26DrA0XEtHmxomIYudueoow=",
    "size_bytes": 13769,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/403.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Accès refusé · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/403.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-9lFNFKt3LUmWMruA06FmOoHfRiL1UJgxguKGi9ILTpw=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-4gU4UBBQIz8Bsm79zMQgC8Lr1UE+dC2uZw0gVvE+2Gc="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/fr/404.html": {
    "path": "/fr/404.html",
    "title": "Page introuvable · Trent Power",
    "canonical": "https://trentpower.fr/fr/404.html",
    "route": "/fr/404.html",
    "file_type": "HTML",
    "source": "/source/fr/404.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2F404.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-NsasWSHRlEA4hD9FCqfXCM2l1DE5UfdSa6l4uQrqfPw=",
    "sha256": "sha256-NsasWSHRlEA4hD9FCqfXCM2l1DE5UfdSa6l4uQrqfPw=",
    "size_bytes": 13534,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/404.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Page introuvable · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/404.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-r468DElmeYDkuhYeBPyx3YjxJ4y04TgoZ6VzCzjvPlE=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-8O9Yo7bqtzcmwJkZbv7T90cqcNDvyzRQ1nIRGgks9yg="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/fr/500.html": {
    "path": "/fr/500.html",
    "title": "Une erreur est survenue · Trent Power",
    "canonical": "https://trentpower.fr/fr/500.html",
    "route": "/fr/500.html",
    "file_type": "HTML",
    "source": "/source/fr/500.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2F500.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-GkGGq6uKUZK1oy9HO5sFjmuxPW7WyUHBPcYJkfNX6oE=",
    "sha256": "sha256-GkGGq6uKUZK1oy9HO5sFjmuxPW7WyUHBPcYJkfNX6oE=",
    "size_bytes": 13777,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/500.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Une erreur est survenue · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/500.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-KF5sNuvXgmQTFvyNrIFnghaahnWjJ5aoQGO6obe/HXE=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-1EQsNqd+JnRTfwTDQ/EcxLc9jjLZTNZ4fLVrY0Oiw/I="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/fr/maintenance.html": {
    "path": "/fr/maintenance.html",
    "title": "En maintenance · Trent Power",
    "canonical": "https://trentpower.fr/fr/maintenance.html",
    "route": "/fr/maintenance.html",
    "file_type": "HTML",
    "source": "/source/fr/maintenance.html.txt",
    "reader": "/fr/source/voir/?path=%2Ffr%2Fmaintenance.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-9Yn39FUv+KmUvbJgHjTFIW1Vo6GaAM6U3reHImrOoS8=",
    "sha256": "sha256-9Yn39FUv+KmUvbJgHjTFIW1Vo6GaAM6U3reHImrOoS8=",
    "size_bytes": 14149,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/fr/maintenance.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. En maintenance · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/fr/maintenance.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-WeeNlSNNbiiwfNFcV7iJGZZnqpX9qoI+fuHrJDeO1Io=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-fMFXhY20gYUa7D3IUqpHgPV8BBzlOAu4OpJLD0IHK4A="
      }
    ],
    "first_archived": "2026-05-19",
    "change_status": "changed"
  },
  "/403.html": {
    "path": "/403.html",
    "title": "Forbidden · Trent Power",
    "canonical": "https://trentpower.fr/403.html",
    "route": "/403.html",
    "file_type": "HTML",
    "source": "/source/403.html.txt",
    "reader": "/en-au/source/view/?path=%2F403.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-xvhO92l1EFdVf/yhJX6ooIP8vFPDViPSvVBQ2iEPPr4=",
    "sha256": "sha256-xvhO92l1EFdVf/yhJX6ooIP8vFPDViPSvVBQ2iEPPr4=",
    "size_bytes": 13367,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/403.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Forbidden · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/403.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-r3AcgYOzwWt6bR23fzTU/nuOK44kn/Ty12b6UslFh94=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-8Twh75tWeVj1aBPqVHi8QBWG9s2k9RqUL+eOK/DxxlI="
      },
      {
        "edition_date": "2026-05-17",
        "release_path": "/integrity/releases/2026-05-17/",
        "sha256": "sha256-rl7TYLlftKgS92Urd5MkAvHO4XPL8oBDndWp9/n5/Y0="
      },
      {
        "edition_date": "2026-05-09",
        "release_path": "/integrity/releases/2026-05-09/",
        "sha256": "sha256-3QuRcRyewiRGZw2S08YS5URm88A6zV8poWUB0MhMJ/k="
      }
    ],
    "first_archived": "2026-05-09",
    "change_status": "changed"
  },
  "/404.html": {
    "path": "/404.html",
    "title": "Page not found · Trent Power",
    "canonical": "https://trentpower.fr/404.html",
    "route": "/404.html",
    "file_type": "HTML",
    "source": "/source/404.html.txt",
    "reader": "/en-au/source/view/?path=%2F404.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-/LUOSg0q+gedA4+neu3r+wzJGbC4OFu3E4Dhd2PLnLQ=",
    "sha256": "sha256-/LUOSg0q+gedA4+neu3r+wzJGbC4OFu3E4Dhd2PLnLQ=",
    "size_bytes": 13241,
    "size_label": "12 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/404.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Page not found · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/404.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-FiL+2ffE9vB57Vg382E1+yOvR0xVigLZ+/Q1bzjCXY0=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-xOb2PFqpiJQ+G9lTKb+pKKF9BXuNpLnwldo2gahb28k="
      },
      {
        "edition_date": "2026-05-17",
        "release_path": "/integrity/releases/2026-05-17/",
        "sha256": "sha256-WwyKs29zzUxeUg4yB0Spihcz/oUoLfCWKUCDA7ce4NA="
      },
      {
        "edition_date": "2026-05-09",
        "release_path": "/integrity/releases/2026-05-09/",
        "sha256": "sha256-t/zXPNEyBLjGn5md59MhwQqtAUHNZjYMpdcHTH47Y6I="
      }
    ],
    "first_archived": "2026-05-09",
    "change_status": "changed"
  },
  "/500.html": {
    "path": "/500.html",
    "title": "Something went wrong · Trent Power",
    "canonical": "https://trentpower.fr/500.html",
    "route": "/500.html",
    "file_type": "HTML",
    "source": "/source/500.html.txt",
    "reader": "/en-au/source/view/?path=%2F500.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-p40W3gzSizjZZTDTpG5sGWSPH9SALkK6YcKOzoAiOKo=",
    "sha256": "sha256-p40W3gzSizjZZTDTpG5sGWSPH9SALkK6YcKOzoAiOKo=",
    "size_bytes": 13387,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/500.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Something went wrong · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/500.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-AhVQxq8NJcLB9OjjBc06x4xQc9ZHT3gs5m2TlZKZPD0=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-ciEiN4eHdeN9KZ00eWKzOYK3mACIlLvcU6ewPcyrSk4="
      },
      {
        "edition_date": "2026-05-17",
        "release_path": "/integrity/releases/2026-05-17/",
        "sha256": "sha256-r2WJIsn0AO1seSevoiiSrnFnXEA2xHD89sk3Cd6nJ5s="
      },
      {
        "edition_date": "2026-05-09",
        "release_path": "/integrity/releases/2026-05-09/",
        "sha256": "sha256-EJDBuOVb0AXzhuxoy4QZqeK4r1uTC06kUUGtoKJHUlM="
      }
    ],
    "first_archived": "2026-05-09",
    "change_status": "changed"
  },
  "/maintenance.html": {
    "path": "/maintenance.html",
    "title": "Down for maintenance · Trent Power",
    "canonical": "https://trentpower.fr/maintenance.html",
    "route": "/maintenance.html",
    "file_type": "HTML",
    "source": "/source/maintenance.html.txt",
    "reader": "/en-au/source/view/?path=%2Fmaintenance.html",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-N6Wj7uh0ajlO6sy24/zh9GUX0aNz0kHGQRvUlo4V+j4=",
    "sha256": "sha256-N6Wj7uh0ajlO6sy24/zh9GUX0aNz0kHGQRvUlo4V+j4=",
    "size_bytes": 13751,
    "size_label": "13 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/maintenance.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Down for maintenance · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/maintenance.html",
    "print_type": "utility-sheet",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-hfdG6M5H+xXbRDfQ9gXIJaB2neSAknQ9lzKWmxDYbuE=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-uJfxpRy/7W0/3H7Rj7+f9ht8vpdUGDhnLJO4jQzzupg="
      },
      {
        "edition_date": "2026-05-17",
        "release_path": "/integrity/releases/2026-05-17/",
        "sha256": "sha256-w1x6/vxRXyO8r3GBNJlcDiJCUIVTE1RspRl2aDcx2k8="
      },
      {
        "edition_date": "2026-05-09",
        "release_path": "/integrity/releases/2026-05-09/",
        "sha256": "sha256-WMMCOt32qI4CtfR52Nfm6uWTMeEdsun++yOXv4b1fBw="
      }
    ],
    "first_archived": "2026-05-09",
    "change_status": "changed"
  },
  "/local/": {
    "path": "/local/",
    "title": "Local Device Console · Trent Power",
    "canonical": "https://trentpower.fr/local/",
    "route": "/local/",
    "file_type": "HTML",
    "source": "/source/local/index.html.txt",
    "reader": "/en-au/source/view/?path=%2Flocal%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-+6BfxUVukw4sqaWgMafymIQoCR/EAuN4Xs47R6PHj5Q=",
    "sha256": "sha256-+6BfxUVukw4sqaWgMafymIQoCR/EAuN4Xs47R6PHj5Q=",
    "size_bytes": 23951,
    "size_label": "23 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/local/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Local Device Console · Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr/local/",
    "print_type": "utility-sheet"
  },
  "/": {
    "path": "/",
    "title": "Choose a language. · Trent Power",
    "canonical": "https://trentpower.fr/",
    "route": "/",
    "file_type": "HTML",
    "source": "/source/index.html.txt",
    "reader": "/en-au/source/view/?path=%2F",
    "source_manifest": "/source/source-manifest.json",
    "source_sha256": "sha256-D009vr3xzHnJGFkFrY66aM7BZ2ccS64GUtAjxSSvflk=",
    "sha256": "sha256-D009vr3xzHnJGFkFrY66aM7BZ2ccS64GUtAjxSSvflk=",
    "size_bytes": 11348,
    "size_label": "11 KB",
    "manifest": "/integrity.json",
    "manifest_entry_path": "/index.html",
    "manifest_status": "found",
    "signature": "/integrity.json.sig",
    "public_key": "/.well-known/pgp-key.asc",
    "edition": "2026-05-23",
    "asset_version": "2026-05-23.e0e11a9f",
    "validated": "2026-05-28",
    "citation": "Trent Power. Personal Site. Edition 2026-05-23. trentpower.fr",
    "release": "/integrity/releases/2026-05-23/",
    "print_type": "profile",
    "history": [
      {
        "edition_date": "2026-05-23",
        "release_path": "/integrity/releases/2026-05-23/",
        "sha256": "sha256-w0TU3VbD3iKGaH+wKZwGxY0h6Bb/JfEQO3zH/se14ho=",
        "current": true
      },
      {
        "edition_date": "2026-05-19",
        "release_path": "/integrity/releases/2026-05-19/",
        "sha256": "sha256-Jy7O5erHWuZwfQR3tOpTVwoklHgzv6ADeNL06qPT1iw="
      },
      {
        "edition_date": "2026-05-17",
        "release_path": "/integrity/releases/2026-05-17/",
        "sha256": "sha256-byDiaPv3GeJ0K2S22rJY03cftglMh7dwzXmN8U/YZjc="
      },
      {
        "edition_date": "2026-05-09",
        "release_path": "/integrity/releases/2026-05-09/",
        "sha256": "sha256-7dnEDXhlnsYTgOZpAhQqakbtmuIwETOkIL1wyH69D2w="
      },
      {
        "edition_date": "2026-02",
        "release_path": "/integrity/releases/2026-02/",
        "sha256": "sha256-Phzxpr/O71TN+IJa0oTtDnb0KkloGGSoHzOrOWv1IZk="
      }
    ],
    "first_archived": "2026-02",
    "change_status": "changed"
  }
};
