/*
 * language-gate.js — root language vestibule, local preference only.
 *
 * The vestibule at / is a deliberate language-choice page shown on
 * every visit. It NEVER redirects. The page is server-rendered visible
 * and works with no JavaScript: the two choices are ordinary
 * <a href="/en/"> / <a href="/fr/"> links, and the display language is
 * fixed pre-paint by the inline head script (html[data-preferred-lang]).
 *
 * This script is pure progressive enhancement:
 *   · remembers the chosen edition in localStorage["tp-lang"] on click,
 *     so the next visit's vestibule opens in that language — the choice
 *     itself is never bypassed;
 *   · traps focus within the modal;
 *   · moves focus to the first choice on load.
 *
 * localStorage is used only to improve presentation. No redirect, no
 * cookies, no network request, no analytics, no dependencies. Fails
 * silently if storage is unavailable.
 */
(function () {
  "use strict";

  var overlay = document.getElementById("lang-gate");
  if (!overlay) return;

  var choices = overlay.querySelectorAll("a[data-lang-choice]");

  // Remember the chosen edition, then let the link navigate normally.
  Array.prototype.forEach.call(choices, function (link) {
    link.addEventListener("click", function () {
      var lang = link.getAttribute("data-lang-choice");
      if (lang === "en" || lang === "fr") {
        try { localStorage.setItem("tp-lang", lang); } catch (_) {}
      }
    });
  });

  // Focus trap — the vestibule resolves via a choice, so Escape is not
  // bound (there is nothing to dismiss to).
  var focusable = overlay.querySelectorAll(
    "a[href], button, [tabindex]:not([tabindex='-1'])"
  );
  if (!focusable.length) return;
  var first = focusable[0];
  var last = focusable[focusable.length - 1];

  overlay.addEventListener("keydown", function (event) {
    if (event.key !== "Tab") return;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  // Move focus into the modal once the document is interactive.
  window.requestAnimationFrame(function () {
    try { first.focus({ preventScroll: true }); } catch (_) { first.focus(); }
  });
})();
