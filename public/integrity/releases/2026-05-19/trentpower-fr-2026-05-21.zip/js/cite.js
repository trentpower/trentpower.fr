/*! trentpower.fr · /js/cite.js · generated · signed via /integrity.json */
(function () {
'use strict';
var EDITION = '2026-05-19';
var LABELS = {
en: {
'cite.site_label': 'Personal Site',
'cite.edition_label': 'Edition',
'cite.overlay.action.print_home': 'Print profile',
'cite.overlay.action.print_page': 'Print page',
'cite.overlay.action.close': 'Close',
'cite.overlay.kicker': 'This page',
'cite.overlay.lede': 'Canonical publication record.',
'cite.overlay.action.verify': 'Verify this page',
'cite.overlay.action.open_source': 'View source',
'cite.overlay.action.copy_citation': 'Copy citation',
'cite.overlay.footer_signed': 'Edition {edition} · Signed SHA256',
'cite.overlay.toast.citation_copied': 'Citation copied'
},
fr: {
'cite.site_label': 'Site personnel',
'cite.edition_label': 'Édition',
'cite.overlay.action.print_home': 'Imprimer le profil',
'cite.overlay.action.print_page': 'Imprimer la page',
'cite.overlay.action.close': 'Fermer',
'cite.overlay.kicker': 'Cette page',
'cite.overlay.lede': 'Notice de publication canonique.',
'cite.overlay.action.verify': 'Vérifier cette page',
'cite.overlay.action.open_source': 'Voir le code source',
'cite.overlay.action.copy_citation': 'Copier la citation',
'cite.overlay.footer_signed': 'Édition {edition} · SHA256 signé',
'cite.overlay.toast.citation_copied': 'Citation copiée'
}
};
function getLang() {
return document.documentElement.lang === 'fr' ? 'fr' : 'en';
}
function tt(key, fallback) {
var bag = LABELS[getLang()] || LABELS.en;
var v = bag[key];
return (typeof v === 'string') ? v : (fallback || '');
}
function normalisePath(raw) {
if (!raw) return '/';
raw = String(raw).trim();
if (!raw) return '/';
if (raw.charAt(0) !== '/') raw = '/' + raw;
raw = raw.replace(/\/index\.html$/, '/');
if (raw.indexOf('.') === -1 && raw.charAt(raw.length - 1) !== '/') raw += '/';
return raw;
}
function currentRecord() {
var map = (typeof window !== 'undefined' && window.TP_VERIFICATION_MAP) || {};
var p = normalisePath(location.pathname || '/');
return map[p] || null;
}
function pageTitle() {
var raw = document.title || '';
if (raw.indexOf('|') !== -1) {
return raw.replace(/^[^|]+\|\s*/, '').trim().replace(/\s*&\s*/g, ' and ');
}
return raw.replace(/\s*[—\-]\s*Trent Power$/, '').trim();
}
function canonicalUrl() {
var link = document.querySelector('link[rel="canonical"]');
return link ? link.href : location.href;
}
function fallbackCitation() {
return 'Trent Power. "' + pageTitle() + '." ' +
tt('cite.site_label', 'Personal Site') +
'. Paris, France. ' +
tt('cite.edition_label', 'Edition') + ' ' + EDITION + '. ' +
canonicalUrl();
}
function verifyUrl() {
var p = normalisePath(location.pathname || '/');
var base = getLang() === 'fr' ? '/fr/verifier/' : '/en/verify/';
return base + '?path=' + encodeURIComponent(p);
}
function printLabel() {
var explicit = document.body && document.body.dataset && document.body.dataset.printLabel;
if (explicit) return explicit;
var page = (document.body && document.body.dataset && document.body.dataset.page)
|| (document.documentElement.dataset && document.documentElement.dataset.page)
|| '';
if (page === 'home') return tt('cite.overlay.action.print_home', 'Print profile');
return tt('cite.overlay.action.print_page', 'Print page');
}
function el(tag, attrs, text) {
var n = document.createElement(tag);
if (attrs) for (var k in attrs) {
if (Object.prototype.hasOwnProperty.call(attrs, k) && attrs[k] != null) {
n.setAttribute(k, attrs[k]);
}
}
if (text != null) n.textContent = text;
return n;
}
function safeHref(href) {
if (!href) return '#';
if (href.charAt(0) === '/' || /^https?:\/\//.test(href)) return href;
return '#';
}
var overlay = null;
var copyBtnAction = {};
function resolveTitle(rec) {
var explicit = document.body && document.body.dataset && document.body.dataset.citationTitle;
if (explicit) return explicit;
var page = (document.body && document.body.dataset && document.body.dataset.page) || '';
if (page) {
var key = 'cite.overlay.page_title.' + page;
var translated = tt(key, '');
if (translated) return translated;
}
return (rec && rec.title) || pageTitle() || tt('cite.site_label', 'Personal Site');
}
function buildOverlay() {
var rec = currentRecord();
var citation = (rec && rec.citation) || fallbackCitation();
var title = resolveTitle(rec);
overlay = el('div', {
'class': 'modal-overlay cite-overlay',
'id': 'cite-dialog',
'role': 'dialog',
'aria-modal': 'true',
'aria-labelledby': 'cite-modal-title',
'aria-hidden': 'true',
});
var card = el('div', { 'class': 'modal cite-modal' });
var closeX = el('button', {
type: 'button',
'class': 'cite-modal-close-x',
'data-cite-action': 'close',
'aria-label': tt('cite.overlay.action.close', 'Close'),
}, '\u00d7');
card.appendChild(closeX);
var header = el('header', { 'class': 'cite-modal-header' });
header.appendChild(el('p', { 'class': 'cite-modal-kicker' },
tt('cite.overlay.kicker', 'This page')));
header.appendChild(el('h2', { 'class': 'cite-modal-title', 'id': 'cite-modal-title' },
title));
header.appendChild(el('p', { 'class': 'cite-modal-lede' },
tt('cite.overlay.lede', 'Canonical publication record for this page.')));
card.appendChild(header);
var actions = el('div', { 'class': 'cite-modal-actions' });
var primary = el('div', { 'class': 'cite-modal-actions-row cite-modal-actions-row--primary' });
primary.appendChild(el('a', {
'href': safeHref(verifyUrl()),
'class': 'cite-modal-action cite-modal-action--primary',
'data-cite-action': 'verify',
}, tt('cite.overlay.action.verify', 'Verify this page')));
var sourceHref = (rec && rec.reader) || (rec && rec.source) || '/source/';
primary.appendChild(el('a', {
'href': safeHref(sourceHref),
'class': 'cite-modal-action cite-modal-action--primary',
'data-cite-action': 'open-source',
}, tt('cite.overlay.action.open_source', 'View source')));
actions.appendChild(primary);
var secondary = el('div', { 'class': 'cite-modal-actions-row cite-modal-actions-row--secondary' });
var copyBtn = el('button', {
type: 'button',
'class': 'cite-modal-action cite-modal-action--secondary',
'data-copy-text': citation,
'data-copy-feedback': tt('cite.overlay.toast.citation_copied', 'Citation copied'),
'data-copy-announce': 'cite-copy-status',
}, tt('cite.overlay.action.copy_citation', 'Copy citation'));
secondary.appendChild(copyBtn);
var printBtn = el('button', {
type: 'button',
'class': 'cite-modal-action cite-modal-action--secondary',
'data-cite-action': 'print',
}, printLabel());
secondary.appendChild(printBtn);
copyBtnAction['print'] = printBtn;
actions.appendChild(secondary);
card.appendChild(actions);
var modalFooter = el('p', { 'class': 'cite-modal-footer-line' });
var footerStamp = tt('cite.overlay.footer_signed',
'Edition ' + EDITION + ' · Signed SHA256')
.replace('{edition}', EDITION);
modalFooter.appendChild(document.createTextNode(footerStamp));
card.appendChild(modalFooter);
var liveStatus = el('output', {
'class': 'visually-hidden',
'aria-live': 'polite',
'id': 'cite-copy-status',
});
card.appendChild(liveStatus);
overlay.appendChild(card);
document.body.appendChild(overlay);
overlay.addEventListener('click', function (e) {
if (e.target === overlay) {
if (window.TP_OVERLAY && window.TP_OVERLAY.close) window.TP_OVERLAY.close();
}
});
card.addEventListener('click', handleActionClick);
}
function handleActionClick(e) {
var t = e.target && e.target.closest
? e.target.closest('[data-cite-action]')
: null;
if (!t) return;
var action = t.dataset.citeAction;
if (action === 'close') {
if (window.TP_OVERLAY && window.TP_OVERLAY.close) window.TP_OVERLAY.close();
return;
}
if (action === 'print') {
window.print();
if (window.TP_OVERLAY && window.TP_OVERLAY.close) window.TP_OVERLAY.close();
return;
}
}
function openCite(e, opener) {
if (!opener && e && e.currentTarget) opener = e.currentTarget;
if (!window.TP_OVERLAY || !window.TP_OVERLAY.open) {
if (e && typeof e.preventDefault === 'function') e.preventDefault();
try { console.warn('cite overlay unavailable, falling back to /verify/'); }
catch (_) {}
window.location.href = '/verify/';
return;
}
if (e && typeof e.preventDefault === 'function') e.preventDefault();
if (!overlay) buildOverlay();
window.TP_OVERLAY.open(overlay, opener || null, { hash: '#cite' });
}
function init() {
var triggers = document.querySelectorAll('[data-cite-open]');
if (!triggers.length) return;
Array.prototype.forEach.call(triggers, function (trigger) {
trigger.addEventListener('click', function (e) { openCite(e, trigger); });
});
if (window.location.hash === '#cite') {
setTimeout(function () { openCite(null, triggers[0]); }, 0);
}
window.addEventListener('popstate', function () {
var st = history.state;
if (window.location.hash === '#cite' && st && st.tp_overlay === 'cite' &&
!document.querySelector('.modal-overlay.active')) {
if (!overlay) buildOverlay();
if (window.TP_OVERLAY && window.TP_OVERLAY.open) {
window.TP_OVERLAY.open(overlay, triggers[0], { hash: '#cite', fromPopstate: true });
}
}
});
}
function _scheduleInit() {
if ('requestIdleCallback' in window) {
window.requestIdleCallback(init, { timeout: 1500 });
} else {
window.setTimeout(init, 500);
}
}
if (document.readyState === 'loading') {
document.addEventListener('DOMContentLoaded', _scheduleInit);
} else {
_scheduleInit();
}
})();
