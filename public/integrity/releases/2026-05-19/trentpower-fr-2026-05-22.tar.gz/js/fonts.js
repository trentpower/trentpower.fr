/*! trentpower.fr · /js/fonts.js · generated · loaded after first paint · signed via /integrity.json */
(function () {
'use strict';
if (document.querySelector('link[data-tp-fonts-full]')) return;
var link = document.createElement('link');
link.rel = 'stylesheet';
link.href = '/fonts-full.2026-05-19.3d11de66.css';
link.setAttribute('data-tp-fonts-full', '');
function paintFlip() {
if (typeof requestAnimationFrame === 'function') {
requestAnimationFrame(function () {
document.documentElement.classList.add('fonts-loaded');
});
} else {
document.documentElement.classList.add('fonts-loaded');
}
}
link.addEventListener('load', function () {
if (document.fonts && document.fonts.ready && typeof document.fonts.ready.then === 'function') {
document.fonts.ready.then(paintFlip);
} else {
setTimeout(paintFlip, 1500);
}
});
document.head.appendChild(link);
})();
