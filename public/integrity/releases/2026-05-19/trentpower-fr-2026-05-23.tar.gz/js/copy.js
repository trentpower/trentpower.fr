/*! trentpower.fr · /js/copy.js · generated · signed via /integrity.json */
(function () {
'use strict';
var REVERT_MS = 1500;
function lang() {
return document.documentElement.lang === 'fr' ? 'fr' : 'en';
}
function copiedLabel() {
return lang() === 'fr' ? 'Copié' : 'Copied';
}
function execCommandCopy(text) {
return new Promise(function (resolve, reject) {
try {
var ta = document.createElement('textarea');
ta.value = text;
ta.setAttribute('readonly', '');
ta.style.position = 'fixed';
ta.style.top = '-1000px';
ta.style.opacity = '0';
document.body.appendChild(ta);
ta.select();
var ok = document.execCommand && document.execCommand('copy');
document.body.removeChild(ta);
if (ok) resolve(); else reject();
} catch (_) { reject(); }
});
}
function writeClipboard(text) {
if (navigator.clipboard && navigator.clipboard.writeText) {
return navigator.clipboard.writeText(text).catch(function () {
return execCommandCopy(text);
});
}
return execCommandCopy(text);
}
function payloadFor(trigger) {
if (trigger.hasAttribute('data-copy-text')) {
return trigger.getAttribute('data-copy-text') || '';
}
var targetId = trigger.getAttribute('data-copy-target');
var target = targetId ? document.getElementById(targetId) : null;
var raw = target ? (target.textContent || '') : '';
if (trigger.getAttribute('data-copy-collapse') === 'whitespace') {
return raw.replace(/\s+/g, ' ').trim();
}
return raw.replace(/\s+$/, '');
}
function feedback(trigger) {
if (trigger.getAttribute('data-state') === 'copied') return;
var done = trigger.getAttribute('data-copy-feedback') || copiedLabel();
var resting = trigger.textContent;
trigger.textContent = done;
trigger.setAttribute('data-state', 'copied');
var announceId = trigger.getAttribute('data-copy-announce');
var region = announceId ? document.getElementById(announceId) : null;
if (region) {
region.textContent = '';
setTimeout(function () { region.textContent = done; }, 0);
}
setTimeout(function () {
trigger.textContent = resting;
trigger.removeAttribute('data-state');
if (region) region.textContent = '';
}, REVERT_MS);
}
document.addEventListener('click', function (e) {
var trigger = e.target && e.target.closest
? e.target.closest('[data-copy-target], [data-copy-text]')
: null;
if (!trigger) return;
var payload = payloadFor(trigger);
if (!payload) return;
e.preventDefault();
writeClipboard(payload).then(
function () { feedback(trigger); },
function () { }
);
});
window.TP_COPY = {
copy: function (text) { return writeClipboard(String(text == null ? '' : text)); }
};
})();
