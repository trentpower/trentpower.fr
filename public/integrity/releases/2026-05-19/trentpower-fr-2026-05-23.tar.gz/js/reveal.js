/*! trentpower.fr · /js/reveal.js · generated · signed via /integrity.json */
(function () {
'use strict';
var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function _reveal() {
var revealGroups = ['.principle', '.trajectory-item', '.project-card'];
var allRevealEls = document.querySelectorAll(revealGroups.join(', '));
if (!prefersReducedMotion && 'IntersectionObserver' in window) {
var observer = new IntersectionObserver(function (entries) {
entries.forEach(function (entry) {
if (entry.isIntersecting) {
entry.target.classList.add('visible');
observer.unobserve(entry.target);
}
});
}, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
revealGroups.forEach(function (sel) {
document.querySelectorAll(sel).forEach(function (el, i) {
el.style.transitionDelay = (i * 80) + 'ms';
observer.observe(el);
});
});
} else {
allRevealEls.forEach(function (el) {
el.classList.add('visible');
});
}
}
if ('requestIdleCallback' in window) {
requestIdleCallback(_reveal, { timeout: 2000 });
} else {
setTimeout(_reveal, 200);
}
})();
