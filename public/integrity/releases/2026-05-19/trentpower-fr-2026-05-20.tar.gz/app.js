/*! trentpower.fr · /app.js · generated · signed via /integrity.json */
(function () {
'use strict';
try { document.documentElement.classList.add('js'); } catch (_) {}
function _markEnhanced() {
try { document.documentElement.classList.add('enhanced'); } catch (_) {}
}
if (document.readyState === 'loading') {
document.addEventListener('DOMContentLoaded', _markEnhanced, { once: true });
} else {
_markEnhanced();
}
function _safeScriptURL(s) {
if (typeof s !== 'string') {
throw new TypeError('tp-app: script URL must be a string');
}
if (s.charAt(0) !== '/' || s.charAt(1) === '/') {
throw new Error('tp-app: only absolute same-origin paths allowed: ' + s);
}
var bareNoQuery = s.split('?')[0].split('#')[0];
if (!/\.(js|mjs)$/.test(bareNoQuery)) {
throw new Error('tp-app: script URL extension not allowed: ' + s);
}
var ALLOWED_PREFIXES = ['/sw.js', '/app.js', '/app-enhance.', '/cite.js', '/verify/'];
var ok = ALLOWED_PREFIXES.some(function (p) {
return bareNoQuery === p || bareNoQuery.indexOf(p) === 0;
});
if (!ok) {
throw new Error('tp-app: script URL not in allowlist: ' + s);
}
return s;
}
var ttPolicy = (typeof window !== 'undefined' && window.trustedTypes &&
typeof window.trustedTypes.createPolicy === 'function')
? window.trustedTypes.createPolicy('tp-app', {
createScriptURL: _safeScriptURL
})
: null;
function trustedScriptURL(value) {
return ttPolicy ? ttPolicy.createScriptURL(value) : value;
}
(function () {
var root = document.documentElement;
function applyTheme(value) {
if (value === 'light' || value === 'dark') {
root.setAttribute('data-theme', value);
} else {
root.removeAttribute('data-theme');
}
try { localStorage.setItem('tp-theme', value); } catch (_) {}
document.querySelectorAll('.site-footer__theme button[data-theme]').forEach(function (b) {
b.setAttribute('aria-pressed', b.getAttribute('data-theme') === value ? 'true' : 'false');
});
}
function bootTheme() {
var stored;
try { stored = localStorage.getItem('tp-theme'); } catch (_) { stored = null; }
var value = (stored === 'light' || stored === 'dark') ? stored : 'system';
document.querySelectorAll('.site-footer__theme button[data-theme]').forEach(function (b) {
b.setAttribute('aria-pressed', b.getAttribute('data-theme') === value ? 'true' : 'false');
});
}
bootTheme();
document.addEventListener('click', function (event) {
if (!event.target || !event.target.closest) return;
var btn = event.target.closest('.site-footer__theme button[data-theme]');
if (!btn) return;
event.preventDefault();
applyTheme(btn.getAttribute('data-theme'));
});
})();
if ('serviceWorker' in navigator && location.protocol === 'https:') {
var swDebug = location.search.indexOf('debug-sw=1') !== -1;
window.addEventListener('load', function () {
try {
navigator.serviceWorker.register(trustedScriptURL('/sw.js'), { scope: '/' })
.then(function (reg) {
if (swDebug) {
try { console.info('[tp] service worker registered', reg && reg.scope); } catch (_) {}
}
})
.catch(function (err) {
if (swDebug) {
try { console.warn('[tp] service worker registration skipped', err); } catch (_) {}
}
});
} catch (err) {
if (swDebug) {
try { console.warn('[tp] service worker registration unavailable', err); } catch (_) {}
}
}
}, { once: true });
}
var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function _deferEnhancements() {
var revealGroups = ['.principle', '.trajectory-item', '.project-card'];
var allRevealEls = document.querySelectorAll(revealGroups.join(', '));
if (!prefersReducedMotion && 'IntersectionObserver' in window) {
var observer = new IntersectionObserver(function (entries) {
entries.forEach(function (entry) {
if (entry.isIntersecting) {
entry.target.classList.add('visible');
observer.unobserve(entry.target);
}
});
}, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });
revealGroups.forEach(function (sel) {
document.querySelectorAll(sel).forEach(function (el, i) {
el.style.transitionDelay = (i * 80) + 'ms';
observer.observe(el);
});
});
} else {
allRevealEls.forEach(function (el) {
el.classList.add('visible');
});
}
var emailLinks = document.querySelectorAll('[data-contact]');
emailLinks.forEach(function (el) {
var existingHref = el.getAttribute('href') || '';
if (existingHref.indexOf('mailto:') === 0) return;
var user = el.getAttribute('data-contact');
var domain = el.getAttribute('data-domain');
if (!user || !domain) return;
var addr = user + '@' + domain;
var href = 'mailto:' + addr;
var subject = el.getAttribute('data-contact-subject');
if (subject) href += '?subject=' + encodeURIComponent(subject);
el.setAttribute('href', href);
var firstChild = el.firstElementChild;
if (firstChild) {
el.insertBefore(document.createTextNode(addr + ' '), firstChild);
} else {
el.textContent = addr;
}
});
}
if ('requestIdleCallback' in window) {
requestIdleCallback(_deferEnhancements, { timeout: 2000 });
} else {
setTimeout(_deferEnhancements, 200);
}
function _tpLoadEnhance() {
if (window.__tpEnhanceLoaded || window.TP_OVERLAY) return;
window.__tpEnhanceLoaded = true;
try {
var s = document.createElement('script'); s.src = trustedScriptURL('/app-enhance.2026-05-19.1bcd9876.js'); s.defer = true;
document.head.appendChild(s);
} catch (_) { }
}
if ('requestIdleCallback' in window) {
requestIdleCallback(_tpLoadEnhance, { timeout: 1500 });
} else {
setTimeout(_tpLoadEnhance, 500);
}
})();
