# trentpower.fr — Editorial Copy Review

**Edition** 2026-05-19  
**Asset version** `2026-05-19.1bcd9876`  
**Generated** 2026-05-20  
**Languages** English, Français  
**Entries** 1033 total, 0 fully multilingual  

Master editorial copy file for trentpower.fr. Every public-facing string the site renders, organised by surface and section. Multilingual where the source supports it.

---

## Editorial principles

### Tone of voice

Calm, declarative, archival. The site speaks once, in a low confident register. Avoid marketing register, avoid hedging. Sentences should be complete and rhythmic, not punchy.

### Privacy-first posture

The site collects nothing and delivers no analytics, cookies, trackers, third-party requests, or external runtime. Copy that reinforces this — privacy page, security page, cite/verify overlays — should be precise and uncluttered. Never overclaim; describe.

### Multilingual posture

English is the canonical authoring language. French, Italian, Spanish, and German are full translations. Each is editorial, not literal — they should read as if originally written in that language by a native professional. Do not import English idiom or sentence rhythm.

### Architectural / editorial relationship

The site itself is part of the artefact. Copy is published, signed, and versioned alongside the code. A copy edit ships the same way a code change ships — through the editorial copy register into a build, then into a signed release. The deployed bytes are the canonical text.

---

## Part 01 · Global navigation and chrome

_70 entries._

_STRING · Cite & verify overlay · copied_  
`cite.copied`

**English** — Copied

**Français** — Copié


<sub>source · `editorial copy register`</sub>


_LABEL · Cite & verify overlay · edition_label_  
`cite.edition_label`

**English** — Edition

**Français** — Édition


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · hover_  
`cite.hover`

**English** — Copy citation

**Français** — Copier la citation


<sub>source · `editorial copy register`</sub>


_LABEL · Cite & verify overlay_  
`cite.label.action`

**English** — Cite & verify

**Français** — Citer et vérifier


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.close`

**English** — Close

**Français** — Fermer


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.copy_citation`

**English** — Copy citation

**Français** — Copier la citation


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.open_source`

**English** — View source

**Français** — Voir le code source


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.print_home`

**English** — Print profile

**Français** — Imprimer le profil


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.print_page`

**English** — Print profile

**Français** — Imprimer le profil


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.print_sheet`

**English** — Print profile

**Français** — Imprimer le profil


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.verify`

**English** — Verify this page

**Français** — Vérifier cette page


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.view_integrity`

**English** — View integrity record

**Français** — Voir la notice d’intégrité


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.footer_signed`

**English** — Edition {edition} · Signed SHA256

**Français** — Édition {edition} · SHA256 signé


<sub>source · `editorial copy register`</sub>


_KICKER · Cite & verify overlay · overlay_  
`cite.overlay.kicker`

**English** — This page

**Français** — Cette page


<sub>source · `editorial copy register`</sub>


_BODY · Cite & verify overlay · overlay_  
`cite.overlay.lede`

**English** — Canonical publication record.

**Français** — Notice de publication canonique.


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.acknowledgments`

**English** — Security acknowledgements

**Français** — Remerciements de sécurité


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.forbidden`

**English** — Access not available

**Français** — Accès non disponible


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.home`

**English** — Client Strategy & Growth Systems

**Français** — Stratégie client et systèmes de croissance


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.integrity`

**English** — Integrity record

**Français** — Notice d’intégrité


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.integrity-verify-locally`

**English** — Verify locally

**Français** — Vérifier localement


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.maintenance`

**English** — Down for maintenance

**Français** — Maintenance en cours


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.not-found`

**English** — Page not found

**Français** — Page introuvable


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.privacy`

**English** — Privacy statement

**Français** — Notice de confidentialité


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.release-archive`

**English** — Release archive · 2026-05-09

**Français** — Archive des versions · 2026-05-09


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.releases`

**English** — Release archive

**Français** — Archive des versions


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.security`

**English** — Security posture

**Français** — Posture de sécurité


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.server-error`

**English** — Temporary server error

**Français** — Erreur serveur temporaire


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.source`

**English** — Source reader

**Français** — Lecteur de code source


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.source-reader`

**English** — Source reader

**Français** — Lecteur de code source


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.sw-reset`

**English** — Service worker reset

**Français** — Réinitialisation du service worker


<sub>source · `editorial copy register`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.verify`

**English** — Verify page

**Français** — Page de vérification


<sub>source · `editorial copy register`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.toast.citation_copied`

**English** — Citation copied

**Français** — Citation copiée


<sub>source · `editorial copy register`</sub>


_LABEL · Cite & verify overlay · site_label_  
`cite.site_label`

**English** — Personal Site

**Français** — Site personnel


<sub>source · `editorial copy register`</sub>


_STRING · Copy-to-clipboard labels · command_  
`copy.command`

**English** — Copy command

**Français** — Copier la commande


<sub>source · `editorial copy register`</sub>


_STRING · Copy-to-clipboard labels · copied_  
`copy.copied`

**English** — Copied

**Français** — Copié


<sub>source · `editorial copy register`</sub>


_STRING · Copy-to-clipboard labels · failed_  
`copy.failed`

**English** — Copy failed

**Français** — Échec de copie


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · lang_toggle_  
`footer.lang_toggle`

**English** — FR

**Français** — EN


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · location_  
`footer.location`

**English** — Paris, France

**Français** — Paris, France


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · privacy_  
`footer.privacy`

**English** — Privacy

**Français** — Confidentialité


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.edition`

**English** — Edition

**Français** — Édition


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.last_verified`

**English** — Verified

**Français** — Vérifié


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.days`

**English** — {n} days ago

**Français** — il y a {n} jours


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.months`

**English** — {n} months ago

**Français** — il y a {n} mois


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.today`

**English** — today

**Français** — aujourd'hui


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.years`

**English** — {n} years ago

**Français** — il y a {n} ans


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.yesterday`

**English** — yesterday

**Français** — hier


<sub>source · `editorial copy register`</sub>


_TITLE · Global footer · proof_  
`footer.proof.sha_title`

**English** — View this page's entry in the signed integrity manifest

**Français** — Voir l'entrée de cette page dans le manifeste d'intégrité signé


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · proof_  
`footer.proof.signed`

**English** — SHA256

**Français** — SHA256


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · provenance_  
`footer.provenance.line`

**English** — Machine-translated from the English original.

**Français** — Traduction automatique de l’édition anglaise originale.


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · theme_  
`footer.theme.auto`

**English** — Auto

**Français** — Auto


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · theme_  
`footer.theme.dark`

**English** — Dark

**Français** — Sombre


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · theme_  
`footer.theme.light`

**English** — Light

**Français** — Clair


<sub>source · `editorial copy register`</sub>


_STRING · Global footer · verify_  
`footer.verify`

**English** — Verify

**Français** — Vérifier


<sub>source · `editorial copy register`</sub>


_STRING · Modal overlay · close_  
`modal.close`

**English** — Close

**Français** — Fermer


> Aria-label for the modal close button.

<sub>source · `editorial copy register`</sub>


_BUTTON · Modal overlay · cta_aria_  
`modal.cta_aria`

**English** — Request access by email

**Français** — Demander l’accès par e-mail


<sub>source · `editorial copy register`</sub>


_LABEL · Modal overlay · cta_label_  
`modal.cta_label`

**English** — Access by request

**Français** — Sur demande


<sub>source · `editorial copy register`</sub>


_STRING · Modal overlay · text_  
`modal.text`

**English** — This is a personal project. If you'd like to see it, I'd be happy to share access.

**Français** — C’est un projet personnel. Si vous souhaitez y accéder, je serais heureux de vous en donner l’accès.


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · heading_  
`trust_routes.heading`

**English** — Trust routes

**Français** — Routes de confiance


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · integrity_desc_  
`trust_routes.integrity_desc`

**English** — How releases are signed

**Français** — Comment les éditions sont signées


<sub>source · `editorial copy register`</sub>


_LABEL · Trust-chain route labels · integrity_label_  
`trust_routes.integrity_label`

**English** — Integrity

**Français** — Intégrité


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · privacy_desc_  
`trust_routes.privacy_desc`

**English** — What this site does not collect

**Français** — Ce que ce site ne collecte pas


<sub>source · `editorial copy register`</sub>


_LABEL · Trust-chain route labels · privacy_label_  
`trust_routes.privacy_label`

**English** — Privacy

**Français** — Confidentialité


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · releases_desc_  
`trust_routes.releases_desc`

**English** — Frozen signed snapshots

**Français** — Instantanés signés et figés


<sub>source · `editorial copy register`</sub>


_LABEL · Trust-chain route labels · releases_label_  
`trust_routes.releases_label`

**English** — Releases

**Français** — Éditions


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · security_desc_  
`trust_routes.security_desc`

**English** — How the site is protected

**Français** — Comment le site est protégé


<sub>source · `editorial copy register`</sub>


_LABEL · Trust-chain route labels · security_label_  
`trust_routes.security_label`

**English** — Security

**Français** — Sécurité


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · source_desc_  
`trust_routes.source_desc`

**English** — Readable mirrors of public files

**Français** — Miroirs lisibles des fichiers publics


<sub>source · `editorial copy register`</sub>


_LABEL · Trust-chain route labels · source_label_  
`trust_routes.source_label`

**English** — Source

**Français** — Source


<sub>source · `editorial copy register`</sub>


_STRING · Trust-chain route labels · verify_desc_  
`trust_routes.verify_desc`

**English** — How a page can be checked

**Français** — Comment une page peut être contrôlée


<sub>source · `editorial copy register`</sub>


_LABEL · Trust-chain route labels · verify_label_  
`trust_routes.verify_label`

**English** — Verify

**Français** — Vérifier


<sub>source · `editorial copy register`</sub>


---

## Part 02 · Homepage

_51 entries._

_BODY · Homepage — Approach · adoption_body_  
`approach.adoption_body`

**English** — A strategy or technology only creates value when teams trust it and choose to use it. Trust must be earned, and utility must be proven. Client Advisors are first-line Clients and vital collaborators.

**Français** — Une stratégie ou une technologie ne crée de la valeur que lorsque les équipes lui font confiance et choisissent de l’utiliser. La confiance se mérite, l’utilité se démontre. Les Conseillers Clients sont des Clients de première ligne et des collaborateurs essentiels.


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Approach · adoption_title_  
`approach.adoption_title`

**English** — Adoption matters more than tools

**Français** — L’adoption compte plus que les outils


<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Approach · ai_body_  
`approach.ai_body`

**English** — Authenticity is a human advantage, and it cannot be automated. Trust, empathy, and judgement are built in the moment through tone and presence. I use AI to remove friction so people can show up more relevant, more consistent and more human, at scale.

**Français** — L’authenticité est un avantage humain, elle ne peut pas être automatisée. La confiance, l’empathie et le jugement se construisent dans l’instant, à travers le ton et la présence. J’utilise l’IA pour réduire les frictions, afin que chacun puisse être plus pertinent, plus cohérent et plus humain, à grande échelle.


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Approach · ai_title_  
`approach.ai_title`

**English** — AI should amplify human relationships

**Français** — L’IA doit amplifier les relations humaines


<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Approach · clienteling_detail_  
`approach.clienteling_detail`

**English** — <dfn id="clienteling-definition" itemprop="name">Clienteling</dfn> <span itemprop="description">is a discipline. It is the practice of transforming what a Client Advisor knows into something a Client feels. The moment interactions become mechanical, it stops being Clienteling.</span>

**Français** — Le <dfn id="clienteling-definition" itemprop="name">clienteling</dfn> <span itemprop="description">est une discipline. C’est la pratique de transformer ce qu’un Conseiller Client sait en quelque chose qu’un Client ressent. Dès que les interactions deviennent mécaniques, ce n’est plus du clienteling.</span>


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Approach · clienteling_title_  
`approach.clienteling_title`

**English** — Clienteling converts transaction into meaning

**Français** — Le clienteling transforme la transaction en sens


<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Approach · governance_body_  
`approach.governance_body`

**English** — Clear ownership, cadence, and priorities create alignment, accelerate decisions, and enable scale.

**Français** — Des responsabilités claires, une cadence régulière et des priorités créent l’alignement, accélèrent les décisions et permettent le passage à l’échelle.


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Approach · governance_title_  
`approach.governance_title`

**English** — Governance creates momentum

**Français** — La gouvernance crée de l’élan


<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Approach · growth_body_  
`approach.growth_body`

**English** — Lasting growth follows when elegant systems are in place.

**Français** — Une croissance durable repose sur des systèmes élégants.


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Approach · growth_title_  
`approach.growth_title`

**English** — Client growth takes discipline

**Français** — La croissance client exige une discipline


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Approach_  
`approach.label`

**English** — Approach

**Français** — Approche


> Section anchor label.

<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Approach · taste_body_  
`approach.taste_body`

**English** — Discernment, and cultural awareness shape interactions into something valuable and memorable.

**Français** — Le discernement et la conscience culturelle façonnent les interactions en quelque chose de précieux et mémorable.


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Approach · taste_title_  
`approach.taste_title`

**English** — Taste is a strategic advantage

**Français** — Le goût est un avantage stratégique


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Contact · email_aria_  
`contact.email_aria`

**English** — Email Trent Power

**Français** — Écrire à Trent Power


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Contact · headline_  
`contact.headline`

**English** — Write,<br>and I&rsquo;ll <em>write back.</em>

**Français** — Écrivez-moi,<br>et je <em>vous répondrai.</em>


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Contact_  
`contact.label`

**English** — Contact

**Français** — Contact


> Section anchor label.

<sub>source · `editorial copy register`</sub>


_BODY · Homepage hero_  
`hero.body`

**English** — I lead client strategy at Group level, focusing on the systems, governance, and ways of working that turn client relationships into long-term value. My work sits at the intersection of strategy, technology, and human relationships, with a focus on impact that scales and endures.

**Français** — Je pilote la stratégie client au niveau du Groupe, en me concentrant sur les systèmes, la gouvernance et les façons de travailler qui transforment les relations clients en valeur à long terme. Mon travail se situe à l’intersection de la stratégie, de la technologie et des relations humaines, avec un impact qui se déploie à grande échelle et dans la durée.


> Supporting paragraph. ~3–5 sentences, calm voice, no marketing register.

<sub>source · `editorial copy register`</sub>


_STRING · Homepage hero · statement_  
`hero.statement`

**English** — Client strategy,<br><mark>growth systems,</mark><br>and cultural adoption<br>at global scale.

**Français** — Stratégie client,<br><mark>systèmes de croissance,</mark><br>et adoption culturelle<br>à l’échelle mondiale.


> Primary identity statement. Keep declarative, restrained, one sentence.

<sub>source · `editorial copy register`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.0`

**English** — Continue in English, the author's edition


> Screen-reader-only label or image alt text.

<sub>source · `/`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.1`

**English** — Continuer en français, une version traduite par machine


> Screen-reader-only label or image alt text.

<sub>source · `/`</sub>


_STRING · Homepage · trust_no_tracking_  
`home.trust_no_tracking`

**English** — no tracking

**Français** — sans suivi


<sub>source · `editorial copy register`</sub>


_STRING · Homepage · trust_privacy_  
`home.trust_privacy`

**English** — privacy-first

**Français** — confidentialité d’abord


<sub>source · `editorial copy register`</sub>


_STRING · Homepage · trust_signed_  
`home.trust_signed`

**English** — signed releases

**Français** — versions signées


<sub>source · `editorial copy register`</sub>


_STRING · Homepage · trust_static_  
`home.trust_static`

**English** — static

**Français** — statique


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Projects_  
`projects.label`

**English** — Projects

**Français** — Projets


> Section anchor label.

<sub>source · `editorial copy register`</sub>


_BUTTON · Homepage — Projects · paris_cta_  
`projects.paris_cta`

**English** — View project

**Français** — Voir le projet


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Projects · paris_desc_  
`projects.paris_desc`

**English** — A private cultural intelligence system for Paris, combining location, effort, editorial judgement and personal taste into a calmer way to decide what is worth leaving home for.

**Français** — Un système privé d’intelligence culturelle pour Paris, combinant localisation, effort, jugement éditorial et goût personnel pour décider plus calmement ce qui mérite une sortie.


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Projects · paris_preview_caption_  
`projects.paris_preview_caption`

**English** — A sample cultural intelligence selection for one week, one neighbourhood.

**Français** — Un échantillon de sélections d'intelligence culturelle, une semaine, un quartier.


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Projects · paris_preview_header_  
`projects.paris_preview_header`

**English** — This week near Jourdain, 20th

**Français** — Cette semaine près de Jourdain, 20e


<sub>source · `editorial copy register`</sub>


_SUBLINE · Homepage — Projects · paris_subline_  
`projects.paris_subline`

**English** — A personal experiment in taste systems, local relevance and human-scale recommendation.

**Français** — Une expérimentation personnelle autour des systèmes de goût, de la pertinence locale et de la recommandation à échelle humaine.


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Projects · tier_bike_  
`projects.tier_bike`

**English** — bike

**Français** — vélo


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Projects · tier_metro_  
`projects.tier_metro`

**English** — metro

**Français** — métro


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Projects · tier_walk_  
`projects.tier_walk`

**English** — walk

**Français** — à pied


<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Trajectory · background_detail_  
`trajectory.background_detail`

**English** — Building online platforms and communities

**Français** — Construire des plateformes et des communautés en ligne


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Trajectory · background_label_  
`trajectory.background_label`

**English** — Background

**Français** — Parcours initial


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · background_span_  
`trajectory.background_span`

**English** — 1997 — 2004

**Français** — 1997 — 2004


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Trajectory · background_title_  
`trajectory.background_title`

**English** — Web Entrepreneur

**Français** — Entrepreneur web


<sub>source · `editorial copy register`</sub>


_BODY · Homepage — Trajectory · current_detail_  
`trajectory.current_detail`

**English** — Group-wide client strategy across Maisons and markets

**Français** — Stratégie client à l’échelle du Groupe, à travers Maisons et marchés


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Trajectory · current_label_  
`trajectory.current_label`

**English** — Current

**Français** — Actuel


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · current_org_  
`trajectory.current_org`

**English** — <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr>

**Français** — <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr>


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · current_span_  
`trajectory.current_span`

**English** — 2023 — now

**Français** — 2023 — aujourd’hui


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Trajectory · current_title_  
`trajectory.current_title`

**English** — Group Director, Client Development & Client Relations

**Français** — Directeur Groupe, Développement Client & Relations Clients


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Trajectory_  
`trajectory.label`

**English** — Trajectory

**Français** — Parcours


> Section anchor label.

<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Trajectory · maisons_label_  
`trajectory.maisons_label`

**English** — Maisons

**Français** — Maisons


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · maisons_org_  
`trajectory.maisons_org`

**English** — BVLGARI

**Français** — BVLGARI


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · maisons_span_  
`trajectory.maisons_span`

**English** — 2004 — 2017

**Français** — 2004 — 2017


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Trajectory · maisons_title_  
`trajectory.maisons_title`

**English** — Senior leadership across <a href="/#clienteling-definition" aria-label="Read the definition of Clienteling used on this site">Clienteling</a>, <abbr title="Customer Relationship Management">CRM</abbr> & Retail

**Français** — Direction senior en <a href="/#clienteling-definition" aria-label="Lire la définition de Clienteling utilisée sur ce site">Clienteling</a>, <abbr title="Customer Relationship Management">CRM</abbr> & Retail


<sub>source · `editorial copy register`</sub>


_LABEL · Homepage — Trajectory · previous_label_  
`trajectory.previous_label`

**English** — Previous

**Français** — Précédent


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · previous_org_  
`trajectory.previous_org`

**English** — <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr>

**Français** — <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr>


<sub>source · `editorial copy register`</sub>


_STRING · Homepage — Trajectory · previous_span_  
`trajectory.previous_span`

**English** — 2017 — 2023

**Français** — 2017 — 2023


<sub>source · `editorial copy register`</sub>


_TITLE · Homepage — Trajectory · previous_title_  
`trajectory.previous_title`

**English** — Group Head of Clienteling

**Français** — Responsable Groupe Clienteling


<sub>source · `editorial copy register`</sub>


---

## Part 03 · Print profile

_47 entries._

_STRING · Print profile · arch_  
`print.arch.archive`

**English** — Archive

**Français** — Archive


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · arch_  
`print.arch.browser`

**English** — Browser

**Français** — Navigateur


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · arch_  
`print.arch.cache`

**English** — Offline Cache

**Français** — Cache


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · arch_  
`print.arch.caption`

**English** — Static, privacy-first, signed and inspectable

**Français** — Statique, respectueux de la vie privée, signé et inspectable


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · arch_  
`print.arch.files`

**English** — Site Files

**Français** — Fichiers


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · arch_  
`print.arch.host`

**English** — Static Host

**Français** — Hébergement


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · arch_  
`print.arch.trust`

**English** — Trust

**Français** — Confiance


<sub>source · `editorial copy register`</sub>


_BODY · Print profile_  
`print.body`

**English** — I lead client strategy at Group level, focusing on the systems, governance and ways of working that turn client relationships into long-term value. My work sits at the intersection of strategy, technology and human relationships, with a focus on impact that scales and endures.

**Français** — Je dirige la stratégie client au niveau Groupe, en me concentrant sur les systèmes, la gouvernance et les méthodes de travail qui transforment les relations clients en valeur durable. Mon travail se situe à l’intersection de la stratégie, de la technologie et des relations humaines, avec un impact qui passe à l’échelle et qui dure.


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · contact_  
`print.contact.linkedin`

**English** — LinkedIn · Trent Power

**Français** — LinkedIn · Trent Power


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · credentials_  
`print.credentials.exec_detail`

**English** — Ongoing senior-level learning across artificial intelligence, consumer behaviour, organisational transformation, and leadership coaching.

**Français** — Apprentissage senior en continu — intelligence artificielle, comportement consommateur, transformation organisationnelle et coaching en leadership.


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · credentials_  
`print.credentials.exec_title`

**English** — Selective executive education

**Français** — Formation exécutive sélective


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · credentials_  
`print.credentials.label`

**English** — Credentials

**Français** — Parcours académique


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · credentials_  
`print.credentials.sydney_detail`

**English** — Master’s degree, 2009.

**Français** — Master, 2009.


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · credentials_  
`print.credentials.sydney_title`

**English** — University of Sydney

**Français** — University of Sydney


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · doc_title_  
`print.doc_title`

**English** — Trent Power - Client Strategy Executive Profile

**Français** — Trent Power - Profil exécutif stratégie client


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · focus_  
`print.focus.01.body`

**English** — Lasting growth follows when strong systems are in place.

**Français** — Une croissance durable repose sur des systèmes solides.


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · focus_  
`print.focus.01.label`

**English** — 01 Focus

**Français** — 01 Focus


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · focus_  
`print.focus.01.title`

**English** — Client growth takes discipline

**Français** — La croissance client exige une discipline


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · focus_  
`print.focus.02.body`

**English** — Technology creates value when teams trust it, choose it and use it.

**Français** — La technologie crée de la valeur quand les équipes lui font confiance, la choisissent et l’utilisent.


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · focus_  
`print.focus.02.label`

**English** — 02 Adoption

**Français** — 02 Adoption


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · focus_  
`print.focus.02.title`

**English** — Adoption matters more than tools

**Français** — L’adoption compte plus que les outils


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · focus_  
`print.focus.03.body`

**English** — Authenticity remains a human advantage; automation must strengthen context, memory and care.

**Français** — L’authenticité reste un avantage humain ; l’automatisation doit renforcer le contexte, la mémoire et l’attention.


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · focus_  
`print.focus.03.label`

**English** — 03 Human relationships

**Français** — 03 Relations humaines


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · focus_  
`print.focus.03.title`

**English** — AI should amplify human relationships

**Français** — L’IA doit amplifier les relations humaines


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · focus_  
`print.focus.04.body`

**English** — Clear ownership and disciplined priorities create alignment and scale.

**Français** — Un cadre de responsabilité clair et des priorités disciplinées créent l’alignement et l’échelle.


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · focus_  
`print.focus.04.label`

**English** — 04 Governance

**Français** — 04 Gouvernance


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · focus_  
`print.focus.04.title`

**English** — Governance creates momentum

**Français** — La gouvernance crée de l’élan


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · footer_  
`print.footer.citation`

**English** — Trent Power. Personal Site. Paris, France.

**Français** — Trent Power. Site personnel. Paris, France.


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · footer_  
`print.footer.edition`

**English** — Edition <time datetime="2026-05-19">2026-05-19</time> · https://trentpower.fr/

**Français** — Édition <time datetime="2026-05-19">2026-05-19</time> · https://trentpower.fr/


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · footer_  
`print.footer.evidence`

**English** — Public record · HTML · Edition 19 May 2026

**Français** — Document public · HTML · Édition du 19 mai 2026


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · footer_  
`print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Print profile_  
`print.kicker`

**English** — trentpower.fr

**Français** — trentpower.fr


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · name_  
`print.name`

**English** — Trent Power

**Français** — Trent Power


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · place_  
`print.place`

**English** — Personal Site · Paris, France

**Français** — Site personnel · Paris, France


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · project_  
`print.project.body`

**English** — A private cultural intelligence system for Paris, combining location, effort, editorial judgement and personal taste into a calmer way to decide what is worth leaving home for.

**Français** — Un système privé d’intelligence culturelle pour Paris, combinant localisation, effort, jugement éditorial et goût personnel pour décider plus calmement de ce qui mérite que l’on sorte de chez soi.


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · project_  
`print.project.label`

**English** — Proof point

**Français** — Point de preuve


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · project_  
`print.project.note`

**English** — A personal experiment in taste systems, local relevance and human-scale recommendation.

**Français** — Une expérimentation personnelle sur les systèmes de goût, la pertinence locale et la recommandation à échelle humaine.


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile · project_  
`print.project.title`

**English** — What’s On in Paris

**Français** — What’s On in Paris


<sub>source · `editorial copy register`</sub>


_STRING · Print profile · role_  
`print.role`

**English** — Client strategy, growth systems and cultural adoption

**Français** — Stratégie client, systèmes de croissance et adoption culturelle


<sub>source · `editorial copy register`</sub>


_TITLE · Print profile_  
`print.title`

**English** — Client strategy, growth systems and cultural adoption at global scale

**Français** — Stratégie client, systèmes de croissance et adoption culturelle à l’échelle mondiale


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · trajectory_  
`print.trajectory.background.body`

**English** — Early digital and entrepreneurial work building online platforms and communities

**Français** — Travaux digitaux et entrepreneuriaux fondateurs : plateformes et communautés en ligne


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.background.label`

**English** — Background

**Français** — Parcours initial


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · trajectory_  
`print.trajectory.current.body`

**English** — Group Director, Client Development & Client Relations · LVMH

**Français** — Directeur Groupe, Développement Client & Relations Clients · LVMH


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.current.label`

**English** — Current

**Français** — Actuel


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.label`

**English** — Trajectory

**Français** — Parcours


<sub>source · `editorial copy register`</sub>


_BODY · Print profile · trajectory_  
`print.trajectory.previous.body`

**English** — Senior leadership across Clienteling, CRM and Client Development

**Français** — Direction senior en Clienteling, CRM et Développement Client


<sub>source · `editorial copy register`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.previous.label`

**English** — Previous

**Français** — Précédent


<sub>source · `editorial copy register`</sub>


---

## Part 04 · Privacy

_32 entries._

_BODY · Privacy page · body_detail_  
`privacy.body_detail`

**English** — External links are ordinary references. They are contacted only if you choose to open them. The only browser storage used is a local language preference. It stays on your device and is never transmitted.

**Français** — Les liens externes sont de simples références. Ils ne sont contactés que si vous choisissez de les ouvrir. Le seul stockage navigateur utilisé est une préférence de langue locale. Elle reste sur votre appareil et n’est jamais transmise.


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · body_intro_  
`privacy.body_intro`

**English** — No tracking, analytics, cookies, profiling, embedded third-party services, or third-party requests while you browse. No personal data is collected for analytics, advertising, or profiling. Any limited technical data the server processes is used only to keep the site secure and operating correctly.

**Français** — Aucun suivi, aucune analytique, aucun cookie, aucun profilage, aucun service tiers intégré, ni requête vers des tiers pendant votre navigation. Aucune donnée personnelle n’est collectée à des fins d’analyse, de publicité ou de profilage. Les données techniques limitées traitées par le serveur servent uniquement à assurer la sécurité et le bon fonctionnement du site.


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · body_records_  
`privacy.body_records`

**English** — Public inspection and verification records are published separately. You can read the <a href="/security/" aria-describedby="desc-security-threat-model">Security & threat model</a> for the full posture.

**Français** — Les registres d’inspection publique et de vérification sont publiés séparément. Vous pouvez consulter le <a href="/security/" aria-describedby="desc-security-threat-model">Modèle de sécurité et de menaces</a> pour la posture complète.


<sub>source · `editorial copy register`</sub>


_STRING · Privacy page · page_h1_  
`privacy.page_h1`

**English** — <span class="hero-line">Nothing tracked.</span><span class="hero-line">Nothing to delete.</span>

**Français** — <span class="hero-line">Rien n’est suivi.</span><span class="hero-line">Rien à supprimer.</span>


<sub>source · `editorial copy register`</sub>


_KICKER · Privacy page · page_kicker_  
`privacy.page_kicker`

**English** — Privacy & Trust

**Français** — Confidentialité & confiance


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · page_title_  
`privacy.page_title`

**English** — Privacy & Trust

**Français** — Confidentialité & confiance


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.01.body`

**English** — No analytics. No cookies. No profiling. No third-party requests while browsing.

**Français** — Aucune analytique. Aucun cookie. Aucun profilage. Aucune requête tierce pendant la navigation.


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.01.label`

**English** — 01 No tracking

**Français** — 01 Aucun suivi


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.01.title`

**English** — No tracking

**Français** — Aucun suivi


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.02.body`

**English** — No public forms. No visitor accounts. No behavioural tracking. No advertising infrastructure.

**Français** — Aucun formulaire public. Aucun compte visiteur. Aucun suivi comportemental. Aucune infrastructure publicitaire.


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.02.label`

**English** — 02 No data collection

**Français** — 02 Aucune collecte


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.02.title`

**English** — No data collection

**Français** — Aucune collecte de données


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.03.body`

**English** — Integrity page. Security page. Public manifest. Source view.

**Français** — Page Intégrité. Page Sécurité. Manifeste public. Vue source.


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.03.label`

**English** — 03 Verification route

**Français** — 03 Voie de vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.03.title`

**English** — Verification route

**Français** — Voie de vérification


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.04.body`

**English** — Privacy is not a compliance layer. It is part of the site’s editorial and professional posture.

**Français** — La confidentialité n’est pas une couche de conformité. Elle fait partie de la posture éditoriale et professionnelle du site.


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.04.label`

**English** — 04 Design principle

**Français** — 04 Principe de conception


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.04.title`

**English** — Privacy as posture

**Français** — La privacy comme posture


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.05.body`

**English** — View source. Read /integrity.json. Verify the signature. Inspect the security headers.

**Français** — Voir la source. Lire /integrity.json. Vérifier la signature. Inspecter les en-têtes de sécurité.


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.05.label`

**English** — 05 What you can check

**Français** — 05 Ce que vous pouvez vérifier


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.05.title`

**English** — What you can check

**Français** — Ce que vous pouvez vérifier


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.06.body`

**English** — trent@trentpower.fr · canonical route trentpower.fr/privacy/

**Français** — trent@trentpower.fr · route canonique trentpower.fr/privacy/


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.06.label`

**English** — 06 Contact

**Français** — 06 Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.06.title`

**English** — Contact

**Français** — Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.doc_title`

**English** — Trent Power - Privacy Trust Sheet

**Français** — Trent Power - Profil de confidentialité


<sub>source · `editorial copy register`</sub>


_STRING · Privacy page · print_  
`privacy.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/privacy/

**Français** — Édition 2026-05-19 · trentpower.fr/privacy/


<sub>source · `editorial copy register`</sub>


_STRING · Privacy page · print_  
`privacy.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Privacy page · print_  
`privacy.print.kicker`

**English** — Privacy & Trust

**Français** — Confidentialité & confiance


<sub>source · `editorial copy register`</sub>


_BODY · Privacy page · print_  
`privacy.print.lede`

**English** — This site is intentionally simple and privacy-respectful. It uses no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse.

**Français** — Ce site est volontairement simple et respectueux de la vie privée. Il n’utilise ni suivi, ni analytique, ni cookies, ni profilage, ni requêtes tierces intégrées pendant la navigation.


<sub>source · `editorial copy register`</sub>


_STRING · Privacy page · print_  
`privacy.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/privacy/

**Français** — Édition 2026-05-19 · trentpower.fr/privacy/


<sub>source · `editorial copy register`</sub>


_LABEL · Privacy page · print_  
`privacy.print.qr.label`

**English** — trentpower.fr/privacy/

**Français** — trentpower.fr/privacy/


<sub>source · `editorial copy register`</sub>


_TITLE · Privacy page · print_  
`privacy.print.title`

**English** — Privacy-first by design

**Français** — La confidentialité, par conception


<sub>source · `editorial copy register`</sub>


---

## Part 05 · Integrity & Releases

_128 entries._

_BODY · Integrity page · body_intro_  
`integrity.body_intro`

**English** — Every public file is hashed and listed in a manifest, signed with a detached <abbr title="Pretty Good Privacy">PGP</abbr> signature so each release can be checked against the publisher's key - independently, on your own machine, without trust in this server. You can <a href="/integrity/verify-locally/" aria-describedby="desc-verify-locally">verify locally here</a>.

**Français** — Chaque fichier public est haché et listé dans un manifeste, signé par une signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée — chaque version peut donc être vérifiée avec la clé de l’éditeur, en local, sans confiance envers ce serveur. Vous pouvez <a href="/integrity/verify-locally/" aria-describedby="desc-verify-locally">vérifier localement ici</a>.


<sub>source · `editorial copy register`</sub>


_BUTTON · Integrity page · copy_button_  
`integrity.copy_button`

**English** — Copy

**Français** — Copier


<sub>source · `editorial copy register`</sub>


_BUTTON · Integrity page · copy_button_done_  
`integrity.copy_button_done`

**English** — Copied

**Français** — Copié


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · file_integrity_  
`integrity.file_integrity`

**English** — /integrity.json · SHA-256 hashes of all public assets

**Français** — /integrity.json · hachages SHA-256 de tous les fichiers publics


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · file_key_  
`integrity.file_key`

**English** — /.well-known/pgp-key.asc · public signing key

**Français** — /.well-known/pgp-key.asc · clé de signature publique


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · file_sig_  
`integrity.file_sig`

**English** — /integrity.json.sig · detached PGP signature

**Français** — /integrity.json.sig · signature PGP détachée


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · fingerprint_copied_  
`integrity.fingerprint_copied`

**English** — Copied

**Français** — Copiée


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · fingerprint_copy_  
`integrity.fingerprint_copy`

**English** — Copy fingerprint

**Français** — Copier l’empreinte


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · page_h1_  
`integrity.page_h1`

**English** — <span class="hero-line">Signed.</span><span class="hero-line">Verifiable.</span><span class="hero-line">Reproducible.</span>

**Français** — <span class="hero-line">Signé.</span><span class="hero-line">Vérifiable.</span><span class="hero-line">Reproductible.</span>


<sub>source · `editorial copy register`</sub>


_KICKER · Integrity page · page_kicker_  
`integrity.page_kicker`

**English** — Integrity

**Français** — Intégrité


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · page_title_  
`integrity.page_title`

**English** — Integrity

**Français** — Intégrité


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.01.body`

**English** — <code>/integrity.json</code> - <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> hashes of every intentional public file.

**Français** — <code>/integrity.json</code> - empreintes <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> de chaque fichier public intentionnel.


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.01.label`

**English** — 01 Manifest

**Français** — 01 Manifeste


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.01.title`

**English** — Manifest

**Français** — Manifeste


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.02.body`

**English** — /integrity.json.sig - detached <abbr title="Pretty Good Privacy">PGP</abbr> signature that verifies the manifest.

**Français** — /integrity.json.sig - signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée qui certifie le manifeste.


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.02.label`

**English** — 02 Signature

**Français** — 02 Signature


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.02.title`

**English** — Detached signature

**Français** — Signature détachée


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.03.body`

**English** — /.well-known/pgp-key.asc - fingerprint A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.

**Français** — /.well-known/pgp-key.asc - empreinte A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.03.label`

**English** — 03 Public key

**Français** — 03 Clé publique


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.03.title`

**English** — Public key

**Français** — Clé publique


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.04.body`

**English** — /integrity/releases/ - public snapshots: February 2026 and May 2026.

**Français** — /integrity/releases/ - instantanés publics : février 2026 et mai 2026.


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.04.label`

**English** — 04 Releases

**Français** — 04 Versions


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.04.title`

**English** — Frozen releases

**Français** — Versions figées


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.05.body`

**English** — /source/ - public text view of selected source files. No secrets, no private artefacts.

**Français** — /source/ - vue texte publique de fichiers sources sélectionnés. Aucun secret, aucun artefact privé.


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.05.label`

**English** — 05 Source route

**Français** — 05 Voie source


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.05.title`

**English** — Source route

**Français** — Voie source


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.06.body`

**English** — curl -O trentpower.fr/integrity.json && curl -O trentpower.fr/integrity.json.sig && gpg --verify integrity.json.sig integrity.json

**Français** — curl -O trentpower.fr/integrity.json && curl -O trentpower.fr/integrity.json.sig && gpg --verify integrity.json.sig integrity.json


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.06.label`

**English** — 06 Verification

**Français** — 06 Vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.06.title`

**English** — Verification

**Français** — Vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.doc_title`

**English** — Trent Power - Integrity Verification Sheet

**Français** — Trent Power - Certificat d’intégrité


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · print_  
`integrity.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/integrity/

**Français** — Édition 2026-05-19 · trentpower.fr/integrity/


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · print_  
`integrity.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Integrity page · print_  
`integrity.print.kicker`

**English** — Integrity

**Français** — Intégrité


<sub>source · `editorial copy register`</sub>


_BODY · Integrity page · print_  
`integrity.print.lede`

**English** — Published files are listed in a public manifest and signed with a detached <abbr title="Pretty Good Privacy">PGP</abbr> signature so updates can be verified independently.

**Français** — Les fichiers publiés sont listés dans un manifeste public et signés par une signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée afin que toute mise à jour puisse être vérifiée de manière indépendante.


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · print_  
`integrity.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/integrity/

**Français** — Édition 2026-05-19 · trentpower.fr/integrity/


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · print_  
`integrity.print.qr.label`

**English** — trentpower.fr/integrity/

**Français** — trentpower.fr/integrity/


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · print_  
`integrity.print.title`

**English** — Signed public verification

**Français** — Vérification publique signée


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.action.view_manifest`

**English** — View manifest

**Français** — Voir le manifeste


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.action.view_releases`

**English** — View releases

**Français** — Voir les éditions


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.archives`

**English** — Signed public source release

**Français** — Édition publique signée des sources


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.checksums`

**English** — Signed checksum list for archive downloads

**Français** — Liste de sommes de contrôle signée pour les archives


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.manifest`

**English** — <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> hashes of public files

**Français** — Empreintes <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> des fichiers publics


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.public_key`

**English** — Public signing key

**Français** — Clé publique de signature


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.signature`

**English** — Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature

**Français** — Signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.group.archives`

**English** — Source archives

**Français** — Archives source


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.group.fingerprint`

**English** — Release fingerprint

**Français** — Empreinte de version


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.group.verification`

**English** — Verification records

**Français** — Pièces de vérification


<sub>source · `editorial copy register`</sub>


_KICKER · Integrity page · record_  
`integrity.record.kicker`

**English** — Signed release

**Français** — Édition signée


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.archives`

**English** — Archives

**Français** — Archives


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.checksums`

**English** — Archive checksums

**Français** — Sommes de contrôle


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.fingerprint`

**English** — Fingerprint

**Français** — Empreinte


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.manifest`

**English** — Manifest

**Français** — Manifeste


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.public_key`

**English** — Public key

**Français** — Clé publique


<sub>source · `editorial copy register`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.signature`

**English** — Detached signature

**Français** — Signature détachée


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · record_  
`integrity.record.status_short`

**English** — Manifest · Signature · Public key

**Français** — Manifeste · Signature · Clé publique


<sub>source · `editorial copy register`</sub>


_TITLE · Integrity page · record_  
`integrity.record.title`

**English** — <time datetime="2026-05">May 2026</time>

**Français** — <time datetime="2026-05">Mai 2026</time>


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · verify_release_local_  
`integrity.verify_release_local.note`

**English** — Run the signed manifest check in a temporary keyring.

**Français** — Exécute la vérification du manifeste signé dans un trousseau temporaire.


<sub>source · `editorial copy register`</sub>


_STRING · Integrity page · verify_release_local_  
`integrity.verify_release_local.summary`

**English** — Advanced local verification

**Français** — Vérification locale avancée


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · aria_  
`releases.aria.actions_archive`

**English** — Release record

**Français** — Fiche d’édition


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · aria_  
`releases.aria.actions_current`

**English** — Current release downloads and verification

**Français** — Téléchargements et vérification de l’édition actuelle


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · body_intro_  
`releases.body_intro`

**English** — Each <dfn id="signed-release">release</dfn> is a frozen, signed snapshot of the public site at the time of publication. Source archives can be downloaded, and checksums and signatures are provided for local verification.

**Français** — Chaque <dfn id="signed-release">édition</dfn> est un instantané figé et signé du site public au moment de la publication. Les archives sources peuvent être téléchargées, et des sommes de contrôle et signatures sont fournies pour la vérification locale.


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sha`

**English** — SHA-256 checksum

**Français** — Somme de contrôle SHA-256


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sig`

**English** — Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature

**Français** — Signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sums`

**English** — SHA-256 list for release archives

**Français** — Liste SHA-256 des archives de l’édition


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sums_sig`

**English** — Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature over SHA256SUMS

**Français** — Signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée sur SHA256SUMS


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.targz`

**English** — Technical preservation archive

**Français** — Archive technique de préservation


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.zip`

**English** — Portable public source snapshot

**Français** — Instantané portable de la source publique


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.kicker`

**English** — Release files

**Français** — Fichiers d’édition


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.sums`

**English** — Checksum list

**Français** — Liste de sommes de contrôle


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.sums_sig`

**English** — Checksum list signature

**Français** — Signature de la liste


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.targz`

**English** — TAR.GZ

**Français** — TAR.GZ


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.targz_sha`

**English** — TAR.GZ checksum

**Français** — Somme TAR.GZ


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.targz_sig`

**English** — TAR.GZ signature

**Français** — Signature TAR.GZ


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.zip`

**English** — ZIP

**Français** — ZIP


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.zip_sha`

**English** — ZIP checksum

**Français** — Somme ZIP


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.zip_sig`

**English** — ZIP signature

**Français** — Signature ZIP


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.status`

**English** — ZIP · TAR.GZ · Checksums · Signatures

**Français** — ZIP · TAR.GZ · Sommes de contrôle · Signatures


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · detail_  
`releases.detail.card.title`

**English** — 9 May 2026

**Français** — 17 mai 2026


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.intro`

**English** — Signed release archives for the 9 May 2026 edition. A signed checksum list verifies the archive set; checksums verify the downloaded files; detached signatures verify each archive directly. The signed manifest at /integrity.json remains the live-site authority.

**Français** — Archives d’édition signées pour l’édition du 17 mai 2026. Une liste de sommes de contrôle signée vérifie l’ensemble des archives ; les sommes de contrôle vérifient les fichiers téléchargés ; des signatures détachées vérifient directement chaque archive. Le manifeste signé publié à /integrity.json reste l’autorité du site en direct.


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · detail_  
`releases.detail.note`

**English** — Archive binaries are not included in /integrity.json to avoid recursive hashing. They are verified separately through the signed checksum list, individual SHA-256 checksums and detached signatures. <a href="/integrity/">Integrity</a> remains the live-site authority.

**Français** — Les fichiers d’archive ne sont pas inclus dans /integrity.json afin d’éviter un hachage récursif. Ils sont vérifiés séparément au moyen de la liste de sommes de contrôle signée, des sommes de contrôle SHA-256 individuelles et de signatures détachées. <a href="/integrity/">Intégrité</a> reste l’autorité du site en direct.


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · detail_  
`releases.detail.page_title`

**English** — May 2026

**Français** — Mai 2026


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · download_checksums_sig_  
`releases.download_checksums_sig`

**English** — Checksums & signature

**Français** — Sommes de contrôle & signature


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · download_targz_  
`releases.download_targz`

**English** — Download TAR.GZ

**Français** — Télécharger TAR.GZ


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · download_zip_  
`releases.download_zip`

**English** — Download ZIP

**Français** — Télécharger ZIP


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_feb_  
`releases.edition_feb`

**English** — February 2026 · initial signed release

**Français** — Février 2026 · première version signée


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_feb_date_  
`releases.edition_feb_date`

**English** — February 2026

**Français** — Février 2026


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_feb_desc_  
`releases.edition_feb_desc`

**English** — <cite>Initial signed release</cite>

**Français** — <cite>Première édition signée</cite>


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_feb_meta_  
`releases.edition_feb_meta`

**English** — Signed snapshot · Initial release

**Français** — Instantané signé · Édition initiale


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may09_date_  
`releases.edition_may09_date`

**English** — 9 May 2026

**Français** — 17 mai 2026


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may09_desc_  
`releases.edition_may09_desc`

**English** — <cite>Final May edition</cite>

**Français** — <cite>Édition finale de mai</cite>


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may09_meta_  
`releases.edition_may09_meta`

**English** — Signed snapshot · Earlier release

**Français** — Instantané signé · Édition précédente


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may17_date_  
`releases.edition_may17_date`

**English** — 19 May 2026

**Français** — 19 mai 2026


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may17_desc_  
`releases.edition_may17_desc`

**English** — <cite>Editorial cohesion</cite>

**Français** — <cite>Cohérence éditoriale</cite>


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may17_meta_  
`releases.edition_may17_meta`

**English** — Signed snapshot · Previous release

**Français** — Instantané signé · Édition actuelle


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may19_date_  
`releases.edition_may19_date`

**English** — 19 May 2026


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may19_desc_  
`releases.edition_may19_desc`

**English** — <cite>Bilingual editions</cite>


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · edition_may19_meta_  
`releases.edition_may19_meta`

**English** — Signed snapshot · Current release


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · editions_heading_  
`releases.editions_heading`

**English** — Editions

**Français** — Éditions


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · group_  
`releases.group.archive`

**English** — Archive

**Français** — Archives


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · group_  
`releases.group.current`

**English** — Current release

**Français** — Édition actuelle


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · page_title_  
`releases.page_title`

**English** — Releases

**Français** — Versions


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.card.01.body`

**English** — Final May edition. Signed source archives, deterministic ZIP and TAR.GZ, aggregated SHA256SUMS. Clean active filenames. One-page print profile. Trust sheets.

**Français** — Édition finale Signifier, Söhne, Söhne Mono. Noms de fichiers actifs propres. Profil imprimé d’une page. Fiches de confiance.


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.card.01.label`

**English** — 01 9 May 2026

**Français** — 01 Mai 2026


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.card.01.title`

**English** — 9 May 2026

**Français** — Mai 2026


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.card.02.body`

**English** — Initial signed release. Earlier visual system. Preserved as a historical archive.

**Français** — Première version signée. Système visuel antérieur. Préservée comme archive historique.


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.card.02.label`

**English** — 02 February 2026

**Français** — 02 Février 2026


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.card.02.title`

**English** — February 2026

**Français** — Février 2026


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.card.03.body`

**English** — Frozen assets. Local CSS and fonts. No live mutable style dependency.

**Français** — Ressources figées. CSS et polices locales. Aucune dépendance de style mutable en direct.


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.card.03.label`

**English** — 03 Archive principle

**Français** — 03 Principe d’archive


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.card.03.title`

**English** — Archive principle

**Français** — Principe d’archive


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.card.04.body`

**English** — /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc

**Français** — /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.card.04.label`

**English** — 04 Integrity route

**Français** — 04 Voie d’intégrité


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.card.04.title`

**English** — Integrity route

**Français** — Voie d’intégrité


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.card.05.body`

**English** — Verifiability. Authorship. Continuity. Public trust.

**Français** — Vérifiabilité. Auteur. Continuité. Confiance publique.


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.card.05.label`

**English** — 05 Why it matters

**Français** — 05 Pourquoi


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.card.05.title`

**English** — Why it matters

**Français** — Pourquoi


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.card.06.body`

**English** — /integrity/releases/2026-05-17/ · /integrity/releases/2026-05-09/ · /integrity/releases/2026-02/ · /source/

**Français** — /integrity/releases/2026-05-17/ · /integrity/releases/2026-05-09/ · /integrity/releases/2026-02/ · /source/


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.card.06.label`

**English** — 06 Where to inspect

**Français** — 06 Où inspecter


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.card.06.title`

**English** — Where to inspect

**Français** — Où inspecter


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.doc_title`

**English** — Trent Power - Release Archive Sheet

**Français** — Trent Power - Archive des versions


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · print_  
`releases.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/integrity/releases/

**Français** — Édition 2026-05-19 · trentpower.fr/integrity/releases/


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · print_  
`releases.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Releases index · print_  
`releases.print.kicker`

**English** — Releases

**Français** — Versions


<sub>source · `editorial copy register`</sub>


_BODY · Releases index · print_  
`releases.print.lede`

**English** — Public release snapshots preserve selected editions of the site with local assets so their design and integrity can be inspected over time.

**Français** — Les instantanés de versions publiques préservent des éditions choisies du site avec des ressources locales afin que leur conception et leur intégrité puissent être inspectées dans le temps.


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · print_  
`releases.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/integrity/releases/

**Français** — Édition 2026-05-19 · trentpower.fr/integrity/releases/


<sub>source · `editorial copy register`</sub>


_LABEL · Releases index · print_  
`releases.print.qr.label`

**English** — trentpower.fr/integrity/releases/

**Français** — trentpower.fr/integrity/releases/


<sub>source · `editorial copy register`</sub>


_TITLE · Releases index · print_  
`releases.print.title`

**English** — Frozen public editions

**Français** — Éditions publiques figées


<sub>source · `editorial copy register`</sub>


_STRING · Releases index · view_release_  
`releases.view_release`

**English** — View release

**Français** — Voir l’édition


<sub>source · `editorial copy register`</sub>


---

## Part 06 · Security & Acknowledgements

_110 entries._

_BODY · Security acknowledgements · body_intro_  
`acknowledgments.body_intro`

**English** — This page records responsible security disclosures that have been verified and resolved.

**Français** — Cette page recense les divulgations de sécurité responsables qui ont été vérifiées et résolues.


<sub>source · `editorial copy register`</sub>


_STRING · Security acknowledgements · integrity_link_  
`acknowledgments.integrity_link`

**English** — Site integrity statement

**Français** — Déclaration d’intégrité du site


<sub>source · `editorial copy register`</sub>


_STRING · Security acknowledgements · none_  
`acknowledgments.none`

**English** — There are no acknowledgements at present. This reflects the absence of reportable disclosures to date, not the absence of review or maintenance.

**Français** — Il n’y a pas de mentions pour le moment. Cela reflète l’absence de divulgations signalables à ce jour, et non l’absence de révision ou de maintenance.


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · page_title_  
`acknowledgments.page_title`

**English** — Security acknowledgements

**Français** — Mentions de sécurité


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.01.body`

**English** — Coordinated, time-bounded, with credit on request.

**Français** — Coordonné, à délai défini, crédit sur demande.


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.01.label`

**English** — 01 Disclosure model

**Français** — 01 Modèle de divulgation


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.01.title`

**English** — Disclosure model

**Français** — Modèle de divulgation


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.02.body`

**English** — trent@trentpower.fr · PGP-signed reports preferred · public key at /.well-known/pgp-key.asc.

**Français** — trent@trentpower.fr · rapports signés PGP préférés · clé publique sur /.well-known/pgp-key.asc.


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.02.label`

**English** — 02 Reporting policy

**Français** — 02 Politique de signalement


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.02.title`

**English** — Reporting policy

**Français** — Politique de signalement


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.03.body`

**English** — Acknowledge within 72 hours. Patch, verify, publish notes if material.

**Français** — Accusé de réception sous 72 heures. Correctif, vérification, notes publiques si nécessaire.


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.03.label`

**English** — 03 Coordinated remediation

**Français** — 03 Remédiation coordonnée


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.03.title`

**English** — Coordinated remediation

**Français** — Remédiation coordonnée


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.04.body`

**English** — Reproduce, hash, sign, and record in the next signed release.

**Français** — Reproduction, empreinte, signature, et consignation dans la prochaine version signée.


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.04.label`

**English** — 04 Verification process

**Français** — 04 Processus de vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.04.title`

**English** — Verification process

**Français** — Processus de vérification


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.05.body`

**English** — trent@trentpower.fr · fingerprint A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.

**Français** — trent@trentpower.fr · empreinte A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.05.label`

**English** — 05 Security contact

**Français** — 05 Contact sécurité


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.05.title`

**English** — Security contact

**Français** — Contact sécurité


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.06.body`

**English** — Acknowledgement page is the canonical record; updates accompany each signed edition.

**Français** — La page de reconnaissances est le registre canonique ; mises à jour à chaque édition signée.


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.06.label`

**English** — 06 Publication status

**Français** — 06 Statut de publication


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.06.title`

**English** — Publication status

**Français** — Statut de publication


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.doc_title`

**English** — Trent Power - Security Acknowledgments

**Français** — Trent Power - Reconnaissances de sécurité


<sub>source · `editorial copy register`</sub>


_STRING · Security acknowledgements · print_  
`acknowledgments.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/security/acknowledgments/

**Français** — Édition 2026-05-19 · trentpower.fr/security/acknowledgments/


<sub>source · `editorial copy register`</sub>


_STRING · Security acknowledgements · print_  
`acknowledgments.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Security acknowledgements · print_  
`acknowledgments.print.kicker`

**English** — Security acknowledgments

**Français** — Reconnaissances de sécurité


<sub>source · `editorial copy register`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.lede`

**English** — Acknowledgements for individuals and researchers who contributed responsibly to the security posture of this site.

**Français** — Reconnaissances pour les personnes et les chercheurs ayant contribué de manière responsable à la posture de sécurité de ce site.


<sub>source · `editorial copy register`</sub>


_STRING · Security acknowledgements · print_  
`acknowledgments.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/security/acknowledgments/

**Français** — Édition 2026-05-19 · trentpower.fr/security/acknowledgments/


<sub>source · `editorial copy register`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.qr.label`

**English** — trentpower.fr/security/acknowledgments/

**Français** — trentpower.fr/security/acknowledgments/


<sub>source · `editorial copy register`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.title`

**English** — Responsible disclosure record

**Français** — Registre des divulgations responsables


<sub>source · `editorial copy register`</sub>


_STRING · Security acknowledgements · report_  
`acknowledgments.report`

**English** — If you believe you have found a security issue with this site, please report it responsibly. Contact details and disclosure preferences are listed in security.txt.

**Français** — Si vous pensez avoir trouvé un problème de sécurité sur ce site, veuillez le signaler de manière responsable. Les coordonnées et les préférences de divulgation sont indiquées dans security.txt.


<sub>source · `editorial copy register`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.archive_body`

**English** — Frozen signed releases

**Français** — Instantanés signés et figés


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.archive_label`

**English** — Archive

**Français** — Archive


<sub>source · `editorial copy register`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.browser_body`

**English** — <abbr title="HyperText Transfer Protocol Secure">HTTPS</abbr> · no cookies · no analytics

**Français** — <abbr title="HyperText Transfer Protocol Secure">HTTPS</abbr> · ni cookies ni analyses


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.browser_label`

**English** — Browser

**Français** — Navigateur


<sub>source · `editorial copy register`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.cache_body`

**English** — Service worker · local cache after first visit

**Français** — Service worker · cache local dès la première visite


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.cache_label`

**English** — Offline cache

**Français** — Cache hors-ligne


<sub>source · `editorial copy register`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.files_body`

**English** — <abbr title="HyperText Markup Language">HTML</abbr> · <abbr title="Cascading Style Sheets">CSS</abbr> · vanilla JS · self-hosted fonts

**Français** — <abbr title="HyperText Markup Language">HTML</abbr> · <abbr title="Cascading Style Sheets">CSS</abbr> · JavaScript natif · polices auto-hébergées


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.files_label`

**English** — Site files

**Français** — Fichiers du site


<sub>source · `editorial copy register`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.host_body`

**English** — Apache · Gandi · Paris · <abbr title="Secure File Transfer Protocol">SFTP</abbr> deployment

**Français** — Apache · Gandi · Paris · déploiement <abbr title="Secure File Transfer Protocol">SFTP</abbr>


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.host_label`

**English** — Static host

**Français** — Hébergement statique


<sub>source · `editorial copy register`</sub>


_KICKER · Security page · architecture_card_  
`security.architecture_card.kicker`

**English** — Architecture

**Français** — Architecture


<sub>source · `editorial copy register`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.trust_body`

**English** — Integrity · Verify · Source · Releases

**Français** — Intégrité · Vérification · Source · Éditions


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.trust_label`

**English** — Trust

**Français** — Confiance


<sub>source · `editorial copy register`</sub>


_BODY · Security page · body_intro_  
`security.body_intro`

**English** — How this site is hosted, what it protects, what it doesn't - and how anyone can verify it independently.

**Français** — Comment ce site est hébergé, ce qu’il protège, ce qu’il ne protège pas - et comment chacun peut le vérifier indépendamment.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · page_h1_  
`security.page_h1`

**English** — <span class="hero-line">Static.</span><span class="hero-line">Self-managed.</span><span class="hero-line">Verification-led.</span>

**Français** — <span class="hero-line">Statique.</span><span class="hero-line">Auto-hébergé.</span><span class="hero-line">Vérifiable.</span>


<sub>source · `editorial copy register`</sub>


_KICKER · Security page · page_kicker_  
`security.page_kicker`

**English** — Security & Threat Model

**Français** — Sécurité et modèle de menace


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · page_title_  
`security.page_title`

**English** — Security & Threat Model

**Français** — Sécurité & modèle de menace


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.card.01.body`

**English** — Static HTML, CSS, vanilla JavaScript. Self-managed deployment on Apache (Gandi, Paris). No public database.

**Français** — HTML, CSS, JavaScript natif. Déploiement auto-géré sur Apache (Gandi, Paris). Aucune base de données publique.


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.card.01.label`

**English** — 01 Architecture

**Français** — 01 Architecture


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.card.01.title`

**English** — Architecture

**Français** — Architecture


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.card.02.body`

**English** — <abbr title="Content Security Policy">CSP</abbr> default-deny. <abbr title="HTTP Strict Transport Security">HSTS</abbr>. <abbr title="Cross-Origin Opener Policy">COOP</abbr> / <abbr title="Cross-Origin Embedder Policy">COEP</abbr> / <abbr title="Cross-Origin Resource Policy">CORP</abbr>. Referrer-Policy no-referrer. Locked-down Permissions-Policy.

**Français** — <abbr title="Content Security Policy">CSP</abbr> par défaut deny. <abbr title="HTTP Strict Transport Security">HSTS</abbr>. <abbr title="Cross-Origin Opener Policy">COOP</abbr> / <abbr title="Cross-Origin Embedder Policy">COEP</abbr> / <abbr title="Cross-Origin Resource Policy">CORP</abbr>. Referrer-Policy no-referrer. Permissions-Policy verrouillée.


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.card.02.label`

**English** — 02 Headers

**Français** — 02 En-têtes


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.card.02.title`

**English** — Security headers

**Français** — En-têtes de sécurité


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.card.03.body`

**English** — Identity. Published content. Public verification files. Source integrity.

**Français** — Identité. Contenu publié. Fichiers de vérification publics. Intégrité du code source.


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.card.03.label`

**English** — 03 Assets protected

**Français** — 03 Actifs protégés


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.card.03.title`

**English** — Assets protected

**Français** — Actifs protégés


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.card.04.body`

**English** — Content injection. Hosting credential compromise. Spoofed identity. Stale or tampered files.

**Français** — Injection de contenu. Compromission des identifiants d’hébergement. Usurpation d’identité. Fichiers obsolètes ou altérés.


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.card.04.label`

**English** — 04 Threat model

**Français** — 04 Modèle de menaces


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.card.04.title`

**English** — Threat model

**Français** — Modèle de menaces


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.card.05.body`

**English** — No third-party scripts. No public forms. Signed integrity manifest. Restricted file exposure. Service-worker-controlled cache.

**Français** — Aucun script tiers. Aucun formulaire public. Manifeste d’intégrité signé. Exposition de fichiers restreinte. Cache piloté par service worker.


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.card.05.label`

**English** — 05 Controls

**Français** — 05 Contrôles


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.card.05.title`

**English** — Controls

**Français** — Contrôles


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.card.06.body`

**English** — Hosting and registrar risk remain. Static-site exposure is reduced, not eliminated. Responsible disclosure route is published.

**Français** — Le risque hébergeur et registrar demeure. L’exposition d’un site statique est réduite, pas éliminée. Voie de divulgation responsable publiée.


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.card.06.label`

**English** — 06 Residual risk

**Français** — 06 Risque résiduel


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.card.06.title`

**English** — Residual risk

**Français** — Risque résiduel


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.doc_title`

**English** — Trent Power - Security Threat Model Sheet

**Français** — Trent Power - Profil sécurité


<sub>source · `editorial copy register`</sub>


_STRING · Security page · print_  
`security.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/security/

**Français** — Édition 2026-05-19 · trentpower.fr/security/


<sub>source · `editorial copy register`</sub>


_STRING · Security page · print_  
`security.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Security page · print_  
`security.print.kicker`

**English** — Security & Threat Model

**Français** — Sécurité & modèle de menace


<sub>source · `editorial copy register`</sub>


_BODY · Security page · print_  
`security.print.lede`

**English** — The public site is static HTML, CSS and vanilla JavaScript, with strict headers, no runtime server logic, no public database and no third-party scripts.

**Français** — Le site public est composé de HTML, CSS et JavaScript natif, avec des en-têtes stricts, aucune logique serveur à l’exécution, aucune base de données publique et aucun script tiers.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · print_  
`security.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/security/

**Français** — Édition 2026-05-19 · trentpower.fr/security/


<sub>source · `editorial copy register`</sub>


_LABEL · Security page · print_  
`security.print.qr.label`

**English** — trentpower.fr/security/

**Français** — trentpower.fr/security/


<sub>source · `editorial copy register`</sub>


_TITLE · Security page · print_  
`security.print.title`

**English** — Static, self-managed, verification-led

**Français** — Statique, auto-géré, axé sur la vérification


<sub>source · `editorial copy register`</sub>


_STRING · Security page · public_verification_footer_  
`security.public_verification_footer`

**English** — These routes support inspection and provenance. They do not remove the need to protect <abbr title="Domain Name System">DNS</abbr>, hosting credentials and the private signing key.

**Français** — Ces routes facilitent l'inspection et la provenance. Elles ne suppriment pas la nécessité de protéger le <abbr title="Domain Name System">DNS</abbr>, les identifiants d'hébergement et la clé privée de signature.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · public_verification_intro_  
`security.public_verification_intro`

**English** — The site exposes public inspection routes so published content can be checked without private infrastructure access.

**Français** — Le site expose des routes d'inspection publique pour que le contenu publié puisse être contrôlé sans accès à l'infrastructure privée.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · public_verification_list_  
`security.public_verification_list`

**English** — <a href="/integrity/" aria-label="Open the integrity archive for signed releases, public key and manifest"><code>/integrity/</code></a> records signed releases, public key and manifest<br><a href="/verify/" aria-label="Open the page verification tool for canonical URLs, source mirrors and fingerprints"><code>/verify/</code></a> records one page’s canonical <abbr title="Uniform Resource Locator">URL</abbr>, source mirror and fingerprint<br><a href="/source/" aria-label="Open readable source mirrors of selected public files"><code>/source/</code></a> publishes readable mirrors of selected public files<br><a href="/integrity/releases/" aria-label="Open frozen signed release snapshots"><code>/integrity/releases/</code></a> preserves frozen signed snapshots

**Français** — <a href="/integrity/" aria-label="Ouvrir l’archive d’intégrité des publications signées, de la clé publique et du manifeste"><code>/integrity/</code></a> recense les éditions signées, la clé publique et le manifeste<br><a href="/verify/" aria-label="Ouvrir l’outil de vérification des URL canoniques, miroirs source et empreintes de page"><code>/verify/</code></a> recense l'<abbr title="Uniform Resource Locator">URL</abbr> canonique d'une page, son miroir source et son empreinte<br><a href="/source/" aria-label="Ouvrir les miroirs lisibles du code source de certains fichiers publics"><code>/source/</code></a> publie les miroirs lisibles d'une sélection de fichiers publics<br><a href="/integrity/releases/" aria-label="Ouvrir les instantanés figés et signés des publications"><code>/integrity/releases/</code></a> conserve les instantanés signés et figés


<sub>source · `editorial copy register`</sub>


_STRING · Security page · public_verification_summary_  
`security.public_verification_summary`

**English** — 5. Public verification surface

**Français** — 5. Surface de vérification publique


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s1_routes_note_  
`security.s1_routes_note`

**English** — Public inspection routes expose the signed manifest, page records, readable source mirrors and archived releases without exposing private infrastructure.

**Français** — Les routes d'inspection publiques exposent le manifeste signé, les enregistrements de page, les miroirs source lisibles et les éditions archivées sans exposer l'infrastructure privée.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s1_summary_  
`security.s1_summary`

**English** — 1. Architecture

**Français** — 1. Architecture


<sub>source · `editorial copy register`</sub>


_BODY · Security page · s2_body_  
`security.s2_body`

**English** — The controls described here protect:

**Français** — Les contrôles décrits ici protègent :


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s2_list_  
`security.s2_list`

**English** — Domain ownership<br>DNS integrity<br>Hosting account integrity<br>Public content integrity<br>The signing key used for release authenticity

**Français** — La propriété du domaine<br>L’intégrité DNS<br>L’intégrité du compte d’hébergement<br>L’intégrité du contenu public<br>La clé de signature utilisée pour l’authenticité des versions


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s2_summary_  
`security.s2_summary`

**English** — 2. Assets protected

**Français** — 2. Actifs protégés


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_admin_heading_  
`security.s3_admin_heading`

**English** — Administrative abuse

**Français** — Abus administratif


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_admin_list_  
`security.s3_admin_list`

**English** — Credential stuffing<br>Automated vulnerability scanning

**Français** — Credential stuffing<br>Analyse automatisée des vulnérabilités


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_content_heading_  
`security.s3_content_heading`

**English** — Content tampering

**Français** — Altération du contenu


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_content_list_  
`security.s3_content_list`

**English** — Post-deployment file modification<br>Malicious JavaScript injection<br>Silent alteration of static assets

**Français** — Modification de fichiers après déploiement<br>Injection de JavaScript malveillant<br>Altération silencieuse des ressources statiques


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_infra_heading_  
`security.s3_infra_heading`

**English** — Infrastructure compromise

**Français** — Compromission de l’infrastructure


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_infra_list_  
`security.s3_infra_list`

**English** — Registrar account takeover<br><abbr title="Domain Name System">DNS</abbr> hijack<br>Hosting credential compromise

**Français** — Prise de contrôle du compte registrar<br>Détournement <abbr title="Domain Name System">DNS</abbr><br>Compromission des identifiants d’hébergement


<sub>source · `editorial copy register`</sub>


_BODY · Security page · s3_noise_body_  
`security.s3_noise_body`

**English** — Continuous automated probing for common <abbr title="Content Management System">CMS</abbr> paths, configuration files, or known endpoints. These are treated as persistent background conditions rather than exceptional events.

**Français** — Sondage automatisé continu pour les chemins <abbr title="Content Management System">CMS</abbr> courants, les fichiers de configuration ou les points d’entrée connus. Ces éléments sont traités comme des conditions de fond persistantes plutôt que comme des événements exceptionnels.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_noise_heading_  
`security.s3_noise_heading`

**English** — Commodity internet noise

**Français** — Bruit internet courant


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s3_summary_  
`security.s3_summary`

**English** — 3. Threat model

**Français** — 3. Modèle de menace


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_content_heading_  
`security.s4_content_heading`

**English** — Public content

**Français** — Contenu public


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_content_list_  
`security.s4_content_list`

**English** — Static architecture reduces server-side attack surface<br>Strict <abbr title="Content Security Policy">CSP</abbr> starting from <code>default-src 'none'</code><br>No external resource loading<br>No dynamic script execution

**Français** — Architecture statique réduisant la surface d’attaque côté serveur<br><abbr title="Content Security Policy">CSP</abbr> stricte démarrant par <code>default-src 'none'</code><br>Aucun chargement de ressource externe<br>Aucune exécution de script dynamique


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_hosting_heading_  
`security.s4_hosting_heading`

**English** — Hosting

**Français** — Hébergement


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_hosting_list_  
`security.s4_hosting_list`

**English** — Multi-factor authentication enabled<br><abbr title="Secure File Transfer Protocol">SFTP</abbr>-only deployment<br>No <abbr title="Secure Shell">SSH</abbr> shell exposure<br>No scheduled background execution

**Français** — Authentification multi-facteurs activée<br>Déploiement <abbr title="Secure File Transfer Protocol">SFTP</abbr> uniquement<br>Aucune exposition <abbr title="Secure Shell">SSH</abbr> shell<br>Aucune exécution en arrière-plan planifiée


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_monitoring_heading_  
`security.s4_monitoring_heading`

**English** — Monitoring

**Français** — Surveillance


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_monitoring_list_  
`security.s4_monitoring_list`

**English** — Structured log analysis<br>Pattern detection and anomaly scoring<br>File integrity drift detection against the signed release baseline

**Français** — Analyse structurée des journaux<br>Détection de patterns et scoring des anomalies<br>Détection de dérive d’intégrité des fichiers par rapport à la base de référence signée


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_registrar_heading_  
`security.s4_registrar_heading`

**English** — Registrar &amp; <abbr title="Domain Name System">DNS</abbr>

**Français** — Registrar &amp; <abbr title="Domain Name System">DNS</abbr>


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_registrar_list_  
`security.s4_registrar_list`

**English** — <abbr title="Multi-Factor Authentication">MFA</abbr> enabled<br>Registrar lock active<br><abbr title="Domain Name System Security Extensions">DNSSEC</abbr> enabled and validated<br><abbr title="Certificate Authority Authorization">CAA</abbr> records restrict certificate issuance

**Français** — <abbr title="Multi-Factor Authentication">MFA</abbr> activée<br>Verrouillage du registrar actif<br><abbr title="Domain Name System Security Extensions">DNSSEC</abbr> activé et validé<br>Enregistrements <abbr title="Certificate Authority Authorization">CAA</abbr> restreignant l’émission de certificats


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s4_summary_  
`security.s4_summary`

**English** — 4. Controls

**Français** — 4. Contrôles


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s6_footer_  
`security.s6_footer`

**English** — The main risks remain domain, <abbr title="Domain Name System">DNS</abbr>, hosting and private key compromise.

**Français** — Les risques principaux restent la compromission du domaine, du <abbr title="Domain Name System">DNS</abbr>, de l'hébergement et de la clé de signature privée.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s6_intro_  
`security.s6_intro`

**English** — This model does not attempt to address:

**Français** — Ce modèle ne tente pas de traiter :


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s6_list_  
`security.s6_list`

**English** — Physical compromise of hosting infrastructure<br>Global <abbr title="Domain Name System">DNS</abbr> root compromise<br>Certificate authority (<abbr title="Certificate Authority">CA</abbr>) compromise<br>State-level adversaries<br>Zero-day browser exploits on client devices

**Français** — Compromission physique de l’infrastructure d’hébergement<br>Compromission de la racine <abbr title="Domain Name System">DNS</abbr> mondiale<br>Compromission d’une autorité de certification (<abbr title="Certificate Authority">CA</abbr>)<br>Adversaires étatiques<br>Exploits navigateur zero-day sur les appareils clients


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s6_protect_summary_  
`security.s6_protect_summary`

**English** — This model protects the public static site. It does not protect against registrar compromise, hosting compromise, client-device compromise or private key compromise.

**Français** — Ce modèle protège le site statique public. Il ne protège pas contre la compromission du bureau d’enregistrement, de l’hébergement, des appareils clients ou de la clé privée.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s6_summary_  
`security.s6_summary`

**English** — 6. Residual risk

**Français** — 6. Risque résiduel


<sub>source · `editorial copy register`</sub>


_BODY · Security page · s7_body_  
`security.s7_body`

**English** — Responsible disclosure is welcome. Security contact details and encrypted communication instructions are published at <a href="/.well-known/security.txt" aria-describedby="desc-security-contact"><code>/.well-known/security.txt</code></a>.

**Français** — La divulgation responsable est la bienvenue. Les coordonnées de sécurité et les instructions de communication chiffrée sont publiées sur <a href="/.well-known/security.txt" aria-describedby="desc-security-contact"><code>/.well-known/security.txt</code></a>.


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s7_summary_  
`security.s7_summary`

**English** — 7. Disclosure

**Français** — 7. Divulgation


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s8_list_  
`security.s8_list`

**English** — Simplicity over complexity<br>Deterministic behaviour over dynamic systems<br>Transparency over obscurity<br>Verifiable integrity over trust assumptions

**Français** — Simplicité plutôt que complexité<br>Comportement déterministe plutôt que systèmes dynamiques<br>Transparence plutôt qu’obscurité<br>Intégrité vérifiable plutôt qu’hypothèses de confiance


<sub>source · `editorial copy register`</sub>


_STRING · Security page · s8_summary_  
`security.s8_summary`

**English** — 8. Design principles

**Français** — 8. Principes de conception


<sub>source · `editorial copy register`</sub>


---

## Part 07 · Source & Verification

_190 entries._

_STRING · Source page · col_  
`source.col.validated`

**English** — Verified

**Français** — Vérifié


<sub>source · `editorial copy register`</sub>


_STRING · Source page · curation_note_  
`source.curation_note`

**English** — This index shows the principal public mirrors. Additional mirrored files may remain available by direct URL where they support verification, recovery, or release integrity.

**Français** — Cet index présente les principaux miroirs publics. D’autres fichiers miroirs peuvent rester accessibles par URL directe lorsqu’ils soutiennent la vérification, la récupération ou l’intégrité des versions publiées.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · download_checksums_  
`source.download_checksums`

**English** — Checksums

**Français** — Sommes de contrôle


<sub>source · `editorial copy register`</sub>


_BODY · Source page · download_lede_  
`source.download_lede`

**English** — Download the public source archive for the current edition

**Français** — Télécharger l’archive source publique de l’édition courante


<sub>source · `editorial copy register`</sub>


_STRING · Source page · download_targz_  
`source.download_targz`

**English** — TAR.GZ

**Français** — TAR.GZ


<sub>source · `editorial copy register`</sub>


_STRING · Source page · download_zip_  
`source.download_zip`

**English** — ZIP

**Français** — ZIP


<sub>source · `editorial copy register`</sub>


_STRING · Source page · editions_  
`source.editions.eyebrow`

**English** — Editions

**Français** — Éditions


<sub>source · `editorial copy register`</sub>


_STRING · Source page · editions_  
`source.editions.note.current`

**English** — Current signed release

**Français** — Édition signée en cours


<sub>source · `editorial copy register`</sub>


_STRING · Source page · editions_  
`source.editions.note.earlier`

**English** — Earlier signed release

**Français** — Édition signée antérieure


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · editions_  
`source.editions.title`

**English** — Edition lineage

**Français** — Lignée des éditions


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.403_html_txt.description`

**English** — Forbidden page.

**Français** — Page interdite.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.404_html_txt.description`

**English** — Not found page.

**Français** — Page introuvable.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.500_html_txt.description`

**English** — Server error page.

**Français** — Page d'erreur serveur.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.ai_usage_txt_txt.description`

**English** — Statement of AI usage and policy for the site.

**Français** — Déclaration sur l'usage de l'IA et politique pour le site.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.app_enhance_js_txt.description`

**English** — Progressive enhancement layer. Non-essential interactions, gracefully optional.

**Français** — Couche d'amélioration progressive. Interactions non essentielles, gracieusement optionnelles.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.app_js_txt.description`

**English** — Authored runtime script. Navigation, language switch, citation drawer wiring.

**Français** — Script d'exécution écrit à la source. Navigation, changement de langue, câblage du tiroir de citation.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.assertion_txt_txt.description`

**English** — Authorship assertion. Declaration of authorship and integrity intent.

**Français** — Affirmation d'auteur. Déclaration d'auteur et d'intention d'intégrité.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.attestations_json_txt.description`

**English** — Public attestations. Verifiable claims about the site.

**Français** — Attestations publiques. Revendications vérifiables sur le site.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.changelog_txt_txt.description`

**English** — Edition change log. Notable revisions to the public site.

**Français** — Journal des éditions. Révisions notables du site public.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.cite_js_txt.description`

**English** — Cite-and-verify drawer. Surfaces canonical URL, page fingerprint and signature.

**Français** — Tiroir de citation et vérification. Expose l'URL canonique, l'empreinte de la page et la signature.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.fonts_full_css_txt.description`

**English** — Webfont declarations. Subsets, formats and fallbacks.

**Français** — Déclarations de polices web. Sous-ensembles, formats et fallbacks.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.htaccess_txt.description`

**English** — Apache configuration. Public-safety scanned before mirroring.

**Français** — Configuration Apache. Vérifiée contre toute fuite avant publication.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.humans_txt_txt.description`

**English** — Credits and notes for the people behind the site.

**Français** — Crédits et notes pour les personnes derrière le site.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_core_js_txt.description`

**English** — Editorial translation source. All five languages in one authored JSON.

**Français** — Source éditoriale des traductions. Les cinq langues réunies dans un JSON unique.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_de_js_txt.description`

**English** — German translations.

**Français** — Traductions allemandes.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_es_js_txt.description`

**English** — Spanish translations.

**Français** — Traductions espagnoles.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_it_js_txt.description`

**English** — Italian translations. Deployed compact bytes.

**Français** — Traductions italiennes. Octets compacts déployés.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.index_html_txt.description`

**English** — Home page. The editorial entry point.

**Français** — Page d'accueil. Le point d'entrée éditorial.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_index_html_txt.description`

**English** — Integrity overview. The signed manifest, key and release authority.

**Français** — Vue d'ensemble de l'intégrité. Le manifeste signé, la clé et l'autorité de publication.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_releases_2026_05_09_index_html_txt.description`

**English** — Frozen page record for the 2026-05-09 edition.

**Français** — Fiche figée de la page pour l'édition 2026-05-09.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_releases_archive_css_txt.description`

**English** — Stylesheet used inside frozen release archives. Held alongside its release records.

**Français** — Feuille de style utilisée dans les archives d'éditions figées. Conservée auprès de ses fiches d'édition.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_releases_index_html_txt.description`

**English** — Release index. The list of signed editions.

**Français** — Index des éditions. La liste des éditions signées.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.llms_txt_txt.description`

**English** — Machine-readable guidance for language models and AI systems.

**Français** — Indications lisibles par machine pour les modèles de langage et systèmes d'IA.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.maintenance_html_txt.description`

**English** — Maintenance notice. Used during planned downtime.

**Français** — Avis de maintenance. Utilisé lors d'une interruption planifiée.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.manifest_webmanifest_txt.description`

**English** — Web app manifest. Installable surface metadata.

**Français** — Manifeste d'application web. Métadonnées de la surface installable.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.pgp_txt_txt.description`

**English** — PGP statement. The signing key fingerprint and its use.

**Français** — Déclaration PGP. Empreinte de la clé de signature et son usage.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.print_css_txt.description`

**English** — Print stylesheet. Layout rules for paper output.

**Français** — Feuille de style d'impression. Règles de mise en page pour le rendu papier.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.privacy_index_html_txt.description`

**English** — Privacy statement. What is collected, retained and shared.

**Français** — Déclaration de confidentialité. Ce qui est collecté, conservé et partagé.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.readme_txt.description`

**English** — Orientation note for the source tree. Same text shipped at the root of every release archive.

**Français** — Note d'orientation pour l'arborescence source. Même texte livré à la racine de chaque archive d'édition.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.robots_txt_txt.description`

**English** — Crawler access policy and public indexing intent.

**Français** — Politique d'accès des robots et intention d'indexation publique.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.security_acknowledgments_index_html_txt.description`

**English** — Acknowledgments for public security disclosures.

**Français** — Remerciements pour les signalements de sécurité publics.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.security_index_html_txt.description`

**English** — Security posture. Architecture, headers and disclosure path.

**Français** — Posture de sécurité. Architecture, en-têtes et voie de signalement.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.site_metadata_json_txt.description`

**English** — Site-level metadata. Edition, build, asset version.

**Français** — Métadonnées du site. Édition, compilation, version des ressources.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sitemap_xml_sha256_txt.description`

**English** — Source mirror of the SHA-256 checksum for sitemap.xml.

**Français** — Miroir source de la somme de contrôle SHA-256 pour sitemap.xml.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sitemap_xml_txt.description`

**English** — Public sitemap. URL inventory for crawlers.

**Français** — Plan du site public. Inventaire d'URL pour les robots d'indexation.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.source_manifest_json_txt.description`

**English** — Manifest of the /source/ tree itself. Every mirrored file with its hash.

**Français** — Manifeste de l'arborescence /source/ elle-même. Chaque fichier miroir avec son empreinte.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.statement_txt_txt.description`

**English** — Editorial statement. The site's authoring principles.

**Français** — Déclaration éditoriale. Les principes d'écriture du site.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.styles_css_txt.description`

**English** — Authored stylesheet. Mirrored from source, not the minified deployed bytes.

**Français** — Feuille de style écrite à la source. Miroir de la source, non des octets minifiés déployés.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sw_cache_manifest_json_txt.description`

**English** — Service worker cache manifest. Files pinned for offline use.

**Français** — Manifeste de cache du service worker. Fichiers épinglés pour usage hors ligne.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sw_js_txt.description`

**English** — Service worker. Offline cache for the public site.

**Français** — Service worker. Cache hors ligne du site public.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sw_reset_index_html_txt.description`

**English** — Service worker reset. Clears the offline cache.

**Français** — Réinitialisation du service worker. Vide le cache hors ligne.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.verify_index_html_txt.description`

**English** — Verification interface. Page-level fingerprint checks.

**Français** — Interface de vérification. Contrôles d'empreinte au niveau de la page.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.verify_verify_js_txt.description`

**English** — Verification logic. Renders a page record from the verification map.

**Français** — Logique de vérification. Rend une fiche de page à partir de la carte de vérification.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_attribution_txt_txt.description`

**English** — Author attribution. Names the responsible party for the public site.

**Français** — Attribution d'auteur. Nomme la partie responsable du site public.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_build_json_txt.description`

**English** — Build record. Reproducibility data for the current edition.

**Français** — Fiche de compilation. Données de reproductibilité de l'édition courante.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_person_json_txt.description`

**English** — Machine-readable identity in JSON-LD. The reference used by discovery, federation and verification.

**Français** — Identité lisible par machine en JSON-LD. La référence utilisée par la découverte, la fédération et la vérification.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · files_  
`source.files.well_known_person_json_txt.role`

**English** — Canonical identity record

**Français** — Fiche d'identité canonique


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_pgp_key_asc_txt.description`

**English** — ASCII-armoured public signing key. The publisher's signing identity.

**Français** — Clé publique de signature en ASCII-armor. L'identité de signature de l'auteur.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_publication_json_txt.description`

**English** — Publication record. Describes the site as a self-managed editorial work.

**Français** — Fiche de publication. Décrit le site comme un ouvrage éditorial auto-géré.


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_security_txt_txt.description`

**English** — Coordinated disclosure policy. Standard /.well-known/security.txt contact and scope.

**Français** — Politique de divulgation coordonnée. Contact et périmètre standard /.well-known/security.txt.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · files_  
`source.files.well_known_security_txt_txt.role`

**English** — Public trust surface

**Français** — Surface de confiance publique


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_webfinger_txt.description`

**English** — WebFinger discovery surface. Resolves identity across federated protocols.

**Français** — Surface de découverte WebFinger. Résout l'identité à travers les protocoles fédérés.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · files_  
`source.files.well_known_webfinger_txt.role`

**English** — Identity discovery

**Français** — Découverte d'identité


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_  
`source.group.metadata`

**English** — Metadata

**Français** — Métadonnées


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_  
`source.group.published-pages`

**English** — Published pages

**Français** — Pages publiées


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_  
`source.group.scripts`

**English** — Scripts

**Français** — Scripts


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_  
`source.group.trust-records`

**English** — Trust records

**Français** — Fiches de confiance


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.metadata`

**English** — Server configuration and machine-readable records describing the site to crawlers, indexers and language models.

**Français** — Configuration serveur et fiches lisibles par machine décrivant le site aux robots d'indexation et aux modèles de langage.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.published-pages`

**English** — Readable mirrors of the principal public pages, served as plain text so the bytes can be inspected without execution.

**Français** — Miroirs lisibles des principales pages publiques, servis en texte brut afin que les octets puissent être inspectés sans exécution.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.scripts`

**English** — Authored stylesheets and JavaScript the page ships to the browser. Mirrored from source, not the minified deployed bytes.

**Français** — Feuilles de style et JavaScript écrits à la source que la page envoie au navigateur. Miroirs de la source, non des octets minifiés déployés.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.trust-records`

**English** — Public commitments and identity surfaces. Who publishes the site, what is promised, where disclosure runs.

**Français** — Engagements publics et surfaces d'identité. Qui publie le site, ce qui est promis, où passent les signalements.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · heading_  
`source.heading`

**English** — <span class="hero-line">Every public byte,</span><span class="hero-line">in plain text.</span>

**Français** — <span class="hero-line">Chaque octet public,</span><span class="hero-line">en texte clair.</span>


<sub>source · `editorial copy register`</sub>


_BODY · Source page · intro_lede_  
`source.intro_lede`

**English** — Selected public files, published in readable form. For inspection, preservation, and machine readability.

**Français** — Fichiers publics sélectionnés, publiés sous forme lisible. Pour inspection, conservation et lecture machine.


<sub>source · `editorial copy register`</sub>


_KICKER · Source page · page_kicker_  
`source.page_kicker`

**English** — Source

**Français** — Code source


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.card.01.body`

**English** — HTML mirrors. CSS. JavaScript. Manifest files. .htaccess mirror.

**Français** — Miroirs HTML. CSS. JavaScript. Fichiers manifeste. Miroir .htaccess.


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.card.01.label`

**English** — 01 What is included

**Français** — 01 Ce qui est inclus


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.card.01.title`

**English** — What is included

**Français** — Ce qui est inclus


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.card.02.body`

**English** — Credentials. Private notes. Invoices. Backups. Generator internals unless explicitly public.

**Français** — Identifiants. Notes privées. Factures. Sauvegardes. Internes du générateur, sauf publication explicite.


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.card.02.label`

**English** — 02 What is excluded

**Français** — 02 Ce qui est exclu


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.card.02.title`

**English** — What is excluded

**Français** — Ce qui est exclu


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.card.03.body`

**English** — Sorted by file type, then name. Plain text mirrors. SHA-256 hashes. File sizes.

**Français** — Trié par type de fichier, puis par nom. Miroirs en texte brut. Empreintes SHA-256. Tailles de fichier.


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.card.03.label`

**English** — 03 How it is organised

**Français** — 03 Organisation


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.card.03.title`

**English** — How it is organised

**Français** — Organisation


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.card.04.body`

**English** — source-manifest.json · /integrity.json · detached signature · public key.

**Français** — source-manifest.json · /integrity.json · signature détachée · clé publique.


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.card.04.label`

**English** — 04 Verification

**Français** — 04 Vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.card.04.title`

**English** — Verification

**Français** — Vérification


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.card.05.body`

**English** — styles.css.txt · app.js.txt · print.css.txt · htaccess.txt · source-manifest.json

**Français** — styles.css.txt · app.js.txt · print.css.txt · htaccess.txt · source-manifest.json


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.card.05.label`

**English** — 05 Files of note

**Français** — 05 Fichiers notables


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.card.05.title`

**English** — Files of note

**Français** — Fichiers notables


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.card.06.body`

**English** — Human readers first. Machine-readable files preserve identity, authorship and context.

**Français** — Lecteurs humains d’abord. Les fichiers lisibles par machine préservent identité, auteur et contexte.


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.card.06.label`

**English** — 06 Principle

**Français** — 06 Principe


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.card.06.title`

**English** — Principle

**Français** — Principe


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.doc_title`

**English** — Trent Power - Public Source Sheet

**Français** — Trent Power - Vue source publique


<sub>source · `editorial copy register`</sub>


_STRING · Source page · print_  
`source.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/source/

**Français** — Édition 2026-05-19 · trentpower.fr/source/


<sub>source · `editorial copy register`</sub>


_STRING · Source page · print_  
`source.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Source page · print_  
`source.print.kicker`

**English** — Source

**Français** — Source


<sub>source · `editorial copy register`</sub>


_BODY · Source page · print_  
`source.print.lede`

**English** — Selected public files are mirrored as plain text so the site can be inspected from any reader, including mobile.

**Français** — Des fichiers publics sélectionnés sont copiés en texte brut afin que le site puisse être inspecté depuis n’importe quel lecteur, y compris mobile.


<sub>source · `editorial copy register`</sub>


_STRING · Source page · print_  
`source.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/source/

**Français** — Édition 2026-05-19 · trentpower.fr/source/


<sub>source · `editorial copy register`</sub>


_LABEL · Source page · print_  
`source.print.qr.label`

**English** — trentpower.fr/source/

**Français** — trentpower.fr/source/


<sub>source · `editorial copy register`</sub>


_TITLE · Source page · print_  
`source.print.title`

**English** — Public source view

**Français** — Vue source publique


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copied`

**English** — Copied

**Français** — Copié


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copy_canonical`

**English** — Copy URL

**Français** — Copier l’URL


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copy_command`

**English** — Copy verification command

**Français** — Copier la commande de vérification


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copy_fingerprint`

**English** — Copy fingerprint

**Français** — Copier l'empreinte


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copy_hash`

**English** — Copy hash

**Français** — Copier l’empreinte


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copy_manifest_command`

**English** — Copy manifest command

**Français** — Copier la commande manifeste


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.copy_source_command`

**English** — Copy source command

**Français** — Copier la commande source


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.open_key`

**English** — Open public key

**Français** — Ouvrir la clé publique


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.open_manifest`

**English** — Open manifest entry

**Français** — Ouvrir l’entrée du manifeste


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.open_signature`

**English** — Open signature

**Français** — Ouvrir la signature


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.open_source`

**English** — Open source mirror

**Français** — Ouvrir le miroir source


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.open_source_mirror`

**English** — Open mirror

**Français** — Ouvrir le miroir


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.view_source_code`

**English** — View source code

**Français** — Voir le code source


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · action_  
`verify.action.view_source_mirror`

**English** — View source mirror

**Français** — Voir le miroir source


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · chooser_  
`verify.chooser.heading`

**English** — Related records

**Français** — Documents liés


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.home`

**English** — Homepage

**Français** — Accueil


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.integrity`

**English** — Integrity

**Français** — Intégrité


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.privacy`

**English** — Privacy

**Français** — Confidentialité


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.releases`

**English** — Releases

**Français** — Éditions


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.security`

**English** — Security

**Français** — Sécurité


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.source`

**English** — Source

**Français** — Source


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.verify`

**English** — Verify

**Français** — Vérifier


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · command_  
`verify.command.manifest_title`

**English** — Verify the signed manifest

**Français** — Vérifier le manifeste signé


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · command_  
`verify.command.note`

**English** — The signed manifest verifies the published file set. The second command hashes the source mirror so it can be compared against the expected SHA-256 above.

**Français** — Le manifeste signé valide l’ensemble des fichiers publiés. La seconde commande calcule l’empreinte du miroir source pour la comparer au SHA-256 attendu ci-dessus.


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · command_  
`verify.command.source_title`

**English** — Verify the source mirror

**Français** — Vérifier le miroir source


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · doc_title_  
`verify.doc_title`

**English** — Trent Power - Verification Sheet

**Français** — Trent Power - Fiche de vérification


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · general_  
`verify.general.releases`

**English** — Release archive

**Français** — Archives des éditions


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · general_  
`verify.general.source`

**English** — Source viewer

**Français** — Visualiseur source


<sub>source · `editorial copy register`</sub>


_KICKER · Verify page_  
`verify.kicker`

**English** — Verify

**Français** — Vérification


<sub>source · `editorial copy register`</sub>


_BODY · Verify page · lede_  
`verify.lede`

**English** — A public route for checking source, hash, signature and canonical identity.

**Français** — Une voie publique pour contrôler la source, l’empreinte, la signature et l’identité canonique.


<sub>source · `editorial copy register`</sub>


_BODY · Verify page · lede_v2_  
`verify.lede_v2`

**English** — Check a published page against its canonical location, source mirror, page fingerprint and signed release archive.

**Français** — Contrôler une page publiée par rapport à son emplacement canonique, son miroir source, son empreinte de page et l'archive de version signée.


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.closing`

**English** — The signed manifest verifies the published file set. The source command hashes this page's mirror so it can be compared against the fingerprint above.

**Français** — Le manifeste signé authentifie l'ensemble des fichiers publiés. La seconde commande calcule l'empreinte du miroir de cette page pour la comparer à l'empreinte ci-dessus.


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.heading`

**English** — Verify locally

**Français** — Vérifier localement


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.intro`

**English** — Run two local checks: verify the signed manifest, then compare this page's source mirror against the expected fingerprint.

**Français** — Effectuez deux contrôles locaux : vérifier le manifeste signé, puis comparer le miroir source de cette page à l'empreinte attendue.


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.manifest_desc`

**English** — Checks that /integrity.json was signed by the published public key.

**Français** — Vérifie que /integrity.json a été signé avec la clé publique publiée.


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · local_  
`verify.local.manifest_label`

**English** — Verify the signed manifest

**Français** — Vérifier le manifeste signé


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.mirror_desc`

**English** — Calculates the source mirror fingerprint so it can be compared with the expected value above.

**Français** — Calcule l'empreinte du miroir source pour la comparer à la valeur attendue ci-dessus.


<sub>source · `editorial copy register`</sub>


_LABEL · Verify page · local_  
`verify.local.mirror_label`

**English** — Verify this page mirror

**Français** — Vérifier le miroir de cette page


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.subheading_manifest`

**English** — Verify signed manifest

**Français** — Vérifier le manifeste signé


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · local_  
`verify.local.subheading_mirror`

**English** — Verify source mirror

**Français** — Vérifier le miroir source


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · meta_  
`verify.meta`

**English** — Edition 2026-05-19 · trentpower.fr/verify/

**Français** — Édition 2026-05-19 · trentpower.fr/verify/


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · noscript_fallback_  
`verify.noscript_fallback`

**English** — JavaScript is required to select and display a page record here. Source mirrors, the signed manifest and release archives remain available through <a href="/source/">Source</a> and <a href="/integrity/">Integrity</a>.

**Français** — JavaScript est nécessaire pour sélectionner et afficher une fiche de page ici. Les miroirs source, le manifeste signé et les archives d’édition restent accessibles via <a href="/source/">Source</a> et <a href="/integrity/">Intégrité</a>.


<sub>source · `editorial copy register`</sub>


_KICKER · Verify page · page_kicker_  
`verify.page_kicker`

**English** — Verify page

**Français** — Page de vérification


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · selected_  
`verify.selected.manifest`

**English** — Integrity manifest

**Français** — Manifeste d'intégrité


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · selected_  
`verify.selected.public_key`

**English** — Public key

**Français** — Clé publique


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · selected_  
`verify.selected.signature`

**English** — Detached signature

**Français** — Signature détachée


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · status_  
`verify.status.found`

**English** — Found in signed manifest

**Français** — Présent dans le manifeste signé


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · status_  
`verify.status.missing`

**English** — Not found in current public manifest

**Français** — Absent du manifeste public actuel


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.archive`

**English** — Release archive

**Français** — Archive de version


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.citation`

**English** — Citation

**Français** — Citation


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.evidence`

**English** — Source mirror

**Français** — Miroir source


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.fingerprint`

**English** — Page fingerprint

**Français** — Empreinte de page


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.location`

**English** — Canonical location

**Français** — Emplacement canonique


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.heading`

**English** — This page

**Français** — Cette page


<sub>source · `editorial copy register`</sub>


_KICKER · Verify page · thispage_  
`verify.thispage.kicker`

**English** — Page record

**Français** — Document de page


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.canonical`

**English** — Canonical URL

**Français** — URL canonique


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.citation`

**English** — Citation

**Français** — Citation


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.file`

**English** — File

**Français** — Fichier


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.file_size`

**English** — File size

**Français** — Taille


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.file_type`

**English** — File type

**Français** — Type de fichier


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.manifest_status`

**English** — Manifest status

**Français** — Statut dans le manifeste


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.release`

**English** — Release archive

**Français** — Archive de version


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.route`

**English** — Route

**Français** — Route


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.route_prefix`

**English** — Route

**Français** — Route


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.sha256`

**English** — Page fingerprint

**Français** — Empreinte de la page


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.source`

**English** — Source mirror

**Français** — Miroir source


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · thispage_  
`verify.thispage.row.title`

**English** — Page title

**Français** — Titre de la page


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.validated`

**English** — Last verified

**Français** — Dernière vérification


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.found_manifest`

**English** — Found in signed manifest

**Français** — Présent dans le manifeste signé


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.release_archived`

**English** — Release archived

**Français** — Version archivée


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.short.archived`

**English** — Archive

**Français** — Archives


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.short.signed`

**English** — Signed

**Français** — Signé


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.short.source`

**English** — Mirrored

**Français** — Miroir


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.source_available`

**English** — Source available

**Français** — Source disponible


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.validated_prefix`

**English** — Verified

**Français** — Vérifié


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page_  
`verify.title`

**English** — Verify this page

**Français** — Vérifier cette page


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · title_default_  
`verify.title_default`

**English** — <span class="hero-line">Check page against code, size &amp; signature</span>

**Français** — <span class="hero-line">Vérifier la page · code, taille &amp; signature</span>


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · title_prefix_  
`verify.title_prefix`

**English** — Verify

**Français** — Vérifier


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · unknown_  
`verify.unknown.action.manifest`

**English** — Integrity manifest

**Français** — Manifeste d'intégrité


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · unknown_  
`verify.unknown.action.releases`

**English** — Release archive

**Français** — Archive des éditions


<sub>source · `editorial copy register`</sub>


_STRING · Verify page · unknown_  
`verify.unknown.action.source`

**English** — Source

**Français** — Source


<sub>source · `editorial copy register`</sub>


_BODY · Verify page · unknown_  
`verify.unknown.body`

**English** — This route is not in the public verification map. You can still inspect the public manifest, source view and signed releases.

**Français** — Cette route ne figure pas dans la carte de vérification publique. Vous pouvez tout de même consulter le manifeste public, la vue source et les versions signées.


<sub>source · `editorial copy register`</sub>


_TITLE · Verify page · unknown_  
`verify.unknown.title`

**English** — Route not in the verification map

**Français** — Route absente de la carte de vérification


<sub>source · `editorial copy register`</sub>


_STRING · Verify — current edition panel · archive_  
`verify_intro.archive`

**English** — Edition archive

**Français** — Archive d'édition


<sub>source · `editorial copy register`</sub>


_STRING · Verify — current edition panel · edition_  
`verify_intro.edition`

**English** — Edition

**Français** — Édition


<sub>source · `editorial copy register`</sub>


_STRING · Verify — current edition panel · manifest_  
`verify_intro.manifest`

**English** — Signed manifest

**Français** — Manifeste signé


<sub>source · `editorial copy register`</sub>


_LABEL · Verify — current edition panel · panel_label_  
`verify_intro.panel_label`

**English** — Current edition

**Français** — Édition actuelle


<sub>source · `editorial copy register`</sub>


_STRING · Verify — current edition panel · public_key_  
`verify_intro.public_key`

**English** — Public key

**Français** — Clé publique


<sub>source · `editorial copy register`</sub>


_STRING · Verify — current edition panel · signature_  
`verify_intro.signature`

**English** — Detached signature

**Français** — Signature détachée


<sub>source · `editorial copy register`</sub>


_STRING · Verify — current edition panel · signing_key_  
`verify_intro.signing_key`

**English** — Signing key

**Français** — Clé de signature


<sub>source · `editorial copy register`</sub>


---

## Part 08 · Recovery surfaces

_166 entries._

_BODY · Generic error · 403_  
`error.403.print.card.01.body`

**English** — Some paths are intentionally unavailable. Private, backup and operational files are blocked.

**Français** — Certains chemins sont intentionnellement indisponibles. Les fichiers privés, de sauvegarde et opérationnels sont bloqués.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.01.label`

**English** — 01 Access boundary

**Français** — 01 Limite d’accès


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.01.title`

**English** — Access boundary

**Français** — Limite d’accès


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.02.body`

**English** — Homepage. Privacy & Trust. Integrity. Security. Source.

**Français** — Accueil. Confidentialité & confiance. Intégrité. Sécurité. Source.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.02.label`

**English** — 02 Public routes

**Français** — 02 Voies publiques


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.02.title`

**English** — Public routes

**Français** — Voies publiques


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.03.body`

**English** — Reduces accidental exposure. Keeps public files intentional. Supports privacy and trust posture.

**Français** — Réduit l’exposition accidentelle. Maintient des fichiers publics intentionnels. Soutient la posture de confidentialité et de confiance.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.03.label`

**English** — 03 Why this matters

**Français** — 03 Pourquoi


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.03.title`

**English** — Why this matters

**Français** — Pourquoi


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.04.body`

**English** — Inspect /integrity.json. View selected source files. Check /.well-known/security.txt.

**Français** — Inspecter /integrity.json. Voir les fichiers sources sélectionnés. Consulter /.well-known/security.txt.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.04.label`

**English** — 04 Verification

**Français** — 04 Vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.04.title`

**English** — Verification

**Français** — Vérification


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.05.body`

**English** — No public database. No visitor accounts. No forms. No tracking.

**Français** — Aucune base de données publique. Aucun compte visiteur. Aucun formulaire. Sans suivi.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.05.label`

**English** — 05 Static posture

**Français** — 05 Posture statique


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.05.title`

**English** — Static posture

**Français** — Posture statique


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.06.body`

**English** — trent@trentpower.fr · responsible disclosure via /security/

**Français** — trent@trentpower.fr · divulgation responsable via /security/


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.06.label`

**English** — 06 Contact

**Français** — 06 Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.06.title`

**English** — Contact

**Français** — Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.doc_title`

**English** — Trent Power - Access Boundary Sheet

**Français** — Trent Power - Limite d’accès


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 403_  
`error.403.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr

**Français** — Édition 2026-05-19 · trentpower.fr


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 403_  
`error.403.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Generic error · 403_  
`error.403.print.kicker`

**English** — 403

**Français** — 403


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 403_  
`error.403.print.lede`

**English** — This path is not publicly accessible. The public site exposes only intentional files and pages.

**Français** — Ce chemin n’est pas accessible publiquement. Le site public n’expose que des fichiers et pages intentionnels.


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 403_  
`error.403.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr

**Français** — Édition 2026-05-19 · trentpower.fr


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 403_  
`error.403.print.qr.label`

**English** — trentpower.fr

**Français** — trentpower.fr


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 403_  
`error.403.print.title`

**English** — Access not available

**Français** — Accès indisponible


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.01.body`

**English** — The requested route does not resolve to a public page. The site remains available through the homepage.

**Français** — L’adresse demandée ne correspond à aucune page publique. Le site reste accessible depuis l’accueil.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.01.label`

**English** — 01 What happened

**Français** — 01 Ce qui s’est passé


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.01.title`

**English** — What happened

**Français** — Ce qui s’est passé


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.02.body`

**English** — Homepage. Privacy & Trust. Integrity. Security.

**Français** — Accueil. Confidentialité & confiance. Intégrité. Sécurité.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.02.label`

**English** — 02 Where to go

**Français** — 02 Où aller


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.02.title`

**English** — Where to go

**Français** — Où aller


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.03.body`

**English** — Public manifest. Source view. Signed releases.

**Français** — Manifeste public. Vue source. Versions signées.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.03.label`

**English** — 03 Verification

**Français** — 03 Vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.03.title`

**English** — Verification

**Français** — Vérification


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.04.body`

**English** — Check the URL. Remove outdated path fragments. Try the canonical homepage.

**Français** — Vérifier l’URL. Retirer les fragments obsolètes. Essayer la page d’accueil canonique.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.04.label`

**English** — 04 If this was expected

**Français** — 04 Si c’était attendu


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.04.title`

**English** — If expected

**Français** — Si attendu


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.05.body`

**English** — Static site. No tracking. No forms. No third-party scripts.

**Français** — Site statique. Sans suivi. Sans formulaire. Sans script tiers.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.05.label`

**English** — 05 Public posture

**Français** — 05 Posture publique


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.05.title`

**English** — Public posture

**Français** — Posture publique


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.06.body`

**English** — trent@trentpower.fr · LinkedIn · Trent Power

**Français** — trent@trentpower.fr · LinkedIn · Trent Power


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.06.label`

**English** — 06 Contact

**Français** — 06 Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.06.title`

**English** — Contact

**Français** — Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.doc_title`

**English** — Trent Power - Page Not Found Sheet

**Français** — Trent Power - Page introuvable


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 404_  
`error.404.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr

**Français** — Édition 2026-05-19 · trentpower.fr


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 404_  
`error.404.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Generic error · 404_  
`error.404.print.kicker`

**English** — 404

**Français** — 404


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 404_  
`error.404.print.lede`

**English** — The address may have changed, or the page may no longer be part of the public site.

**Français** — L’adresse a peut-être changé, ou la page ne fait plus partie du site public.


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 404_  
`error.404.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr

**Français** — Édition 2026-05-19 · trentpower.fr


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 404_  
`error.404.print.qr.label`

**English** — trentpower.fr

**Français** — trentpower.fr


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 404_  
`error.404.print.title`

**English** — Page not found

**Français** — Page introuvable


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.01.body`

**English** — The server could not complete the request. Try again shortly.

**Français** — Le serveur n’a pas pu traiter la requête. Réessayer dans un instant.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.01.label`

**English** — 01 What happened

**Français** — 01 Ce qui s’est passé


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.01.title`

**English** — What happened

**Français** — Ce qui s’est passé


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.02.body`

**English** — Homepage. Integrity. Security. Source.

**Français** — Accueil. Intégrité. Sécurité. Source.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.02.label`

**English** — 02 Stable routes

**Français** — 02 Voies stables


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.02.title`

**English** — Stable routes

**Français** — Voies stables


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.03.body`

**English** — /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc

**Français** — /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.03.label`

**English** — 03 Public verification

**Français** — 03 Vérification publique


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.03.title`

**English** — Public verification

**Français** — Vérification publique


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.04.body`

**English** — Static HTML, CSS and JavaScript. No runtime public application. No public database.

**Français** — HTML, CSS et JavaScript statiques. Aucune application publique à l’exécution. Aucune base de données publique.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.04.label`

**English** — 04 Architecture

**Français** — 04 Architecture


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.04.title`

**English** — Architecture

**Français** — Architecture


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.05.body`

**English** — Refresh later. Return to homepage. Contact if persistent.

**Français** — Rafraîchir plus tard. Revenir à l’accueil. Contacter si persistant.


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.05.label`

**English** — 05 What to do

**Français** — 05 Que faire


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.05.title`

**English** — What to do

**Français** — Que faire


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.06.body`

**English** — trent@trentpower.fr · LinkedIn · Trent Power

**Français** — trent@trentpower.fr · LinkedIn · Trent Power


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.06.label`

**English** — 06 Contact

**Français** — 06 Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.06.title`

**English** — Contact

**Français** — Contact


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.doc_title`

**English** — Trent Power - Temporary Server Error Sheet

**Français** — Trent Power - Erreur serveur temporaire


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 500_  
`error.500.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr

**Français** — Édition 2026-05-19 · trentpower.fr


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 500_  
`error.500.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Generic error · 500_  
`error.500.print.kicker`

**English** — 500

**Français** — 500


<sub>source · `editorial copy register`</sub>


_BODY · Generic error · 500_  
`error.500.print.lede`

**English** — Something unexpected happened while serving this page. The public site is static, so this is likely a hosting or routing issue rather than an application failure.

**Français** — Un événement inattendu est survenu lors du chargement de cette page. Le site public étant statique, il s’agit probablement d’un incident d’hébergement ou de routage plutôt que d’une défaillance applicative.


<sub>source · `editorial copy register`</sub>


_STRING · Generic error · 500_  
`error.500.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr

**Français** — Édition 2026-05-19 · trentpower.fr


<sub>source · `editorial copy register`</sub>


_LABEL · Generic error · 500_  
`error.500.print.qr.label`

**English** — trentpower.fr

**Français** — trentpower.fr


<sub>source · `editorial copy register`</sub>


_TITLE · Generic error · 500_  
`error.500.print.title`

**English** — Temporary server error

**Français** — Erreur serveur temporaire


<sub>source · `editorial copy register`</sub>


_BODY · 404 page_  
`error_404.body`

**English** — The page you’re looking for doesn’t exist or has moved.

**Français** — La page que vous recherchez n’existe pas ou a été déplacée.


<sub>source · `editorial copy register`</sub>


_TITLE · 404 page · page_title_  
`error_404.page_title`

**English** — Page not found

**Français** — Page introuvable


<sub>source · `editorial copy register`</sub>


_BODY · 500 page_  
`error_500.body`

**English** — The server encountered an error. Try again shortly, or return to the homepage.

**Français** — Le serveur a rencontré une erreur. Réessayez dans quelques instants ou retournez à la page d’accueil.


<sub>source · `editorial copy register`</sub>


_TITLE · 500 page · page_title_  
`error_500.page_title`

**English** — Something went wrong

**Français** — Une erreur s’est produite


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page_  
`maintenance.body`

**English** — The signed manifest, source mirrors and frozen release archives remain available throughout maintenance. Verification continues to work.

**Français** — Le manifeste signé, les miroirs source et les archives de versions restent accessibles pendant la maintenance. La vérification reste opérationnelle.


<sub>source · `editorial copy register`</sub>


_KICKER · Maintenance page_  
`maintenance.kicker`

**English** — Maintenance

**Français** — Maintenance


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · lede_  
`maintenance.lede`

**English** — We're doing some work here. Check back shortly, or return to the homepage.

**Français** — Des travaux sont en cours. Revenez dans quelques instants ou retournez à la page d'accueil.


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · page_title_  
`maintenance.page_title`

**English** — Down for maintenance

**Français** — En maintenance


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.01.body`

**English** — A signed release or infrastructure update is in progress.

**Français** — Une version signée ou une mise à jour d’infrastructure est en cours.


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.01.label`

**English** — 01 Deployment state

**Français** — 01 État de déploiement


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.01.title`

**English** — Deployment state

**Français** — État de déploiement


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.02.body`

**English** — The previous signed edition remains downloadable in /integrity/releases/.

**Français** — L’édition signée précédente reste téléchargeable dans /integrity/releases/.


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.02.label`

**English** — 02 Integrity preservation

**Français** — 02 Préservation d’intégrité


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.02.title`

**English** — Integrity preservation

**Français** — Préservation d’intégrité


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.03.body`

**English** — Service returns automatically when the new edition is signed and verified.

**Français** — Le service revient automatiquement dès que la nouvelle édition est signée et vérifiée.


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.03.label`

**English** — 03 Public availability

**Français** — 03 Disponibilité publique


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.03.title`

**English** — Public availability

**Français** — Disponibilité publique


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.04.body`

**English** — Archived editions stay reachable independently of this maintenance window.

**Français** — Les éditions archivées restent accessibles indépendamment de cette fenêtre de maintenance.


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.04.label`

**English** — 04 Signed releases

**Français** — 04 Versions signées


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.04.title`

**English** — Signed releases

**Français** — Versions signées


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.05.body`

**English** — trent@trentpower.fr - for inquiries during extended unavailability.

**Français** — trent@trentpower.fr - pour toute demande en cas d’indisponibilité prolongée.


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.05.label`

**English** — 05 Maintenance contact

**Français** — 05 Contact de maintenance


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.05.title`

**English** — Maintenance contact

**Français** — Contact de maintenance


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.06.body`

**English** — Canonical URLs are preserved across editions; bookmarks remain valid.

**Français** — Les URL canoniques sont préservées d’une édition à l’autre ; vos signets restent valides.


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.06.label`

**English** — 06 Expected continuity

**Français** — 06 Continuité attendue


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.06.title`

**English** — Expected continuity

**Français** — Continuité attendue


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.doc_title`

**English** — Trent Power - Maintenance

**Français** — Trent Power - Maintenance


<sub>source · `editorial copy register`</sub>


_STRING · Maintenance page · print_  
`maintenance.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/maintenance.html

**Français** — Édition 2026-05-19 · trentpower.fr/maintenance.html


<sub>source · `editorial copy register`</sub>


_STRING · Maintenance page · print_  
`maintenance.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Maintenance page · print_  
`maintenance.print.kicker`

**English** — Maintenance status

**Français** — État de maintenance


<sub>source · `editorial copy register`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.lede`

**English** — This site is temporarily unavailable while a new signed edition or infrastructure update is being deployed.

**Français** — Ce site est temporairement indisponible pendant le déploiement d’une nouvelle édition signée ou d’une mise à jour d’infrastructure.


<sub>source · `editorial copy register`</sub>


_STRING · Maintenance page · print_  
`maintenance.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/maintenance.html

**Français** — Édition 2026-05-19 · trentpower.fr/maintenance.html


<sub>source · `editorial copy register`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.qr.label`

**English** — trentpower.fr/maintenance.html

**Français** — trentpower.fr/maintenance.html


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.title`

**English** — Temporary maintenance mode

**Français** — Mode maintenance temporaire


<sub>source · `editorial copy register`</sub>


_TITLE · Maintenance page_  
`maintenance.title`

**English** — Down for maintenance

**Français** — En maintenance


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · api_label_  
`sw_reset.api_label`

**English** — APIs

**Français** — API


<sub>source · `editorial copy register`</sub>


_BUTTON · Service Worker reset page_  
`sw_reset.button`

**English** — Reset local offline cache

**Français** — Réinitialiser le cache hors-ligne local


<sub>source · `editorial copy register`</sub>


_BUTTON · Service Worker reset page · button_done_  
`sw_reset.button_done`

**English** — Reset complete

**Français** — Réinitialisation effectuée


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · card_state_  
`sw_reset.card_state`

**English** — Offline cache

**Français** — Cache hors-ligne


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · card_state_cleared_  
`sw_reset.card_state_cleared`

**English** — Offline cache cleared

**Français** — Cache hors-ligne effacé


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · clear_caches_  
`sw_reset.clear_caches`

**English** — Offline cache entries

**Français** — Entrées du cache hors-ligne


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · clear_pref_  
`sw_reset.clear_pref`

**English** — Saved language preference

**Français** — Préférence de langue enregistrée


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · clear_sw_  
`sw_reset.clear_sw`

**English** — Service Worker registrations

**Français** — Enregistrements du Service Worker


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · clears_heading_  
`sw_reset.clears_heading`

**English** — Clears

**Français** — Efface


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · detected_label_  
`sw_reset.detected_label`

**English** — Detected

**Français** — Détecté


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · edition_label_  
`sw_reset.edition_label`

**English** — Cached edition

**Français** — Édition en cache


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · edition_none_  
`sw_reset.edition_none`

**English** — No cached edition detected

**Français** — Aucune édition en cache détectée


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · footnote_  
`sw_reset.footnote`

**English** — Offline state is stored locally through the browser Cache Storage and Service Worker APIs.

**Français** — L'état hors-ligne est conservé localement via les API Cache Storage et Service Worker du navigateur.


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · lede_  
`sw_reset.lede`

**English** — Clears the local offline cache for this device only. The live publication and server are unaffected.

**Français** — Efface le cache hors-ligne local de cet appareil uniquement. La publication en ligne et le serveur ne sont pas affectés.


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · link_home_  
`sw_reset.link_home`

**English** — Home

**Français** — Accueil


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · link_reload_  
`sw_reset.link_reload`

**English** — Reload current edition

**Français** — Recharger l'édition actuelle


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · local_marker_  
`sw_reset.local_marker`

**English** — LOCAL DEVICE ONLY

**Français** — APPAREIL LOCAL UNIQUEMENT


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · page_title_  
`sw_reset.page_title`

**English** — Service Worker Reset

**Français** — Réinitialisation du Service Worker


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · preserve_downloads_  
`sw_reset.preserve_downloads`

**English** — Downloads

**Français** — Téléchargements


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · preserve_history_  
`sw_reset.preserve_history`

**English** — Browser history

**Français** — Historique du navigateur


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · preserve_others_  
`sw_reset.preserve_others`

**English** — Other websites

**Français** — Autres sites


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · preserve_server_  
`sw_reset.preserve_server`

**English** — Server content

**Français** — Contenu du serveur


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · preserves_heading_  
`sw_reset.preserves_heading`

**English** — Does not clear

**Français** — N'efface pas


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.01.body`

**English** — Unregisters the service worker and deletes every named cache for this origin.

**Français** — Désenregistre le Service Worker et supprime chaque cache nommé de cette origine.


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.01.label`

**English** — 01 Cache removal

**Français** — 01 Suppression du cache


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.01.title`

**English** — Cache removal

**Français** — Suppression du cache


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.02.body`

**English** — Used when a stale offline copy is serving an outdated signed edition.

**Français** — Utilisé lorsqu’une copie hors-ligne périmée sert une édition signée obsolète.


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.02.label`

**English** — 02 Offline recovery

**Français** — 02 Récupération hors-ligne


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.02.title`

**English** — Offline recovery

**Français** — Récupération hors-ligne


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.03.body`

**English** — Next page load fetches fresh HTML, CSS, JS, fonts, and integrity files.

**Français** — Le chargement suivant récupère HTML, CSS, JS, polices et fichiers d’intégrité à neuf.


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.03.label`

**English** — 03 Signed release refresh

**Français** — 03 Actualisation de version signée


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.03.title`

**English** — Signed release refresh

**Français** — Actualisation de version signée


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.04.body`

**English** — Works in any browser that supports Service Workers and the Cache API.

**Français** — Fonctionne dans tout navigateur prenant en charge les Service Workers et l’API Cache.


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.04.label`

**English** — 04 Browser compatibility

**Français** — 04 Compatibilité navigateur


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.04.title`

**English** — Browser compatibility

**Français** — Compatibilité navigateur


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.05.body`

**English** — Integrity manifest and signature remain unchanged - only cached copies are evicted.

**Français** — Manifeste et signature inchangés - seules les copies en cache sont évincées.


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.05.label`

**English** — 05 Verification continuity

**Français** — 05 Continuité de vérification


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.05.title`

**English** — Verification continuity

**Français** — Continuité de vérification


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.06.body`

**English** — Clears the cached language preference. Theme preference is preserved.

**Français** — Efface la préférence de langue en cache. La préférence de thème est préservée.


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.06.label`

**English** — 06 Local state reset

**Français** — 06 Remise à zéro locale


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.06.title`

**English** — Local state reset

**Français** — Remise à zéro locale


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.doc_title`

**English** — Trent Power - Service Worker Reset

**Français** — Trent Power - Réinitialisation du Service Worker


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · print_  
`sw_reset.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/sw-reset/

**Français** — Édition 2026-05-19 · trentpower.fr/sw-reset/


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · print_  
`sw_reset.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · Service Worker reset page · print_  
`sw_reset.print.kicker`

**English** — Offline recovery

**Français** — Récupération hors-ligne


<sub>source · `editorial copy register`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.lede`

**English** — Recovery utility for clearing cached offline state and refreshing the current signed public release.

**Français** — Utilitaire de récupération pour effacer l’état hors-ligne en cache et actualiser la version publique signée courante.


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · print_  
`sw_reset.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/sw-reset/

**Français** — Édition 2026-05-19 · trentpower.fr/sw-reset/


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.qr.label`

**English** — trentpower.fr/sw-reset/

**Français** — trentpower.fr/sw-reset/


<sub>source · `editorial copy register`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.title`

**English** — Service worker reset

**Français** — Réinitialisation du Service Worker


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · scope_heading_  
`sw_reset.scope_heading`

**English** — Scope

**Français** — Portée


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · secondary_  
`sw_reset.secondary`

**English** — If a recent edition is not appearing correctly, this utility refreshes the local publication cache.

**Français** — Si une édition récente ne s'affiche pas correctement, cet utilitaire rafraîchit le cache local de la publication.


<sub>source · `editorial copy register`</sub>


_STRING · Service Worker reset page · status_initial_  
`sw_reset.status_initial`

**English** — Reading local state…

**Français** — Lecture de l'état local…


<sub>source · `editorial copy register`</sub>


_LABEL · Service Worker reset page · status_label_  
`sw_reset.status_label`

**English** — Local cache status

**Français** — État du cache local


<sub>source · `editorial copy register`</sub>


---

## Part 09 · Metadata (titles · descriptions · Open Graph)

_28 entries._

_DESCRIPTION · Page metadata (titles, descriptions, OG) · 403_  
`meta.403.description`

**English** — Access not permitted.

**Français** — Accès non autorisé.


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · 403_  
`meta.403.title`

**English** — Forbidden · Trent Power

**Français** — Accès refusé · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · 404_  
`meta.404.description`

**English** — Page not found.

**Français** — Page introuvable.


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · 404_  
`meta.404.title`

**English** — Page not found · Trent Power

**Français** — Page introuvable · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · 500_  
`meta.500.description`

**English** — Something went wrong.

**Français** — Une erreur s’est produite.


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · 500_  
`meta.500.title`

**English** — Something went wrong · Trent Power

**Français** — Une erreur est survenue · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · acknowledgments_  
`meta.acknowledgments.description`

**English** — Responsible security disclosures verified and resolved for trentpower.fr.

**Français** — Divulgations de sécurité responsables vérifiées et résolues pour trentpower.fr.


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · acknowledgments_  
`meta.acknowledgments.title`

**English** — Security acknowledgements · Trent Power

**Français** — Remerciements de sécurité · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · home_  
`meta.home.description`

**English** — Client strategy, growth systems and cultural adoption at global scale

**Français** — Stratégie client, systèmes de croissance et adoption culturelle à l’échelle mondiale


> 150–160 chars. Search snippet and Open Graph fallback.

<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · home_  
`meta.home.og_description`

**English** — Client strategy, growth systems and cultural adoption at global scale

**Français** — Stratégie client, systèmes de croissance et adoption culturelle à l’échelle mondiale


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · home_  
`meta.home.og_title`

**English** — Client Strategy & Growth Systems · Trent Power

**Français** — Stratégie Client & Systèmes de Croissance · Trent Power


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · home_  
`meta.home.title`

**English** — Client Strategy & Growth Systems · Trent Power

**Français** — Stratégie Client & Systèmes de Croissance · Trent Power


> Browser tab title and search-result heading. Keep concise; this is the brand line.

<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · integrity_  
`meta.integrity.description`

**English** — Signed public releases, integrity manifest, detached signature and public signing key

**Français** — Éditions publiques signées, manifeste d’intégrité, signature détachée et clé publique


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · integrity_  
`meta.integrity.title`

**English** — Integrity · Trent Power

**Français** — Intégrité · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · maintenance_  
`meta.maintenance.description`

**English** — Down for maintenance.

**Français** — En maintenance.


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · maintenance_  
`meta.maintenance.title`

**English** — Down for maintenance · Trent Power

**Français** — En maintenance · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · privacy_  
`meta.privacy.description`

**English** — A simple, privacy-respectful site with no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse

**Français** — Un site simple et respectueux de la vie privée, sans suivi, analytique, cookies, profilage ni requêtes tierces intégrées pendant la navigation


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · privacy_  
`meta.privacy.title`

**English** — Privacy & Trust · Trent Power

**Français** — Confidentialité & confiance · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · releases_  
`meta.releases.description`

**English** — Frozen, signed snapshots of the public site

**Français** — Instantanés signés et figés du site public


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · releases_  
`meta.releases.title`

**English** — Releases · Trent Power

**Français** — Éditions · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · security_  
`meta.security.description`

**English** — Security architecture, operational controls, public verification surfaces and residual risks

**Français** — Architecture de sécurité, contrôles opérationnels, surfaces publiques de vérification et risques résiduels


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · security_  
`meta.security.title`

**English** — Security & Threat Model · Trent Power

**Français** — Sécurité & modèle de menace · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · source_  
`meta.source.description`

**English** — Readable public mirrors of selected site files

**Français** — Miroirs publics lisibles d’une sélection de fichiers du site


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · source_  
`meta.source.title`

**English** — Source mirrors · Trent Power

**Français** — Miroirs source · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · verify_  
`meta.verify.description`

**English** — A public page record showing the canonical URL, source mirror, page fingerprint and signed release archive

**Français** — Document public présentant l’URL canonique, le miroir source, l’empreinte et l’archive d’édition signée


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · verify_  
`meta.verify.title`

**English** — Verify this page · Trent Power

**Français** — Vérifier cette page · Trent Power


<sub>source · `editorial copy register`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · verify_locally_  
`meta.verify_locally.description`

**English** — Detached verification notes: signed manifest check from a temporary keyring

**Français** — Notes de vérification détachées : contrôle du manifeste signé depuis un trousseau temporaire


<sub>source · `editorial copy register`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · verify_locally_  
`meta.verify_locally.title`

**English** — Verify locally · Trent Power

**Français** — Vérifier localement · Trent Power


<sub>source · `editorial copy register`</sub>


---

## Part 10 · Structured data (Schema.org)

_21 entries._

_Schema · Structured data (Schema.org) · 403_  
`jsonld.403.WebPage.description`

**English** — Access not available.


> WebPage node for /403/.

<sub>source · `/403.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · 403_  
`jsonld.403.WebPage.name`

**English** — 403 — access not available · Trent Power


> WebPage node for /403/.

<sub>source · `/403.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · 404_  
`jsonld.404.WebPage.description`

**English** — Page not found.


> WebPage node for /404/.

<sub>source · `/404.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · 404_  
`jsonld.404.WebPage.name`

**English** — 404 — page not found · Trent Power


> WebPage node for /404/.

<sub>source · `/404.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · 500_  
`jsonld.500.WebPage.description`

**English** — Temporary server error.


> WebPage node for /500/.

<sub>source · `/500.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · 500_  
`jsonld.500.WebPage.name`

**English** — 500 — temporary server error · Trent Power


> WebPage node for /500/.

<sub>source · `/500.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.DefinedTerm.description`

**English** — Clienteling is a discipline. It is the practice of transforming what a Client Advisor knows into something a Client feels. The moment interactions become mechanical, it stops being Clienteling.


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.DefinedTerm.name`

**English** — Clienteling


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.description`

**English** — Client strategy, growth systems and cultural adoption at global scale


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.disambiguatingDescription`

**English** — Client strategy, growth systems and cultural adoption at global scale

**Français** — Stratégie client, systèmes de croissance et adoption culturelle à l'échelle mondiale


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.image.copyrightNotice`

**English** — © David Arous


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.image.creditText`

**English** — David Arous


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.jobTitle`

**English** — Group Director, Client Development & Client Relations

**Français** — Directeur Groupe, Développement Client & Relations Clients


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.name`

**English** — Trent Power


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.ProfilePage.name`

**English** — Trent Power — Profile


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.WebSite.description`

**English** — Client strategy, growth systems and cultural adoption at global scale


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.WebSite.name`

**English** — Trent Power


> Surfaces in search engine rich results and AI assistants.

<sub>source · `/ JSON-LD @graph`</sub>


_Schema · Structured data (Schema.org) · maintenance_  
`jsonld.maintenance.WebPage.description`

**English** — Down for maintenance.


> WebPage node for /maintenance/.

<sub>source · `/maintenance.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · maintenance_  
`jsonld.maintenance.WebPage.name`

**English** — Maintenance · Trent Power


> WebPage node for /maintenance/.

<sub>source · `/maintenance.html JSON-LD`</sub>


_Schema · Structured data (Schema.org) · sw_reset_  
`jsonld.sw_reset.WebPage.description`

**English** — Local recovery utility. Clears the offline cache for trentpower.fr on this device only.


> WebPage node for /sw_reset/.

<sub>source · `/sw-reset JSON-LD`</sub>


_Schema · Structured data (Schema.org) · sw_reset_  
`jsonld.sw_reset.WebPage.name`

**English** — Service Worker Reset · Trent Power


> WebPage node for /sw_reset/.

<sub>source · `/sw-reset JSON-LD`</sub>


---

## Part 11 · Other strings

_190 entries._

_BODY · credentials · exec_detail_  
`credentials.exec_detail`

**English** — Ongoing senior-level learning across artificial intelligence, consumer behaviour, organisational transformation, and leadership coaching.

**Français** — Apprentissage senior en continu — intelligence artificielle, comportement consommateur, transformation organisationnelle et coaching en leadership.


<sub>source · `editorial copy register`</sub>


_TITLE · credentials · exec_title_  
`credentials.exec_title`

**English** — Selective executive education

**Français** — Formation exécutive sélective


<sub>source · `editorial copy register`</sub>


_LABEL · credentials_  
`credentials.label`

**English** — Credentials

**Français** — Parcours académique


<sub>source · `editorial copy register`</sub>


_BODY · credentials · sydney_detail_  
`credentials.sydney_detail`

**English** — Master’s degree, 2009.

**Français** — Master, 2009.


<sub>source · `editorial copy register`</sub>


_TITLE · credentials · sydney_title_  
`credentials.sydney_title`

**English** — University of Sydney

**Français** — University of Sydney


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · checksums_  
`linkdesc.checksums`

**English** — Download the SHA-256 checksums for the signed release archives

**Français** — Télécharger les empreintes SHA-256 des archives de publication signées


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · cite_  
`linkdesc.cite`

**English** — Open citation and verification details for this page

**Français** — Ouvrir les détails de citation et de vérification de cette page


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · email_  
`linkdesc.email`

**English** — Contact Trent Power by email

**Français** — Contacter Trent Power par e-mail


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · home_  
`linkdesc.home`

**English** — Return to the homepage

**Français** — Retour à l’accueil


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · integrity_  
`linkdesc.integrity`

**English** — Open the public integrity record, including hashes, signatures, and release verification

**Français** — Ouvrir le registre d’intégrité public — empreintes, signatures et vérification des éditions


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · lang_en_  
`linkdesc.lang_en`

**English** — Read this site in English

**Français** — Read this site in English


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · lang_fr_  
`linkdesc.lang_fr`

**English** — Lire ce site en français

**Français** — Lire ce site en français


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · linkedin_  
`linkdesc.linkedin`

**English** — Open Trent Power’s LinkedIn profile in a new tab without sending referrer data

**Français** — Ouvrir le profil LinkedIn de Trent Power dans un nouvel onglet, sans transmettre l’URL d’origine


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · manifest_  
`linkdesc.manifest`

**English** — Download the signed integrity manifest (JSON listing every public file and its SHA-256)

**Français** — Télécharger le manifeste d’intégrité signé (JSON listant chaque fichier public et son SHA-256)


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · now_  
`linkdesc.now`

**English** — Read what Trent Power is currently focused on

**Français** — Lire ce sur quoi Trent Power se concentre actuellement


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · privacy_  
`linkdesc.privacy`

**English** — Read how this site avoids analytics, cookies, profiling, tracking, and third-party assets

**Français** — Découvrir comment ce site évite les analytiques, cookies, profilage, traceurs et services tiers


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · public_key_  
`linkdesc.public_key`

**English** — Download the public PGP key used to sign releases

**Français** — Télécharger la clé PGP publique utilisée pour signer les publications


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · security_contact_  
`linkdesc.security_contact`

**English** — Read the security.txt disclosure policy for this site

**Français** — Lire la politique de divulgation security.txt de ce site


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · security_threat_model_  
`linkdesc.security_threat_model`

**English** — Read the security architecture and threat model for this site

**Français** — Lire le modèle de sécurité et l’analyse de menace de ce site


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · signature_  
`linkdesc.signature`

**English** — Download the detached PGP signature for the integrity manifest

**Français** — Télécharger la signature PGP détachée du manifeste d’intégrité


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · source_  
`linkdesc.source`

**English** — View the public source mirror of this site, with readable annotations and line references

**Français** — Consulter le miroir source public du site, annoté et numéroté


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · targz_  
`linkdesc.targz`

**English** — Download the source archive as a TAR.GZ file

**Français** — Télécharger l’archive source au format TAR.GZ


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · theme_auto_  
`linkdesc.theme_auto`

**English** — Match the system appearance setting

**Français** — Suivre les réglages d’apparence du système


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · theme_dark_  
`linkdesc.theme_dark`

**English** — Switch to the dark appearance

**Français** — Passer à l’apparence sombre


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · theme_light_  
`linkdesc.theme_light`

**English** — Switch to the light appearance

**Français** — Passer à l’apparence claire


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · verify_  
`linkdesc.verify`

**English** — Check the current page against the published integrity data

**Français** — Vérifier la page courante contre le registre d’intégrité publié


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · verify_locally_  
`linkdesc.verify_locally`

**English** — Read the instructions to verify the publication locally with command-line tools

**Français** — Lire les instructions pour vérifier la publication localement en ligne de commande


<sub>source · `editorial copy register`</sub>


_STRING · linkdesc · zip_  
`linkdesc.zip`

**English** — Download the source archive as a ZIP file

**Français** — Télécharger l’archive source au format ZIP


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.01.body`

**English** — /integrity.json - SHA-256 hashes of every intentional public file at edition time.

**Français** — /integrity.json - empreintes SHA-256 de chaque fichier public au moment de l’édition.


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.01.label`

**English** — 01 Manifest

**Français** — 01 Manifeste


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.01.title`

**English** — Manifest

**Français** — Manifeste


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.02.body`

**English** — /integrity.json.sig - PGP detached signature over the manifest.

**Français** — /integrity.json.sig - signature PGP détachée du manifeste.


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.02.label`

**English** — 02 Detached signature

**Français** — 02 Signature détachée


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.02.title`

**English** — Detached signature

**Français** — Signature détachée


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.03.body`

**English** — /integrity/releases/2026-05-09/SHA256SUMS - sums for ZIP and TAR.GZ.

**Français** — /integrity/releases/2026-05-09/SHA256SUMS - sommes pour ZIP et TAR.GZ.


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.03.label`

**English** — 03 Archive checksums

**Français** — 03 Sommes d’archive


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.03.title`

**English** — Archive checksums

**Français** — Sommes d’archive


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.04.body`

**English** — trentpower-fr-2026-05-09.zip · trentpower-fr-2026-05-09.tar.gz - deterministic.

**Français** — trentpower-fr-2026-05-09.zip · trentpower-fr-2026-05-09.tar.gz - déterministes.


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.04.label`

**English** — 04 Source archive

**Français** — 04 Archive source


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.04.title`

**English** — Source archive

**Français** — Archive source


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.05.body`

**English** — gpg --verify integrity.json.sig integrity.json against the public key.

**Français** — gpg --verify integrity.json.sig integrity.json contre la clé publique.


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.05.label`

**English** — 05 Verification status

**Français** — 05 Statut de vérification


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.05.title`

**English** — Verification status

**Français** — Statut de vérification


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.06.body`

**English** — Signed by A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.

**Français** — Signée par A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.06.label`

**English** — 06 Release fingerprint

**Français** — 06 Empreinte de version


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.06.title`

**English** — Release fingerprint

**Français** — Empreinte de version


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.doc_title`

**English** — Trent Power - Release Archive 2026-05-09

**Français** — Trent Power - Archive 2026-05-09


<sub>source · `editorial copy register`</sub>


_STRING · release_archive · print_  
`release_archive.print.footer.edition`

**English** — Edition 2026-05-09 · trentpower.fr/integrity/releases/2026-05-09/

**Français** — Édition 2026-05-17 · trentpower.fr/integrity/releases/2026-05-09/


<sub>source · `editorial copy register`</sub>


_STRING · release_archive · print_  
`release_archive.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · release_archive · print_  
`release_archive.print.kicker`

**English** — Signed release archive

**Français** — Archive de version signée


<sub>source · `editorial copy register`</sub>


_BODY · release_archive · print_  
`release_archive.print.lede`

**English** — Public release archive for the May 2026 signed edition, including manifests, checksums, detached signatures, and reproducible source records.

**Français** — Archive publique de l’édition signée de mai 2026 : manifestes, sommes de contrôle, signatures détachées et archives sources reproductibles.


<sub>source · `editorial copy register`</sub>


_STRING · release_archive · print_  
`release_archive.print.meta`

**English** — Edition 2026-05-09 · trentpower.fr/integrity/releases/2026-05-09/

**Français** — Édition 2026-05-17 · trentpower.fr/integrity/releases/2026-05-09/


<sub>source · `editorial copy register`</sub>


_LABEL · release_archive · print_  
`release_archive.print.qr.label`

**English** — trentpower.fr/integrity/releases/2026-05-09/

**Français** — trentpower.fr/integrity/releases/2026-05-09/


<sub>source · `editorial copy register`</sub>


_TITLE · release_archive · print_  
`release_archive.print.title`

**English** — Edition 2026-05-09

**Français** — Édition 2026-05-17


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.back_to_top`

**English** — Top

**Français** — Haut


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.canonical`

**English** — Canonical

**Français** — Canonique


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.clear`

**English** — Clear

**Français** — Effacer


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.copied`

**English** — Copied

**Français** — Copié


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy`

**English** — Copy

**Français** — Copier


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy_code`

**English** — Copy code

**Français** — Copier le code


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy_failed`

**English** — Copy unavailable

**Français** — Copie indisponible


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy_link`

**English** — Copy link

**Français** — Copier le lien


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.count_line_one`

**English** — 1 line

**Français** — 1 ligne


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.count_lines_many`

**English** — {n} lines

**Français** — {n} lignes


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.line_selected`

**English** — Line {n} selected

**Français** — Ligne {n} sélectionnée


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.lines_copied`

**English** — {n} lines copied

**Français** — {n} lignes copiées


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.link_copied`

**English** — Link copied

**Français** — Lien copié


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.link_copied_normalised`

**English** — Link copied — normalised to lines {start} to {end}

**Français** — Lien copié — normalisé aux lignes {start} à {end}


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.plain_text`

**English** — Raw

**Français** — Brut


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.range_selected`

**English** — Lines {start} to {end} selected

**Français** — Lignes {start} à {end} sélectionnées


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.reading_mode`

**English** — Reading mode

**Français** — Mode de lecture


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.selection_cleared`

**English** — Selection cleared

**Français** — Sélection effacée


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.top`

**English** — Top

**Français** — Haut


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.unwrap_lines`

**English** — Unwrap lines

**Français** — Sans retour à la ligne


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.verify`

**English** — Verify

**Français** — Vérifier


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.view_annotated`

**English** — Annotated

**Français** — Annoté


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.view_rendered_page`

**English** — View rendered page

**Français** — Voir la page rendue


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.view_source`

**English** — Source

**Français** — Source


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · action_  
`source_reader.action.wrap_lines`

**English** — Wrap lines

**Français** — Retour à la ligne


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · end_  
`source_reader.end.edition`

**English** — Edition

**Français** — Édition


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · end_  
`source_reader.end.sha256`

**English** — SHA-256

**Français** — SHA-256


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · end_  
`source_reader.end.signed_release`

**English** — Signed release

**Français** — Publication signée


<sub>source · `editorial copy register`</sub>


_TITLE · source_reader · end_  
`source_reader.end.title`

**English** — End of source mirror

**Français** — Fin du miroir source


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.assets`

**English** — stylesheets, scripts, icons, manifest.

**Français** — feuilles de style, scripts, icônes, manifeste.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.base`

**English** — reset and base element typography.

**Français** — réinitialisation et typographie des éléments de base.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.components`

**English** — reusable component styles.

**Français** — styles de composants réutilisables.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.copy`

**English** — clipboard interactions.

**Français** — interactions avec le presse-papiers.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.discovery`

**English** — indexing and referrer policy.

**Français** — politique d'indexation et de référent.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.document`

**English** — page title, description, canonical url.

**Français** — titre de la page, description, URL canonique.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.events`

**English** — event listeners and interaction wiring.

**Français** — écouteurs d'événements et câblage des interactions.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.fonts`

**English** — font face declarations and font assets.

**Français** — déclarations @font-face et fichiers de police.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.footer`

**English** — colophon, language switch, footer actions.

**Français** — colophon, sélecteur de langue, actions de pied de page.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.foundations`

**English** — character encoding, viewport, colour scheme.

**Français** — encodage des caractères, fenêtre d'affichage, palette.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.head`

**English** — document head — metadata, no rendered content.

**Français** — en-tête du document — métadonnées, aucun contenu rendu.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.header`

**English** — site header — wordmark and primary nav.

**Français** — en-tête du site — sigle et navigation principale.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.i18n`

**English** — translation lookup and language switching.

**Français** — résolution des traductions et changement de langue.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.icons`

**English** — platform icons and home-screen artwork.

**Français** — icônes de plateforme et illustration d'écran d'accueil.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.identity`

**English** — authorship, application name, attribution links.

**Français** — auteur, nom de l'application, liens d'attribution.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.init`

**English** — boot sequence — runs once on load.

**Français** — séquence de démarrage — exécutée une fois au chargement.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.layout`

**English** — page-level layout grammar.

**Français** — grammaire de mise en page au niveau de la page.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.modals`

**English** — overlay surfaces, dialogs, focus traps.

**Français** — surfaces superposées, dialogues, pièges de focus.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.policy`

**English** — declared site policies.

**Français** — politiques déclarées du site.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.print`

**English** — print stylesheet rules.

**Français** — règles de feuille de style pour l'impression.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.records`

**English** — editorial record entries.

**Français** — fiches éditoriales.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.responsive`

**English** — viewport-aware overrides.

**Français** — ajustements selon la fenêtre d'affichage.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.script`

**English** — site application logic.

**Français** — logique applicative du site.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.social`

**English** — open graph and twitter card metadata.

**Français** — métadonnées open graph et twitter card.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.state`

**English** — application state and runtime variables.

**Français** — état applicatif et variables d'exécution.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.structured`

**English** — json-ld schema, machine-readable identity.

**Français** — schéma json-ld, identité lisible par machine.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.tokens`

**English** — design tokens — colours, typography, spacing.

**Français** — jetons de design — couleurs, typographie, espacements.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.verification`

**English** — signed-manifest and cryptographic references.

**Français** — manifeste signé et références cryptographiques.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.canonical`

**English** — Canonical file

**Français** — Fichier canonique


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.edition`

**English** — Edition

**Français** — Édition


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.sha256`

**English** — SHA-256

**Français** — SHA-256


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.signed_release`

**English** — Signed release

**Français** — Publication signée


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.apache`

**English** — Apache configuration

**Français** — Configuration Apache


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.asc`

**English** — ASCII-armoured PGP key

**Français** — Clé PGP en ASCII-armor


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.css`

**English** — Cascading Style Sheets

**Français** — Feuilles de style en cascade


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.html`

**English** — HyperText Markup Language

**Français** — Langage de balisage hypertexte


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.js`

**English** — JavaScript

**Français** — JavaScript


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.json`

**English** — JavaScript Object Notation

**Français** — Notation d'objet JavaScript


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.sig`

**English** — Detached PGP signature

**Français** — Signature PGP détachée


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.text`

**English** — Plain text

**Français** — Texte brut


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.xml`

**English** — Extensible Markup Language

**Français** — Langage de balisage extensible


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · loading_  
`source_reader.loading`

**English** — Loading source…

**Français** — Chargement du source…


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.assets`

**English** — Assets

**Français** — Ressources


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.base`

**English** — Base

**Français** — Base


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.components`

**English** — Components

**Français** — Composants


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.copy`

**English** — Copy

**Français** — Copie


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.discovery`

**English** — Discovery

**Français** — Découvrabilité


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.events`

**English** — Events

**Français** — Événements


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.fonts`

**English** — Fonts

**Français** — Polices


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.footer`

**English** — Footer

**Français** — Pied de page


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.head`

**English** — Head

**Français** — Tête


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.header`

**English** — Header

**Français** — En-tête


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.i18n`

**English** — i18n

**Français** — i18n


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.identity`

**English** — Identity

**Français** — Identité


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.init`

**English** — Init

**Français** — Initialisation


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.layout`

**English** — Layout

**Français** — Mise en page


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.main`

**English** — Main

**Français** — Contenu principal


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.modals`

**English** — Modals

**Français** — Modales


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.policy`

**English** — Policy

**Français** — Politique


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.print`

**English** — Print

**Français** — Impression


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.records`

**English** — Records

**Français** — Enregistrements


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.responsive`

**English** — Responsive

**Français** — Responsive


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.social_preview`

**English** — Social preview

**Français** — Aperçu social


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.state`

**English** — State

**Français** — État


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.structured_data`

**English** — Structured data

**Français** — Données structurées


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.tokens`

**English** — Tokens

**Français** — Jetons


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.verification`

**English** — Verification

**Français** — Vérification


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.document_map`

**English** — Document map

**Français** — Plan du document


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.end_of_source`

**English** — End of source mirror

**Français** — Fin du miroir source


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.intent`

**English** — This reader presents public source mirrors with structural annotations and signed publication references.

**Français** — Ce lecteur présente les miroirs publics du code source, avec annotations structurelles et références de publication signées.


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.part_of`

**English** — Related systems:

**Français** — Systèmes liés :


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.validated`

**English** — Verified

**Français** — Vérifié


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · mode_  
`source_reader.mode.annotated`

**English** — Annotated

**Français** — Annoté


<sub>source · `editorial copy register`</sub>


_LABEL · source_reader · mode_  
`source_reader.mode.label`

**English** — Reading mode

**Français** — Mode de lecture


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · mode_  
`source_reader.mode.raw`

**English** — Raw

**Français** — Brut


<sub>source · `editorial copy register`</sub>


_STRING · source_reader · mode_  
`source_reader.mode.source`

**English** — Source

**Français** — Source


<sub>source · `editorial copy register`</sub>


_TITLE · source_reader_  
`source_reader.title`

**English** — Source reader

**Français** — Lecteur source


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · body_close_  
`verify_locally.body_close`

**English** — The command imports the public key into a throw-away keyring, verifies the signed manifest, and removes the working files. No state is retained on the machine afterwards.

**Français** — La commande importe la clé publique dans un trousseau jetable, vérifie le manifeste signé et supprime les fichiers de travail. Aucun état ne subsiste sur la machine ensuite.


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · body_intro_  
`verify_locally.body_intro`

**English** — Detached verification notes for the signed integrity manifest. Run the check in a temporary keyring so the public signing key does not enter your default keychain.

**Français** — Notes de vérification détachées pour le manifeste d'intégrité signé. Exécutez le contrôle dans un trousseau temporaire afin que la clé publique de signature n'entre pas dans votre trousseau principal.


<sub>source · `editorial copy register`</sub>


_KICKER · verify_locally · page_kicker_  
`verify_locally.page_kicker`

**English** — Verify Locally

**Français** — Vérification locale


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · page_title_  
`verify_locally.page_title`

**English** — <span class="hero-line">Get to</span><span class="hero-line">the terminal!</span>

**Français** — <span class="hero-line">À votre</span><span class="hero-line">terminal !</span>


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.01.body`

**English** — Use a temp GNUPGHOME so the import does not touch your main keyring.

**Français** — Utilisez un GNUPGHOME temporaire pour ne pas toucher à votre trousseau principal.


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.01.label`

**English** — 01 Temporary keyring

**Français** — 01 Trousseau temporaire


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.01.title`

**English** — Temporary keyring

**Français** — Trousseau temporaire


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.02.body`

**English** — curl /.well-known/pgp-key.asc · gpg --import pgp-key.asc.

**Français** — curl /.well-known/pgp-key.asc · gpg --import pgp-key.asc.


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.02.label`

**English** — 02 Import public key

**Français** — 02 Importer la clé publique


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.02.title`

**English** — Import public key

**Français** — Importer la clé publique


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.03.body`

**English** — gpg --verify integrity.json.sig integrity.json - expect Good signature.

**Français** — gpg --verify integrity.json.sig integrity.json - attendre Good signature.


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.03.label`

**English** — 03 Verify signature

**Français** — 03 Vérifier la signature


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.03.title`

**English** — Verify signature

**Français** — Vérifier la signature


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.04.body`

**English** — /integrity.json lists every public file with its SHA-256.

**Français** — /integrity.json liste chaque fichier public avec son empreinte SHA-256.


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.04.label`

**English** — 04 Check manifest

**Français** — 04 Contrôler le manifeste


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.04.title`

**English** — Check manifest

**Français** — Contrôler le manifeste


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.05.body`

**English** — Re-hash any file and compare against the manifest entry.

**Français** — Re-hachez un fichier et comparez avec l’entrée du manifeste.


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.05.label`

**English** — 05 Compare checksums

**Français** — 05 Comparer les sommes


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.05.title`

**English** — Compare checksums

**Français** — Comparer les sommes


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.06.body`

**English** — Each signed edition is frozen in /integrity/releases/. No mutable assets.

**Français** — Chaque édition signée est figée dans /integrity/releases/. Aucun actif mutable.


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.06.label`

**English** — 06 Reproducibility notes

**Français** — 06 Notes de reproductibilité


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.06.title`

**English** — Reproducibility notes

**Français** — Notes de reproductibilité


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.doc_title`

**English** — Trent Power - Verify Locally

**Français** — Trent Power - Vérifier localement


<sub>source · `editorial copy register`</sub>


_STRING · verify_locally · print_  
`verify_locally.print.footer.edition`

**English** — Edition 2026-05-19 · trentpower.fr/integrity/verify-locally/

**Français** — Édition 2026-05-19 · trentpower.fr/integrity/verify-locally/


<sub>source · `editorial copy register`</sub>


_STRING · verify_locally · print_  
`verify_locally.print.footer.proof`

**English** — Private · Static · Signed · No tracking

**Français** — Privé · Statique · Signé · Sans suivi


<sub>source · `editorial copy register`</sub>


_KICKER · verify_locally · print_  
`verify_locally.print.kicker`

**English** — Integrity verification

**Français** — Vérification d’intégrité


<sub>source · `editorial copy register`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.lede`

**English** — Detached verification notes for independently checking the signed integrity manifest using the published public key.

**Français** — Notes de vérification détachée pour contrôler indépendamment le manifeste d’intégrité signé avec la clé publique publiée.


<sub>source · `editorial copy register`</sub>


_STRING · verify_locally · print_  
`verify_locally.print.meta`

**English** — Edition 2026-05-19 · trentpower.fr/integrity/verify-locally/

**Français** — Édition 2026-05-19 · trentpower.fr/integrity/verify-locally/


<sub>source · `editorial copy register`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.qr.label`

**English** — trentpower.fr/integrity/verify-locally/

**Français** — trentpower.fr/integrity/verify-locally/


<sub>source · `editorial copy register`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.title`

**English** — Verify locally

**Français** — Vérifier localement


<sub>source · `editorial copy register`</sub>


---

## Multilingual appendix

Side-by-side view of every fully-translated string. Rows where all five languages are present.

| Key | English | Français | Italiano | Español | Deutsch |
|---|---|---|---|---|---|
| acknowledgments.body_intro | This page records responsible security disclosures that have been verified and resolved. | Cette page recense les divulgations de sécurité responsables qui ont été vérifiées et résolues. |
| acknowledgments.integrity_link | Site integrity statement | Déclaration d’intégrité du site |
| acknowledgments.none | There are no acknowledgements at present. This reflects the absence of reportable disclosures to date, not the absence of review or maintenance. | Il n’y a pas de mentions pour le moment. Cela reflète l’absence de divulgations signalables à ce jour, et non l’absence de révision ou de maintenance. |
| acknowledgments.page_title | Security acknowledgements | Mentions de sécurité |
| acknowledgments.print.card.01.body | Coordinated, time-bounded, with credit on request. | Coordonné, à délai défini, crédit sur demande. |
| acknowledgments.print.card.01.label | 01 Disclosure model | 01 Modèle de divulgation |
| acknowledgments.print.card.01.title | Disclosure model | Modèle de divulgation |
| acknowledgments.print.card.02.body | trent@trentpower.fr · PGP-signed reports preferred · public key at /.well-known/pgp-key.asc. | trent@trentpower.fr · rapports signés PGP préférés · clé publique sur /.well-known/pgp-key.asc. |
| acknowledgments.print.card.02.label | 02 Reporting policy | 02 Politique de signalement |
| acknowledgments.print.card.02.title | Reporting policy | Politique de signalement |
| acknowledgments.print.card.03.body | Acknowledge within 72 hours. Patch, verify, publish notes if material. | Accusé de réception sous 72 heures. Correctif, vérification, notes publiques si nécessaire. |
| acknowledgments.print.card.03.label | 03 Coordinated remediation | 03 Remédiation coordonnée |
| acknowledgments.print.card.03.title | Coordinated remediation | Remédiation coordonnée |
| acknowledgments.print.card.04.body | Reproduce, hash, sign, and record in the next signed release. | Reproduction, empreinte, signature, et consignation dans la prochaine version signée. |
| acknowledgments.print.card.04.label | 04 Verification process | 04 Processus de vérification |
| acknowledgments.print.card.04.title | Verification process | Processus de vérification |
| acknowledgments.print.card.05.body | trent@trentpower.fr · fingerprint A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263. | trent@trentpower.fr · empreinte A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263. |
| acknowledgments.print.card.05.label | 05 Security contact | 05 Contact sécurité |
| acknowledgments.print.card.05.title | Security contact | Contact sécurité |
| acknowledgments.print.card.06.body | Acknowledgement page is the canonical record; updates accompany each signed edition. | La page de reconnaissances est le registre canonique ; mises à jour à chaque édition signée. |
| acknowledgments.print.card.06.label | 06 Publication status | 06 Statut de publication |
| acknowledgments.print.card.06.title | Publication status | Statut de publication |
| acknowledgments.print.doc_title | Trent Power - Security Acknowledgments | Trent Power - Reconnaissances de sécurité |
| acknowledgments.print.footer.edition | Edition 2026-05-19 · trentpower.fr/security/acknowledgments/ | Édition 2026-05-19 · trentpower.fr/security/acknowledgments/ |
| acknowledgments.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| acknowledgments.print.kicker | Security acknowledgments | Reconnaissances de sécurité |
| acknowledgments.print.lede | Acknowledgements for individuals and researchers who contributed responsibly to the security posture of this site. | Reconnaissances pour les personnes et les chercheurs ayant contribué de manière responsable à la posture de sécurité de ce site. |
| acknowledgments.print.meta | Edition 2026-05-19 · trentpower.fr/security/acknowledgments/ | Édition 2026-05-19 · trentpower.fr/security/acknowledgments/ |
| acknowledgments.print.qr.label | trentpower.fr/security/acknowledgments/ | trentpower.fr/security/acknowledgments/ |
| acknowledgments.print.title | Responsible disclosure record | Registre des divulgations responsables |
| acknowledgments.report | If you believe you have found a security issue with this site, please report it responsibly. Contact details and disclosure preferences are listed in security.txt. | Si vous pensez avoir trouvé un problème de sécurité sur ce site, veuillez le signaler de manière responsable. Les coordonnées et les préférences de divulgation sont indiquées dans security.txt. |
| approach.adoption_body | A strategy or technology only creates value when teams trust it and choose to use it. Trust must be earned, and utility must be proven. Client Advisors are first-line Clients and vital collaborators. | Une stratégie ou une technologie ne crée de la valeur que lorsque les équipes lui font confiance et choisissent de l’utiliser. La confiance se mérite, l’utilité se démontre. Les Conseillers Clients sont des Clients de première ligne et des collaborateurs essentiels. |
| approach.adoption_title | Adoption matters more than tools | L’adoption compte plus que les outils |
| approach.ai_body | Authenticity is a human advantage, and it cannot be automated. Trust, empathy, and judgement are built in the moment through tone and presence. I use AI to remove friction so people can show up more relevant, more consistent and more human, at scale. | L’authenticité est un avantage humain, elle ne peut pas être automatisée. La confiance, l’empathie et le jugement se construisent dans l’instant, à travers le ton et la présence. J’utilise l’IA pour réduire les frictions, afin que chacun puisse être plus pertinent, plus cohérent et plus humain, à grande échelle. |
| approach.ai_title | AI should amplify human relationships | L’IA doit amplifier les relations humaines |
| approach.clienteling_detail | <dfn id="clienteling-definition" itemprop="name">Clienteling</dfn> <span itemprop="description">is a discipline. It is the practice of transforming what a Client Advisor knows into something a Client feels. The moment interactions become mechanical, it stops being Clienteling.</span> | Le <dfn id="clienteling-definition" itemprop="name">clienteling</dfn> <span itemprop="description">est une discipline. C’est la pratique de transformer ce qu’un Conseiller Client sait en quelque chose qu’un Client ressent. Dès que les interactions deviennent mécaniques, ce n’est plus du clienteling.</span> |
| approach.clienteling_title | Clienteling converts transaction into meaning | Le clienteling transforme la transaction en sens |
| approach.governance_body | Clear ownership, cadence, and priorities create alignment, accelerate decisions, and enable scale. | Des responsabilités claires, une cadence régulière et des priorités créent l’alignement, accélèrent les décisions et permettent le passage à l’échelle. |
| approach.governance_title | Governance creates momentum | La gouvernance crée de l’élan |
| approach.growth_body | Lasting growth follows when elegant systems are in place. | Une croissance durable repose sur des systèmes élégants. |
| approach.growth_title | Client growth takes discipline | La croissance client exige une discipline |
| approach.label | Approach | Approche |
| approach.taste_body | Discernment, and cultural awareness shape interactions into something valuable and memorable. | Le discernement et la conscience culturelle façonnent les interactions en quelque chose de précieux et mémorable. |
| approach.taste_title | Taste is a strategic advantage | Le goût est un avantage stratégique |
| cite.copied | Copied | Copié |
| cite.edition_label | Edition | Édition |
| cite.hover | Copy citation | Copier la citation |
| cite.label.action | Cite & verify | Citer et vérifier |
| cite.overlay.action.close | Close | Fermer |
| cite.overlay.action.copy_citation | Copy citation | Copier la citation |
| cite.overlay.action.open_source | View source | Voir le code source |
| cite.overlay.action.print_home | Print profile | Imprimer le profil |
| cite.overlay.action.print_page | Print profile | Imprimer le profil |
| cite.overlay.action.print_sheet | Print profile | Imprimer le profil |
| cite.overlay.action.verify | Verify this page | Vérifier cette page |
| cite.overlay.action.view_integrity | View integrity record | Voir la notice d’intégrité |
| cite.overlay.footer_signed | Edition {edition} · Signed SHA256 | Édition {edition} · SHA256 signé |
| cite.overlay.kicker | This page | Cette page |
| cite.overlay.lede | Canonical publication record. | Notice de publication canonique. |
| cite.overlay.page_title.acknowledgments | Security acknowledgements | Remerciements de sécurité |
| cite.overlay.page_title.forbidden | Access not available | Accès non disponible |
| cite.overlay.page_title.home | Client Strategy & Growth Systems | Stratégie client et systèmes de croissance |
| cite.overlay.page_title.integrity | Integrity record | Notice d’intégrité |
| cite.overlay.page_title.integrity-verify-locally | Verify locally | Vérifier localement |
| cite.overlay.page_title.maintenance | Down for maintenance | Maintenance en cours |
| cite.overlay.page_title.not-found | Page not found | Page introuvable |
| cite.overlay.page_title.privacy | Privacy statement | Notice de confidentialité |
| cite.overlay.page_title.release-archive | Release archive · 2026-05-09 | Archive des versions · 2026-05-09 |
| cite.overlay.page_title.releases | Release archive | Archive des versions |
| cite.overlay.page_title.security | Security posture | Posture de sécurité |
| cite.overlay.page_title.server-error | Temporary server error | Erreur serveur temporaire |
| cite.overlay.page_title.source | Source reader | Lecteur de code source |
| cite.overlay.page_title.source-reader | Source reader | Lecteur de code source |
| cite.overlay.page_title.sw-reset | Service worker reset | Réinitialisation du service worker |
| cite.overlay.page_title.verify | Verify page | Page de vérification |
| cite.overlay.toast.citation_copied | Citation copied | Citation copiée |
| cite.site_label | Personal Site | Site personnel |
| contact.email_aria | Email Trent Power | Écrire à Trent Power |
| contact.headline | Write,<br>and I&rsquo;ll <em>write back.</em> | Écrivez-moi,<br>et je <em>vous répondrai.</em> |
| contact.label | Contact | Contact |
| copy.command | Copy command | Copier la commande |
| copy.copied | Copied | Copié |
| copy.failed | Copy failed | Échec de copie |
| credentials.exec_detail | Ongoing senior-level learning across artificial intelligence, consumer behaviour, organisational transformation, and leadership coaching. | Apprentissage senior en continu — intelligence artificielle, comportement consommateur, transformation organisationnelle et coaching en leadership. |
| credentials.exec_title | Selective executive education | Formation exécutive sélective |
| credentials.label | Credentials | Parcours académique |
| credentials.sydney_detail | Master’s degree, 2009. | Master, 2009. |
| credentials.sydney_title | University of Sydney | University of Sydney |
| error.403.print.card.01.body | Some paths are intentionally unavailable. Private, backup and operational files are blocked. | Certains chemins sont intentionnellement indisponibles. Les fichiers privés, de sauvegarde et opérationnels sont bloqués. |
| error.403.print.card.01.label | 01 Access boundary | 01 Limite d’accès |
| error.403.print.card.01.title | Access boundary | Limite d’accès |
| error.403.print.card.02.body | Homepage. Privacy & Trust. Integrity. Security. Source. | Accueil. Confidentialité & confiance. Intégrité. Sécurité. Source. |
| error.403.print.card.02.label | 02 Public routes | 02 Voies publiques |
| error.403.print.card.02.title | Public routes | Voies publiques |
| error.403.print.card.03.body | Reduces accidental exposure. Keeps public files intentional. Supports privacy and trust posture. | Réduit l’exposition accidentelle. Maintient des fichiers publics intentionnels. Soutient la posture de confidentialité et de confiance. |
| error.403.print.card.03.label | 03 Why this matters | 03 Pourquoi |
| error.403.print.card.03.title | Why this matters | Pourquoi |
| error.403.print.card.04.body | Inspect /integrity.json. View selected source files. Check /.well-known/security.txt. | Inspecter /integrity.json. Voir les fichiers sources sélectionnés. Consulter /.well-known/security.txt. |
| error.403.print.card.04.label | 04 Verification | 04 Vérification |
| error.403.print.card.04.title | Verification | Vérification |
| error.403.print.card.05.body | No public database. No visitor accounts. No forms. No tracking. | Aucune base de données publique. Aucun compte visiteur. Aucun formulaire. Sans suivi. |
| error.403.print.card.05.label | 05 Static posture | 05 Posture statique |
| error.403.print.card.05.title | Static posture | Posture statique |
| error.403.print.card.06.body | trent@trentpower.fr · responsible disclosure via /security/ | trent@trentpower.fr · divulgation responsable via /security/ |
| error.403.print.card.06.label | 06 Contact | 06 Contact |
| error.403.print.card.06.title | Contact | Contact |
| error.403.print.doc_title | Trent Power - Access Boundary Sheet | Trent Power - Limite d’accès |
| error.403.print.footer.edition | Edition 2026-05-19 · trentpower.fr | Édition 2026-05-19 · trentpower.fr |
| error.403.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| error.403.print.kicker | 403 | 403 |
| error.403.print.lede | This path is not publicly accessible. The public site exposes only intentional files and pages. | Ce chemin n’est pas accessible publiquement. Le site public n’expose que des fichiers et pages intentionnels. |
| error.403.print.meta | Edition 2026-05-19 · trentpower.fr | Édition 2026-05-19 · trentpower.fr |
| error.403.print.qr.label | trentpower.fr | trentpower.fr |
| error.403.print.title | Access not available | Accès indisponible |
| error.404.print.card.01.body | The requested route does not resolve to a public page. The site remains available through the homepage. | L’adresse demandée ne correspond à aucune page publique. Le site reste accessible depuis l’accueil. |
| error.404.print.card.01.label | 01 What happened | 01 Ce qui s’est passé |
| error.404.print.card.01.title | What happened | Ce qui s’est passé |
| error.404.print.card.02.body | Homepage. Privacy & Trust. Integrity. Security. | Accueil. Confidentialité & confiance. Intégrité. Sécurité. |
| error.404.print.card.02.label | 02 Where to go | 02 Où aller |
| error.404.print.card.02.title | Where to go | Où aller |
| error.404.print.card.03.body | Public manifest. Source view. Signed releases. | Manifeste public. Vue source. Versions signées. |
| error.404.print.card.03.label | 03 Verification | 03 Vérification |
| error.404.print.card.03.title | Verification | Vérification |
| error.404.print.card.04.body | Check the URL. Remove outdated path fragments. Try the canonical homepage. | Vérifier l’URL. Retirer les fragments obsolètes. Essayer la page d’accueil canonique. |
| error.404.print.card.04.label | 04 If this was expected | 04 Si c’était attendu |
| error.404.print.card.04.title | If expected | Si attendu |
| error.404.print.card.05.body | Static site. No tracking. No forms. No third-party scripts. | Site statique. Sans suivi. Sans formulaire. Sans script tiers. |
| error.404.print.card.05.label | 05 Public posture | 05 Posture publique |
| error.404.print.card.05.title | Public posture | Posture publique |
| error.404.print.card.06.body | trent@trentpower.fr · LinkedIn · Trent Power | trent@trentpower.fr · LinkedIn · Trent Power |
| error.404.print.card.06.label | 06 Contact | 06 Contact |
| error.404.print.card.06.title | Contact | Contact |
| error.404.print.doc_title | Trent Power - Page Not Found Sheet | Trent Power - Page introuvable |
| error.404.print.footer.edition | Edition 2026-05-19 · trentpower.fr | Édition 2026-05-19 · trentpower.fr |
| error.404.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| error.404.print.kicker | 404 | 404 |
| error.404.print.lede | The address may have changed, or the page may no longer be part of the public site. | L’adresse a peut-être changé, ou la page ne fait plus partie du site public. |
| error.404.print.meta | Edition 2026-05-19 · trentpower.fr | Édition 2026-05-19 · trentpower.fr |
| error.404.print.qr.label | trentpower.fr | trentpower.fr |
| error.404.print.title | Page not found | Page introuvable |
| error.500.print.card.01.body | The server could not complete the request. Try again shortly. | Le serveur n’a pas pu traiter la requête. Réessayer dans un instant. |
| error.500.print.card.01.label | 01 What happened | 01 Ce qui s’est passé |
| error.500.print.card.01.title | What happened | Ce qui s’est passé |
| error.500.print.card.02.body | Homepage. Integrity. Security. Source. | Accueil. Intégrité. Sécurité. Source. |
| error.500.print.card.02.label | 02 Stable routes | 02 Voies stables |
| error.500.print.card.02.title | Stable routes | Voies stables |
| error.500.print.card.03.body | /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc | /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc |
| error.500.print.card.03.label | 03 Public verification | 03 Vérification publique |
| error.500.print.card.03.title | Public verification | Vérification publique |
| error.500.print.card.04.body | Static HTML, CSS and JavaScript. No runtime public application. No public database. | HTML, CSS et JavaScript statiques. Aucune application publique à l’exécution. Aucune base de données publique. |
| error.500.print.card.04.label | 04 Architecture | 04 Architecture |
| error.500.print.card.04.title | Architecture | Architecture |
| error.500.print.card.05.body | Refresh later. Return to homepage. Contact if persistent. | Rafraîchir plus tard. Revenir à l’accueil. Contacter si persistant. |
| error.500.print.card.05.label | 05 What to do | 05 Que faire |
| error.500.print.card.05.title | What to do | Que faire |
| error.500.print.card.06.body | trent@trentpower.fr · LinkedIn · Trent Power | trent@trentpower.fr · LinkedIn · Trent Power |
| error.500.print.card.06.label | 06 Contact | 06 Contact |
| error.500.print.card.06.title | Contact | Contact |
| error.500.print.doc_title | Trent Power - Temporary Server Error Sheet | Trent Power - Erreur serveur temporaire |
| error.500.print.footer.edition | Edition 2026-05-19 · trentpower.fr | Édition 2026-05-19 · trentpower.fr |
| error.500.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| error.500.print.kicker | 500 | 500 |
| error.500.print.lede | Something unexpected happened while serving this page. The public site is static, so this is likely a hosting or routing issue rather than an application failure. | Un événement inattendu est survenu lors du chargement de cette page. Le site public étant statique, il s’agit probablement d’un incident d’hébergement ou de routage plutôt que d’une défaillance applicative. |
| error.500.print.meta | Edition 2026-05-19 · trentpower.fr | Édition 2026-05-19 · trentpower.fr |
| error.500.print.qr.label | trentpower.fr | trentpower.fr |
| error.500.print.title | Temporary server error | Erreur serveur temporaire |
| error_404.body | The page you’re looking for doesn’t exist or has moved. | La page que vous recherchez n’existe pas ou a été déplacée. |
| error_404.page_title | Page not found | Page introuvable |
| error_500.body | The server encountered an error. Try again shortly, or return to the homepage. | Le serveur a rencontré une erreur. Réessayez dans quelques instants ou retournez à la page d’accueil. |
| error_500.page_title | Something went wrong | Une erreur s’est produite |
| footer.lang_toggle | FR | EN |
| footer.location | Paris, France | Paris, France |
| footer.privacy | Privacy | Confidentialité |
| footer.proof.edition | Edition | Édition |
| footer.proof.last_verified | Verified | Vérifié |
| footer.proof.relative.days | {n} days ago | il y a {n} jours |
| footer.proof.relative.months | {n} months ago | il y a {n} mois |
| footer.proof.relative.today | today | aujourd'hui |
| footer.proof.relative.years | {n} years ago | il y a {n} ans |
| footer.proof.relative.yesterday | yesterday | hier |
| footer.proof.sha_title | View this page's entry in the signed integrity manifest | Voir l'entrée de cette page dans le manifeste d'intégrité signé |
| footer.proof.signed | SHA256 | SHA256 |
| footer.provenance.line | Machine-translated from the English original. | Traduction automatique de l’édition anglaise originale. |
| footer.theme.auto | Auto | Auto |
| footer.theme.dark | Dark | Sombre |
| footer.theme.light | Light | Clair |
| footer.verify | Verify | Vérifier |
| hero.body | I lead client strategy at Group level, focusing on the systems, governance, and ways of working that turn client relationships into long-term value. My work sits at the intersection of strategy, technology, and human relationships, with a focus on impact that scales and endures. | Je pilote la stratégie client au niveau du Groupe, en me concentrant sur les systèmes, la gouvernance et les façons de travailler qui transforment les relations clients en valeur à long terme. Mon travail se situe à l’intersection de la stratégie, de la technologie et des relations humaines, avec un impact qui se déploie à grande échelle et dans la durée. |
| hero.statement | Client strategy,<br><mark>growth systems,</mark><br>and cultural adoption<br>at global scale. | Stratégie client,<br><mark>systèmes de croissance,</mark><br>et adoption culturelle<br>à l’échelle mondiale. |
| home.trust_no_tracking | no tracking | sans suivi |
| home.trust_privacy | privacy-first | confidentialité d’abord |
| home.trust_signed | signed releases | versions signées |
| home.trust_static | static | statique |
| integrity.body_intro | Every public file is hashed and listed in a manifest, signed with a detached <abbr title="Pretty Good Privacy">PGP</abbr> signature so each release can be checked against the publisher's key - independently, on your own machine, without trust in this server. You can <a href="/integrity/verify-locally/" aria-describedby="desc-verify-locally">verify locally here</a>. | Chaque fichier public est haché et listé dans un manifeste, signé par une signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée — chaque version peut donc être vérifiée avec la clé de l’éditeur, en local, sans confiance envers ce serveur. Vous pouvez <a href="/integrity/verify-locally/" aria-describedby="desc-verify-locally">vérifier localement ici</a>. |
| integrity.copy_button | Copy | Copier |
| integrity.copy_button_done | Copied | Copié |
| integrity.file_integrity | /integrity.json · SHA-256 hashes of all public assets | /integrity.json · hachages SHA-256 de tous les fichiers publics |
| integrity.file_key | /.well-known/pgp-key.asc · public signing key | /.well-known/pgp-key.asc · clé de signature publique |
| integrity.file_sig | /integrity.json.sig · detached PGP signature | /integrity.json.sig · signature PGP détachée |
| integrity.fingerprint_copied | Copied | Copiée |
| integrity.fingerprint_copy | Copy fingerprint | Copier l’empreinte |
| integrity.page_h1 | <span class="hero-line">Signed.</span><span class="hero-line">Verifiable.</span><span class="hero-line">Reproducible.</span> | <span class="hero-line">Signé.</span><span class="hero-line">Vérifiable.</span><span class="hero-line">Reproductible.</span> |
| integrity.page_kicker | Integrity | Intégrité |
| integrity.page_title | Integrity | Intégrité |
| integrity.print.card.01.body | <code>/integrity.json</code> - <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> hashes of every intentional public file. | <code>/integrity.json</code> - empreintes <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> de chaque fichier public intentionnel. |
| integrity.print.card.01.label | 01 Manifest | 01 Manifeste |
| integrity.print.card.01.title | Manifest | Manifeste |
| integrity.print.card.02.body | /integrity.json.sig - detached <abbr title="Pretty Good Privacy">PGP</abbr> signature that verifies the manifest. | /integrity.json.sig - signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée qui certifie le manifeste. |
| integrity.print.card.02.label | 02 Signature | 02 Signature |
| integrity.print.card.02.title | Detached signature | Signature détachée |
| integrity.print.card.03.body | /.well-known/pgp-key.asc - fingerprint A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263. | /.well-known/pgp-key.asc - empreinte A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263. |
| integrity.print.card.03.label | 03 Public key | 03 Clé publique |
| integrity.print.card.03.title | Public key | Clé publique |
| integrity.print.card.04.body | /integrity/releases/ - public snapshots: February 2026 and May 2026. | /integrity/releases/ - instantanés publics : février 2026 et mai 2026. |
| integrity.print.card.04.label | 04 Releases | 04 Versions |
| integrity.print.card.04.title | Frozen releases | Versions figées |
| integrity.print.card.05.body | /source/ - public text view of selected source files. No secrets, no private artefacts. | /source/ - vue texte publique de fichiers sources sélectionnés. Aucun secret, aucun artefact privé. |
| integrity.print.card.05.label | 05 Source route | 05 Voie source |
| integrity.print.card.05.title | Source route | Voie source |
| integrity.print.card.06.body | curl -O trentpower.fr/integrity.json && curl -O trentpower.fr/integrity.json.sig && gpg --verify integrity.json.sig integrity.json | curl -O trentpower.fr/integrity.json && curl -O trentpower.fr/integrity.json.sig && gpg --verify integrity.json.sig integrity.json |
| integrity.print.card.06.label | 06 Verification | 06 Vérification |
| integrity.print.card.06.title | Verification | Vérification |
| integrity.print.doc_title | Trent Power - Integrity Verification Sheet | Trent Power - Certificat d’intégrité |
| integrity.print.footer.edition | Edition 2026-05-19 · trentpower.fr/integrity/ | Édition 2026-05-19 · trentpower.fr/integrity/ |
| integrity.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| integrity.print.kicker | Integrity | Intégrité |
| integrity.print.lede | Published files are listed in a public manifest and signed with a detached <abbr title="Pretty Good Privacy">PGP</abbr> signature so updates can be verified independently. | Les fichiers publiés sont listés dans un manifeste public et signés par une signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée afin que toute mise à jour puisse être vérifiée de manière indépendante. |
| integrity.print.meta | Edition 2026-05-19 · trentpower.fr/integrity/ | Édition 2026-05-19 · trentpower.fr/integrity/ |
| integrity.print.qr.label | trentpower.fr/integrity/ | trentpower.fr/integrity/ |
| integrity.print.title | Signed public verification | Vérification publique signée |
| integrity.record.action.view_manifest | View manifest | Voir le manifeste |
| integrity.record.action.view_releases | View releases | Voir les éditions |
| integrity.record.desc.archives | Signed public source release | Édition publique signée des sources |
| integrity.record.desc.checksums | Signed checksum list for archive downloads | Liste de sommes de contrôle signée pour les archives |
| integrity.record.desc.manifest | <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> hashes of public files | Empreintes <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> des fichiers publics |
| integrity.record.desc.public_key | Public signing key | Clé publique de signature |
| integrity.record.desc.signature | Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature | Signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée |
| integrity.record.group.archives | Source archives | Archives source |
| integrity.record.group.fingerprint | Release fingerprint | Empreinte de version |
| integrity.record.group.verification | Verification records | Pièces de vérification |
| integrity.record.kicker | Signed release | Édition signée |
| integrity.record.label.archives | Archives | Archives |
| integrity.record.label.checksums | Archive checksums | Sommes de contrôle |
| integrity.record.label.fingerprint | Fingerprint | Empreinte |
| integrity.record.label.manifest | Manifest | Manifeste |
| integrity.record.label.public_key | Public key | Clé publique |
| integrity.record.label.signature | Detached signature | Signature détachée |
| integrity.record.status_short | Manifest · Signature · Public key | Manifeste · Signature · Clé publique |
| integrity.record.title | <time datetime="2026-05">May 2026</time> | <time datetime="2026-05">Mai 2026</time> |
| integrity.verify_release_local.note | Run the signed manifest check in a temporary keyring. | Exécute la vérification du manifeste signé dans un trousseau temporaire. |
| integrity.verify_release_local.summary | Advanced local verification | Vérification locale avancée |
| jsonld.home.Person.disambiguatingDescription | Client strategy, growth systems and cultural adoption at global scale | Stratégie client, systèmes de croissance et adoption culturelle à l'échelle mondiale |
| jsonld.home.Person.jobTitle | Group Director, Client Development & Client Relations | Directeur Groupe, Développement Client & Relations Clients |
| linkdesc.checksums | Download the SHA-256 checksums for the signed release archives | Télécharger les empreintes SHA-256 des archives de publication signées |
| linkdesc.cite | Open citation and verification details for this page | Ouvrir les détails de citation et de vérification de cette page |
| linkdesc.email | Contact Trent Power by email | Contacter Trent Power par e-mail |
| linkdesc.home | Return to the homepage | Retour à l’accueil |
| linkdesc.integrity | Open the public integrity record, including hashes, signatures, and release verification | Ouvrir le registre d’intégrité public — empreintes, signatures et vérification des éditions |
| linkdesc.lang_en | Read this site in English | Read this site in English |
| linkdesc.lang_fr | Lire ce site en français | Lire ce site en français |
| linkdesc.linkedin | Open Trent Power’s LinkedIn profile in a new tab without sending referrer data | Ouvrir le profil LinkedIn de Trent Power dans un nouvel onglet, sans transmettre l’URL d’origine |
| linkdesc.manifest | Download the signed integrity manifest (JSON listing every public file and its SHA-256) | Télécharger le manifeste d’intégrité signé (JSON listant chaque fichier public et son SHA-256) |
| linkdesc.now | Read what Trent Power is currently focused on | Lire ce sur quoi Trent Power se concentre actuellement |
| linkdesc.privacy | Read how this site avoids analytics, cookies, profiling, tracking, and third-party assets | Découvrir comment ce site évite les analytiques, cookies, profilage, traceurs et services tiers |
| linkdesc.public_key | Download the public PGP key used to sign releases | Télécharger la clé PGP publique utilisée pour signer les publications |
| linkdesc.security_contact | Read the security.txt disclosure policy for this site | Lire la politique de divulgation security.txt de ce site |
| linkdesc.security_threat_model | Read the security architecture and threat model for this site | Lire le modèle de sécurité et l’analyse de menace de ce site |
| linkdesc.signature | Download the detached PGP signature for the integrity manifest | Télécharger la signature PGP détachée du manifeste d’intégrité |
| linkdesc.source | View the public source mirror of this site, with readable annotations and line references | Consulter le miroir source public du site, annoté et numéroté |
| linkdesc.targz | Download the source archive as a TAR.GZ file | Télécharger l’archive source au format TAR.GZ |
| linkdesc.theme_auto | Match the system appearance setting | Suivre les réglages d’apparence du système |
| linkdesc.theme_dark | Switch to the dark appearance | Passer à l’apparence sombre |
| linkdesc.theme_light | Switch to the light appearance | Passer à l’apparence claire |
| linkdesc.verify | Check the current page against the published integrity data | Vérifier la page courante contre le registre d’intégrité publié |
| linkdesc.verify_locally | Read the instructions to verify the publication locally with command-line tools | Lire les instructions pour vérifier la publication localement en ligne de commande |
| linkdesc.zip | Download the source archive as a ZIP file | Télécharger l’archive source au format ZIP |
| maintenance.body | The signed manifest, source mirrors and frozen release archives remain available throughout maintenance. Verification continues to work. | Le manifeste signé, les miroirs source et les archives de versions restent accessibles pendant la maintenance. La vérification reste opérationnelle. |
| maintenance.kicker | Maintenance | Maintenance |
| maintenance.lede | We're doing some work here. Check back shortly, or return to the homepage. | Des travaux sont en cours. Revenez dans quelques instants ou retournez à la page d'accueil. |
| maintenance.page_title | Down for maintenance | En maintenance |
| maintenance.print.card.01.body | A signed release or infrastructure update is in progress. | Une version signée ou une mise à jour d’infrastructure est en cours. |
| maintenance.print.card.01.label | 01 Deployment state | 01 État de déploiement |
| maintenance.print.card.01.title | Deployment state | État de déploiement |
| maintenance.print.card.02.body | The previous signed edition remains downloadable in /integrity/releases/. | L’édition signée précédente reste téléchargeable dans /integrity/releases/. |
| maintenance.print.card.02.label | 02 Integrity preservation | 02 Préservation d’intégrité |
| maintenance.print.card.02.title | Integrity preservation | Préservation d’intégrité |
| maintenance.print.card.03.body | Service returns automatically when the new edition is signed and verified. | Le service revient automatiquement dès que la nouvelle édition est signée et vérifiée. |
| maintenance.print.card.03.label | 03 Public availability | 03 Disponibilité publique |
| maintenance.print.card.03.title | Public availability | Disponibilité publique |
| maintenance.print.card.04.body | Archived editions stay reachable independently of this maintenance window. | Les éditions archivées restent accessibles indépendamment de cette fenêtre de maintenance. |
| maintenance.print.card.04.label | 04 Signed releases | 04 Versions signées |
| maintenance.print.card.04.title | Signed releases | Versions signées |
| maintenance.print.card.05.body | trent@trentpower.fr - for inquiries during extended unavailability. | trent@trentpower.fr - pour toute demande en cas d’indisponibilité prolongée. |
| maintenance.print.card.05.label | 05 Maintenance contact | 05 Contact de maintenance |
| maintenance.print.card.05.title | Maintenance contact | Contact de maintenance |
| maintenance.print.card.06.body | Canonical URLs are preserved across editions; bookmarks remain valid. | Les URL canoniques sont préservées d’une édition à l’autre ; vos signets restent valides. |
| maintenance.print.card.06.label | 06 Expected continuity | 06 Continuité attendue |
| maintenance.print.card.06.title | Expected continuity | Continuité attendue |
| maintenance.print.doc_title | Trent Power - Maintenance | Trent Power - Maintenance |
| maintenance.print.footer.edition | Edition 2026-05-19 · trentpower.fr/maintenance.html | Édition 2026-05-19 · trentpower.fr/maintenance.html |
| maintenance.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| maintenance.print.kicker | Maintenance status | État de maintenance |
| maintenance.print.lede | This site is temporarily unavailable while a new signed edition or infrastructure update is being deployed. | Ce site est temporairement indisponible pendant le déploiement d’une nouvelle édition signée ou d’une mise à jour d’infrastructure. |
| maintenance.print.meta | Edition 2026-05-19 · trentpower.fr/maintenance.html | Édition 2026-05-19 · trentpower.fr/maintenance.html |
| maintenance.print.qr.label | trentpower.fr/maintenance.html | trentpower.fr/maintenance.html |
| maintenance.print.title | Temporary maintenance mode | Mode maintenance temporaire |
| maintenance.title | Down for maintenance | En maintenance |
| meta.403.description | Access not permitted. | Accès non autorisé. |
| meta.403.title | Forbidden · Trent Power | Accès refusé · Trent Power |
| meta.404.description | Page not found. | Page introuvable. |
| meta.404.title | Page not found · Trent Power | Page introuvable · Trent Power |
| meta.500.description | Something went wrong. | Une erreur s’est produite. |
| meta.500.title | Something went wrong · Trent Power | Une erreur est survenue · Trent Power |
| meta.acknowledgments.description | Responsible security disclosures verified and resolved for trentpower.fr. | Divulgations de sécurité responsables vérifiées et résolues pour trentpower.fr. |
| meta.acknowledgments.title | Security acknowledgements · Trent Power | Remerciements de sécurité · Trent Power |
| meta.home.description | Client strategy, growth systems and cultural adoption at global scale | Stratégie client, systèmes de croissance et adoption culturelle à l’échelle mondiale |
| meta.home.og_description | Client strategy, growth systems and cultural adoption at global scale | Stratégie client, systèmes de croissance et adoption culturelle à l’échelle mondiale |
| meta.home.og_title | Client Strategy & Growth Systems · Trent Power | Stratégie Client & Systèmes de Croissance · Trent Power |
| meta.home.title | Client Strategy & Growth Systems · Trent Power | Stratégie Client & Systèmes de Croissance · Trent Power |
| meta.integrity.description | Signed public releases, integrity manifest, detached signature and public signing key | Éditions publiques signées, manifeste d’intégrité, signature détachée et clé publique |
| meta.integrity.title | Integrity · Trent Power | Intégrité · Trent Power |
| meta.maintenance.description | Down for maintenance. | En maintenance. |
| meta.maintenance.title | Down for maintenance · Trent Power | En maintenance · Trent Power |
| meta.privacy.description | A simple, privacy-respectful site with no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse | Un site simple et respectueux de la vie privée, sans suivi, analytique, cookies, profilage ni requêtes tierces intégrées pendant la navigation |
| meta.privacy.title | Privacy & Trust · Trent Power | Confidentialité & confiance · Trent Power |
| meta.releases.description | Frozen, signed snapshots of the public site | Instantanés signés et figés du site public |
| meta.releases.title | Releases · Trent Power | Éditions · Trent Power |
| meta.security.description | Security architecture, operational controls, public verification surfaces and residual risks | Architecture de sécurité, contrôles opérationnels, surfaces publiques de vérification et risques résiduels |
| meta.security.title | Security & Threat Model · Trent Power | Sécurité & modèle de menace · Trent Power |
| meta.source.description | Readable public mirrors of selected site files | Miroirs publics lisibles d’une sélection de fichiers du site |
| meta.source.title | Source mirrors · Trent Power | Miroirs source · Trent Power |
| meta.verify.description | A public page record showing the canonical URL, source mirror, page fingerprint and signed release archive | Document public présentant l’URL canonique, le miroir source, l’empreinte et l’archive d’édition signée |
| meta.verify.title | Verify this page · Trent Power | Vérifier cette page · Trent Power |
| meta.verify_locally.description | Detached verification notes: signed manifest check from a temporary keyring | Notes de vérification détachées : contrôle du manifeste signé depuis un trousseau temporaire |
| meta.verify_locally.title | Verify locally · Trent Power | Vérifier localement · Trent Power |
| modal.close | Close | Fermer |
| modal.cta_aria | Request access by email | Demander l’accès par e-mail |
| modal.cta_label | Access by request | Sur demande |
| modal.text | This is a personal project. If you'd like to see it, I'd be happy to share access. | C’est un projet personnel. Si vous souhaitez y accéder, je serais heureux de vous en donner l’accès. |
| print.arch.archive | Archive | Archive |
| print.arch.browser | Browser | Navigateur |
| print.arch.cache | Offline Cache | Cache |
| print.arch.caption | Static, privacy-first, signed and inspectable | Statique, respectueux de la vie privée, signé et inspectable |
| print.arch.files | Site Files | Fichiers |
| print.arch.host | Static Host | Hébergement |
| print.arch.trust | Trust | Confiance |
| print.body | I lead client strategy at Group level, focusing on the systems, governance and ways of working that turn client relationships into long-term value. My work sits at the intersection of strategy, technology and human relationships, with a focus on impact that scales and endures. | Je dirige la stratégie client au niveau Groupe, en me concentrant sur les systèmes, la gouvernance et les méthodes de travail qui transforment les relations clients en valeur durable. Mon travail se situe à l’intersection de la stratégie, de la technologie et des relations humaines, avec un impact qui passe à l’échelle et qui dure. |
| print.contact.linkedin | LinkedIn · Trent Power | LinkedIn · Trent Power |
| print.credentials.exec_detail | Ongoing senior-level learning across artificial intelligence, consumer behaviour, organisational transformation, and leadership coaching. | Apprentissage senior en continu — intelligence artificielle, comportement consommateur, transformation organisationnelle et coaching en leadership. |
| print.credentials.exec_title | Selective executive education | Formation exécutive sélective |
| print.credentials.label | Credentials | Parcours académique |
| print.credentials.sydney_detail | Master’s degree, 2009. | Master, 2009. |
| print.credentials.sydney_title | University of Sydney | University of Sydney |
| print.doc_title | Trent Power - Client Strategy Executive Profile | Trent Power - Profil exécutif stratégie client |
| print.focus.01.body | Lasting growth follows when strong systems are in place. | Une croissance durable repose sur des systèmes solides. |
| print.focus.01.label | 01 Focus | 01 Focus |
| print.focus.01.title | Client growth takes discipline | La croissance client exige une discipline |
| print.focus.02.body | Technology creates value when teams trust it, choose it and use it. | La technologie crée de la valeur quand les équipes lui font confiance, la choisissent et l’utilisent. |
| print.focus.02.label | 02 Adoption | 02 Adoption |
| print.focus.02.title | Adoption matters more than tools | L’adoption compte plus que les outils |
| print.focus.03.body | Authenticity remains a human advantage; automation must strengthen context, memory and care. | L’authenticité reste un avantage humain ; l’automatisation doit renforcer le contexte, la mémoire et l’attention. |
| print.focus.03.label | 03 Human relationships | 03 Relations humaines |
| print.focus.03.title | AI should amplify human relationships | L’IA doit amplifier les relations humaines |
| print.focus.04.body | Clear ownership and disciplined priorities create alignment and scale. | Un cadre de responsabilité clair et des priorités disciplinées créent l’alignement et l’échelle. |
| print.focus.04.label | 04 Governance | 04 Gouvernance |
| print.focus.04.title | Governance creates momentum | La gouvernance crée de l’élan |
| print.footer.citation | Trent Power. Personal Site. Paris, France. | Trent Power. Site personnel. Paris, France. |
| print.footer.edition | Edition <time datetime="2026-05-19">2026-05-19</time> · https://trentpower.fr/ | Édition <time datetime="2026-05-19">2026-05-19</time> · https://trentpower.fr/ |
| print.footer.evidence | Public record · HTML · Edition 19 May 2026 | Document public · HTML · Édition du 19 mai 2026 |
| print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| print.kicker | trentpower.fr | trentpower.fr |
| print.name | Trent Power | Trent Power |
| print.place | Personal Site · Paris, France | Site personnel · Paris, France |
| print.project.body | A private cultural intelligence system for Paris, combining location, effort, editorial judgement and personal taste into a calmer way to decide what is worth leaving home for. | Un système privé d’intelligence culturelle pour Paris, combinant localisation, effort, jugement éditorial et goût personnel pour décider plus calmement de ce qui mérite que l’on sorte de chez soi. |
| print.project.label | Proof point | Point de preuve |
| print.project.note | A personal experiment in taste systems, local relevance and human-scale recommendation. | Une expérimentation personnelle sur les systèmes de goût, la pertinence locale et la recommandation à échelle humaine. |
| print.project.title | What’s On in Paris | What’s On in Paris |
| print.role | Client strategy, growth systems and cultural adoption | Stratégie client, systèmes de croissance et adoption culturelle |
| print.title | Client strategy, growth systems and cultural adoption at global scale | Stratégie client, systèmes de croissance et adoption culturelle à l’échelle mondiale |
| print.trajectory.background.body | Early digital and entrepreneurial work building online platforms and communities | Travaux digitaux et entrepreneuriaux fondateurs : plateformes et communautés en ligne |
| print.trajectory.background.label | Background | Parcours initial |
| print.trajectory.current.body | Group Director, Client Development & Client Relations · LVMH | Directeur Groupe, Développement Client & Relations Clients · LVMH |
| print.trajectory.current.label | Current | Actuel |
| print.trajectory.label | Trajectory | Parcours |
| print.trajectory.previous.body | Senior leadership across Clienteling, CRM and Client Development | Direction senior en Clienteling, CRM et Développement Client |
| print.trajectory.previous.label | Previous | Précédent |
| privacy.body_detail | External links are ordinary references. They are contacted only if you choose to open them. The only browser storage used is a local language preference. It stays on your device and is never transmitted. | Les liens externes sont de simples références. Ils ne sont contactés que si vous choisissez de les ouvrir. Le seul stockage navigateur utilisé est une préférence de langue locale. Elle reste sur votre appareil et n’est jamais transmise. |
| privacy.body_intro | No tracking, analytics, cookies, profiling, embedded third-party services, or third-party requests while you browse. No personal data is collected for analytics, advertising, or profiling. Any limited technical data the server processes is used only to keep the site secure and operating correctly. | Aucun suivi, aucune analytique, aucun cookie, aucun profilage, aucun service tiers intégré, ni requête vers des tiers pendant votre navigation. Aucune donnée personnelle n’est collectée à des fins d’analyse, de publicité ou de profilage. Les données techniques limitées traitées par le serveur servent uniquement à assurer la sécurité et le bon fonctionnement du site. |
| privacy.body_records | Public inspection and verification records are published separately. You can read the <a href="/security/" aria-describedby="desc-security-threat-model">Security & threat model</a> for the full posture. | Les registres d’inspection publique et de vérification sont publiés séparément. Vous pouvez consulter le <a href="/security/" aria-describedby="desc-security-threat-model">Modèle de sécurité et de menaces</a> pour la posture complète. |
| privacy.page_h1 | <span class="hero-line">Nothing tracked.</span><span class="hero-line">Nothing to delete.</span> | <span class="hero-line">Rien n’est suivi.</span><span class="hero-line">Rien à supprimer.</span> |
| privacy.page_kicker | Privacy & Trust | Confidentialité & confiance |
| privacy.page_title | Privacy & Trust | Confidentialité & confiance |
| privacy.print.card.01.body | No analytics. No cookies. No profiling. No third-party requests while browsing. | Aucune analytique. Aucun cookie. Aucun profilage. Aucune requête tierce pendant la navigation. |
| privacy.print.card.01.label | 01 No tracking | 01 Aucun suivi |
| privacy.print.card.01.title | No tracking | Aucun suivi |
| privacy.print.card.02.body | No public forms. No visitor accounts. No behavioural tracking. No advertising infrastructure. | Aucun formulaire public. Aucun compte visiteur. Aucun suivi comportemental. Aucune infrastructure publicitaire. |
| privacy.print.card.02.label | 02 No data collection | 02 Aucune collecte |
| privacy.print.card.02.title | No data collection | Aucune collecte de données |
| privacy.print.card.03.body | Integrity page. Security page. Public manifest. Source view. | Page Intégrité. Page Sécurité. Manifeste public. Vue source. |
| privacy.print.card.03.label | 03 Verification route | 03 Voie de vérification |
| privacy.print.card.03.title | Verification route | Voie de vérification |
| privacy.print.card.04.body | Privacy is not a compliance layer. It is part of the site’s editorial and professional posture. | La confidentialité n’est pas une couche de conformité. Elle fait partie de la posture éditoriale et professionnelle du site. |
| privacy.print.card.04.label | 04 Design principle | 04 Principe de conception |
| privacy.print.card.04.title | Privacy as posture | La privacy comme posture |
| privacy.print.card.05.body | View source. Read /integrity.json. Verify the signature. Inspect the security headers. | Voir la source. Lire /integrity.json. Vérifier la signature. Inspecter les en-têtes de sécurité. |
| privacy.print.card.05.label | 05 What you can check | 05 Ce que vous pouvez vérifier |
| privacy.print.card.05.title | What you can check | Ce que vous pouvez vérifier |
| privacy.print.card.06.body | trent@trentpower.fr · canonical route trentpower.fr/privacy/ | trent@trentpower.fr · route canonique trentpower.fr/privacy/ |
| privacy.print.card.06.label | 06 Contact | 06 Contact |
| privacy.print.card.06.title | Contact | Contact |
| privacy.print.doc_title | Trent Power - Privacy Trust Sheet | Trent Power - Profil de confidentialité |
| privacy.print.footer.edition | Edition 2026-05-19 · trentpower.fr/privacy/ | Édition 2026-05-19 · trentpower.fr/privacy/ |
| privacy.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| privacy.print.kicker | Privacy & Trust | Confidentialité & confiance |
| privacy.print.lede | This site is intentionally simple and privacy-respectful. It uses no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse. | Ce site est volontairement simple et respectueux de la vie privée. Il n’utilise ni suivi, ni analytique, ni cookies, ni profilage, ni requêtes tierces intégrées pendant la navigation. |
| privacy.print.meta | Edition 2026-05-19 · trentpower.fr/privacy/ | Édition 2026-05-19 · trentpower.fr/privacy/ |
| privacy.print.qr.label | trentpower.fr/privacy/ | trentpower.fr/privacy/ |
| privacy.print.title | Privacy-first by design | La confidentialité, par conception |
| projects.label | Projects | Projets |
| projects.paris_cta | View project | Voir le projet |
| projects.paris_desc | A private cultural intelligence system for Paris, combining location, effort, editorial judgement and personal taste into a calmer way to decide what is worth leaving home for. | Un système privé d’intelligence culturelle pour Paris, combinant localisation, effort, jugement éditorial et goût personnel pour décider plus calmement ce qui mérite une sortie. |
| projects.paris_preview_caption | A sample cultural intelligence selection for one week, one neighbourhood. | Un échantillon de sélections d'intelligence culturelle, une semaine, un quartier. |
| projects.paris_preview_header | This week near Jourdain, 20th | Cette semaine près de Jourdain, 20e |
| projects.paris_subline | A personal experiment in taste systems, local relevance and human-scale recommendation. | Une expérimentation personnelle autour des systèmes de goût, de la pertinence locale et de la recommandation à échelle humaine. |
| projects.tier_bike | bike | vélo |
| projects.tier_metro | metro | métro |
| projects.tier_walk | walk | à pied |
| release_archive.print.card.01.body | /integrity.json - SHA-256 hashes of every intentional public file at edition time. | /integrity.json - empreintes SHA-256 de chaque fichier public au moment de l’édition. |
| release_archive.print.card.01.label | 01 Manifest | 01 Manifeste |
| release_archive.print.card.01.title | Manifest | Manifeste |
| release_archive.print.card.02.body | /integrity.json.sig - PGP detached signature over the manifest. | /integrity.json.sig - signature PGP détachée du manifeste. |
| release_archive.print.card.02.label | 02 Detached signature | 02 Signature détachée |
| release_archive.print.card.02.title | Detached signature | Signature détachée |
| release_archive.print.card.03.body | /integrity/releases/2026-05-09/SHA256SUMS - sums for ZIP and TAR.GZ. | /integrity/releases/2026-05-09/SHA256SUMS - sommes pour ZIP et TAR.GZ. |
| release_archive.print.card.03.label | 03 Archive checksums | 03 Sommes d’archive |
| release_archive.print.card.03.title | Archive checksums | Sommes d’archive |
| release_archive.print.card.04.body | trentpower-fr-2026-05-09.zip · trentpower-fr-2026-05-09.tar.gz - deterministic. | trentpower-fr-2026-05-09.zip · trentpower-fr-2026-05-09.tar.gz - déterministes. |
| release_archive.print.card.04.label | 04 Source archive | 04 Archive source |
| release_archive.print.card.04.title | Source archive | Archive source |
| release_archive.print.card.05.body | gpg --verify integrity.json.sig integrity.json against the public key. | gpg --verify integrity.json.sig integrity.json contre la clé publique. |
| release_archive.print.card.05.label | 05 Verification status | 05 Statut de vérification |
| release_archive.print.card.05.title | Verification status | Statut de vérification |
| release_archive.print.card.06.body | Signed by A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263. | Signée par A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263. |
| release_archive.print.card.06.label | 06 Release fingerprint | 06 Empreinte de version |
| release_archive.print.card.06.title | Release fingerprint | Empreinte de version |
| release_archive.print.doc_title | Trent Power - Release Archive 2026-05-09 | Trent Power - Archive 2026-05-09 |
| release_archive.print.footer.edition | Edition 2026-05-09 · trentpower.fr/integrity/releases/2026-05-09/ | Édition 2026-05-17 · trentpower.fr/integrity/releases/2026-05-09/ |
| release_archive.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| release_archive.print.kicker | Signed release archive | Archive de version signée |
| release_archive.print.lede | Public release archive for the May 2026 signed edition, including manifests, checksums, detached signatures, and reproducible source records. | Archive publique de l’édition signée de mai 2026 : manifestes, sommes de contrôle, signatures détachées et archives sources reproductibles. |
| release_archive.print.meta | Edition 2026-05-09 · trentpower.fr/integrity/releases/2026-05-09/ | Édition 2026-05-17 · trentpower.fr/integrity/releases/2026-05-09/ |
| release_archive.print.qr.label | trentpower.fr/integrity/releases/2026-05-09/ | trentpower.fr/integrity/releases/2026-05-09/ |
| release_archive.print.title | Edition 2026-05-09 | Édition 2026-05-17 |
| releases.aria.actions_archive | Release record | Fiche d’édition |
| releases.aria.actions_current | Current release downloads and verification | Téléchargements et vérification de l’édition actuelle |
| releases.body_intro | Each <dfn id="signed-release">release</dfn> is a frozen, signed snapshot of the public site at the time of publication. Source archives can be downloaded, and checksums and signatures are provided for local verification. | Chaque <dfn id="signed-release">édition</dfn> est un instantané figé et signé du site public au moment de la publication. Les archives sources peuvent être téléchargées, et des sommes de contrôle et signatures sont fournies pour la vérification locale. |
| releases.detail.card.desc.sha | SHA-256 checksum | Somme de contrôle SHA-256 |
| releases.detail.card.desc.sig | Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature | Signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée |
| releases.detail.card.desc.sums | SHA-256 list for release archives | Liste SHA-256 des archives de l’édition |
| releases.detail.card.desc.sums_sig | Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature over SHA256SUMS | Signature <abbr title="Pretty Good Privacy">PGP</abbr> détachée sur SHA256SUMS |
| releases.detail.card.desc.targz | Technical preservation archive | Archive technique de préservation |
| releases.detail.card.desc.zip | Portable public source snapshot | Instantané portable de la source publique |
| releases.detail.card.kicker | Release files | Fichiers d’édition |
| releases.detail.card.label.sums | Checksum list | Liste de sommes de contrôle |
| releases.detail.card.label.sums_sig | Checksum list signature | Signature de la liste |
| releases.detail.card.label.targz | TAR.GZ | TAR.GZ |
| releases.detail.card.label.targz_sha | TAR.GZ checksum | Somme TAR.GZ |
| releases.detail.card.label.targz_sig | TAR.GZ signature | Signature TAR.GZ |
| releases.detail.card.label.zip | ZIP | ZIP |
| releases.detail.card.label.zip_sha | ZIP checksum | Somme ZIP |
| releases.detail.card.label.zip_sig | ZIP signature | Signature ZIP |
| releases.detail.card.status | ZIP · TAR.GZ · Checksums · Signatures | ZIP · TAR.GZ · Sommes de contrôle · Signatures |
| releases.detail.card.title | 9 May 2026 | 17 mai 2026 |
| releases.detail.intro | Signed release archives for the 9 May 2026 edition. A signed checksum list verifies the archive set; checksums verify the downloaded files; detached signatures verify each archive directly. The signed manifest at /integrity.json remains the live-site authority. | Archives d’édition signées pour l’édition du 17 mai 2026. Une liste de sommes de contrôle signée vérifie l’ensemble des archives ; les sommes de contrôle vérifient les fichiers téléchargés ; des signatures détachées vérifient directement chaque archive. Le manifeste signé publié à /integrity.json reste l’autorité du site en direct. |
| releases.detail.note | Archive binaries are not included in /integrity.json to avoid recursive hashing. They are verified separately through the signed checksum list, individual SHA-256 checksums and detached signatures. <a href="/integrity/">Integrity</a> remains the live-site authority. | Les fichiers d’archive ne sont pas inclus dans /integrity.json afin d’éviter un hachage récursif. Ils sont vérifiés séparément au moyen de la liste de sommes de contrôle signée, des sommes de contrôle SHA-256 individuelles et de signatures détachées. <a href="/integrity/">Intégrité</a> reste l’autorité du site en direct. |
| releases.detail.page_title | May 2026 | Mai 2026 |
| releases.download_checksums_sig | Checksums & signature | Sommes de contrôle & signature |
| releases.download_targz | Download TAR.GZ | Télécharger TAR.GZ |
| releases.download_zip | Download ZIP | Télécharger ZIP |
| releases.edition_feb | February 2026 · initial signed release | Février 2026 · première version signée |
| releases.edition_feb_date | February 2026 | Février 2026 |
| releases.edition_feb_desc | <cite>Initial signed release</cite> | <cite>Première édition signée</cite> |
| releases.edition_feb_meta | Signed snapshot · Initial release | Instantané signé · Édition initiale |
| releases.edition_may09_date | 9 May 2026 | 17 mai 2026 |
| releases.edition_may09_desc | <cite>Final May edition</cite> | <cite>Édition finale de mai</cite> |
| releases.edition_may09_meta | Signed snapshot · Earlier release | Instantané signé · Édition précédente |
| releases.edition_may17_date | 19 May 2026 | 19 mai 2026 |
| releases.edition_may17_desc | <cite>Editorial cohesion</cite> | <cite>Cohérence éditoriale</cite> |
| releases.edition_may17_meta | Signed snapshot · Previous release | Instantané signé · Édition actuelle |
| releases.editions_heading | Editions | Éditions |
| releases.group.archive | Archive | Archives |
| releases.group.current | Current release | Édition actuelle |
| releases.page_title | Releases | Versions |
| releases.print.card.01.body | Final May edition. Signed source archives, deterministic ZIP and TAR.GZ, aggregated SHA256SUMS. Clean active filenames. One-page print profile. Trust sheets. | Édition finale Signifier, Söhne, Söhne Mono. Noms de fichiers actifs propres. Profil imprimé d’une page. Fiches de confiance. |
| releases.print.card.01.label | 01 9 May 2026 | 01 Mai 2026 |
| releases.print.card.01.title | 9 May 2026 | Mai 2026 |
| releases.print.card.02.body | Initial signed release. Earlier visual system. Preserved as a historical archive. | Première version signée. Système visuel antérieur. Préservée comme archive historique. |
| releases.print.card.02.label | 02 February 2026 | 02 Février 2026 |
| releases.print.card.02.title | February 2026 | Février 2026 |
| releases.print.card.03.body | Frozen assets. Local CSS and fonts. No live mutable style dependency. | Ressources figées. CSS et polices locales. Aucune dépendance de style mutable en direct. |
| releases.print.card.03.label | 03 Archive principle | 03 Principe d’archive |
| releases.print.card.03.title | Archive principle | Principe d’archive |
| releases.print.card.04.body | /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc | /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc |
| releases.print.card.04.label | 04 Integrity route | 04 Voie d’intégrité |
| releases.print.card.04.title | Integrity route | Voie d’intégrité |
| releases.print.card.05.body | Verifiability. Authorship. Continuity. Public trust. | Vérifiabilité. Auteur. Continuité. Confiance publique. |
| releases.print.card.05.label | 05 Why it matters | 05 Pourquoi |
| releases.print.card.05.title | Why it matters | Pourquoi |
| releases.print.card.06.body | /integrity/releases/2026-05-17/ · /integrity/releases/2026-05-09/ · /integrity/releases/2026-02/ · /source/ | /integrity/releases/2026-05-17/ · /integrity/releases/2026-05-09/ · /integrity/releases/2026-02/ · /source/ |
| releases.print.card.06.label | 06 Where to inspect | 06 Où inspecter |
| releases.print.card.06.title | Where to inspect | Où inspecter |
| releases.print.doc_title | Trent Power - Release Archive Sheet | Trent Power - Archive des versions |
| releases.print.footer.edition | Edition 2026-05-19 · trentpower.fr/integrity/releases/ | Édition 2026-05-19 · trentpower.fr/integrity/releases/ |
| releases.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| releases.print.kicker | Releases | Versions |
| releases.print.lede | Public release snapshots preserve selected editions of the site with local assets so their design and integrity can be inspected over time. | Les instantanés de versions publiques préservent des éditions choisies du site avec des ressources locales afin que leur conception et leur intégrité puissent être inspectées dans le temps. |
| releases.print.meta | Edition 2026-05-19 · trentpower.fr/integrity/releases/ | Édition 2026-05-19 · trentpower.fr/integrity/releases/ |
| releases.print.qr.label | trentpower.fr/integrity/releases/ | trentpower.fr/integrity/releases/ |
| releases.print.title | Frozen public editions | Éditions publiques figées |
| releases.view_release | View release | Voir l’édition |
| security.architecture_card.archive_body | Frozen signed releases | Instantanés signés et figés |
| security.architecture_card.archive_label | Archive | Archive |
| security.architecture_card.browser_body | <abbr title="HyperText Transfer Protocol Secure">HTTPS</abbr> · no cookies · no analytics | <abbr title="HyperText Transfer Protocol Secure">HTTPS</abbr> · ni cookies ni analyses |
| security.architecture_card.browser_label | Browser | Navigateur |
| security.architecture_card.cache_body | Service worker · local cache after first visit | Service worker · cache local dès la première visite |
| security.architecture_card.cache_label | Offline cache | Cache hors-ligne |
| security.architecture_card.files_body | <abbr title="HyperText Markup Language">HTML</abbr> · <abbr title="Cascading Style Sheets">CSS</abbr> · vanilla JS · self-hosted fonts | <abbr title="HyperText Markup Language">HTML</abbr> · <abbr title="Cascading Style Sheets">CSS</abbr> · JavaScript natif · polices auto-hébergées |
| security.architecture_card.files_label | Site files | Fichiers du site |
| security.architecture_card.host_body | Apache · Gandi · Paris · <abbr title="Secure File Transfer Protocol">SFTP</abbr> deployment | Apache · Gandi · Paris · déploiement <abbr title="Secure File Transfer Protocol">SFTP</abbr> |
| security.architecture_card.host_label | Static host | Hébergement statique |
| security.architecture_card.kicker | Architecture | Architecture |
| security.architecture_card.trust_body | Integrity · Verify · Source · Releases | Intégrité · Vérification · Source · Éditions |
| security.architecture_card.trust_label | Trust | Confiance |
| security.body_intro | How this site is hosted, what it protects, what it doesn't - and how anyone can verify it independently. | Comment ce site est hébergé, ce qu’il protège, ce qu’il ne protège pas - et comment chacun peut le vérifier indépendamment. |
| security.page_h1 | <span class="hero-line">Static.</span><span class="hero-line">Self-managed.</span><span class="hero-line">Verification-led.</span> | <span class="hero-line">Statique.</span><span class="hero-line">Auto-hébergé.</span><span class="hero-line">Vérifiable.</span> |
| security.page_kicker | Security & Threat Model | Sécurité et modèle de menace |
| security.page_title | Security & Threat Model | Sécurité & modèle de menace |
| security.print.card.01.body | Static HTML, CSS, vanilla JavaScript. Self-managed deployment on Apache (Gandi, Paris). No public database. | HTML, CSS, JavaScript natif. Déploiement auto-géré sur Apache (Gandi, Paris). Aucune base de données publique. |
| security.print.card.01.label | 01 Architecture | 01 Architecture |
| security.print.card.01.title | Architecture | Architecture |
| security.print.card.02.body | <abbr title="Content Security Policy">CSP</abbr> default-deny. <abbr title="HTTP Strict Transport Security">HSTS</abbr>. <abbr title="Cross-Origin Opener Policy">COOP</abbr> / <abbr title="Cross-Origin Embedder Policy">COEP</abbr> / <abbr title="Cross-Origin Resource Policy">CORP</abbr>. Referrer-Policy no-referrer. Locked-down Permissions-Policy. | <abbr title="Content Security Policy">CSP</abbr> par défaut deny. <abbr title="HTTP Strict Transport Security">HSTS</abbr>. <abbr title="Cross-Origin Opener Policy">COOP</abbr> / <abbr title="Cross-Origin Embedder Policy">COEP</abbr> / <abbr title="Cross-Origin Resource Policy">CORP</abbr>. Referrer-Policy no-referrer. Permissions-Policy verrouillée. |
| security.print.card.02.label | 02 Headers | 02 En-têtes |
| security.print.card.02.title | Security headers | En-têtes de sécurité |
| security.print.card.03.body | Identity. Published content. Public verification files. Source integrity. | Identité. Contenu publié. Fichiers de vérification publics. Intégrité du code source. |
| security.print.card.03.label | 03 Assets protected | 03 Actifs protégés |
| security.print.card.03.title | Assets protected | Actifs protégés |
| security.print.card.04.body | Content injection. Hosting credential compromise. Spoofed identity. Stale or tampered files. | Injection de contenu. Compromission des identifiants d’hébergement. Usurpation d’identité. Fichiers obsolètes ou altérés. |
| security.print.card.04.label | 04 Threat model | 04 Modèle de menaces |
| security.print.card.04.title | Threat model | Modèle de menaces |
| security.print.card.05.body | No third-party scripts. No public forms. Signed integrity manifest. Restricted file exposure. Service-worker-controlled cache. | Aucun script tiers. Aucun formulaire public. Manifeste d’intégrité signé. Exposition de fichiers restreinte. Cache piloté par service worker. |
| security.print.card.05.label | 05 Controls | 05 Contrôles |
| security.print.card.05.title | Controls | Contrôles |
| security.print.card.06.body | Hosting and registrar risk remain. Static-site exposure is reduced, not eliminated. Responsible disclosure route is published. | Le risque hébergeur et registrar demeure. L’exposition d’un site statique est réduite, pas éliminée. Voie de divulgation responsable publiée. |
| security.print.card.06.label | 06 Residual risk | 06 Risque résiduel |
| security.print.card.06.title | Residual risk | Risque résiduel |
| security.print.doc_title | Trent Power - Security Threat Model Sheet | Trent Power - Profil sécurité |
| security.print.footer.edition | Edition 2026-05-19 · trentpower.fr/security/ | Édition 2026-05-19 · trentpower.fr/security/ |
| security.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| security.print.kicker | Security & Threat Model | Sécurité & modèle de menace |
| security.print.lede | The public site is static HTML, CSS and vanilla JavaScript, with strict headers, no runtime server logic, no public database and no third-party scripts. | Le site public est composé de HTML, CSS et JavaScript natif, avec des en-têtes stricts, aucune logique serveur à l’exécution, aucune base de données publique et aucun script tiers. |
| security.print.meta | Edition 2026-05-19 · trentpower.fr/security/ | Édition 2026-05-19 · trentpower.fr/security/ |
| security.print.qr.label | trentpower.fr/security/ | trentpower.fr/security/ |
| security.print.title | Static, self-managed, verification-led | Statique, auto-géré, axé sur la vérification |
| security.public_verification_footer | These routes support inspection and provenance. They do not remove the need to protect <abbr title="Domain Name System">DNS</abbr>, hosting credentials and the private signing key. | Ces routes facilitent l'inspection et la provenance. Elles ne suppriment pas la nécessité de protéger le <abbr title="Domain Name System">DNS</abbr>, les identifiants d'hébergement et la clé privée de signature. |
| security.public_verification_intro | The site exposes public inspection routes so published content can be checked without private infrastructure access. | Le site expose des routes d'inspection publique pour que le contenu publié puisse être contrôlé sans accès à l'infrastructure privée. |
| security.public_verification_list | <a href="/integrity/" aria-label="Open the integrity archive for signed releases, public key and manifest"><code>/integrity/</code></a> records signed releases, public key and manifest<br><a href="/verify/" aria-label="Open the page verification tool for canonical URLs, source mirrors and fingerprints"><code>/verify/</code></a> records one page’s canonical <abbr title="Uniform Resource Locator">URL</abbr>, source mirror and fingerprint<br><a href="/source/" aria-label="Open readable source mirrors of selected public files"><code>/source/</code></a> publishes readable mirrors of selected public files<br><a href="/integrity/releases/" aria-label="Open frozen signed release snapshots"><code>/integrity/releases/</code></a> preserves frozen signed snapshots | <a href="/integrity/" aria-label="Ouvrir l’archive d’intégrité des publications signées, de la clé publique et du manifeste"><code>/integrity/</code></a> recense les éditions signées, la clé publique et le manifeste<br><a href="/verify/" aria-label="Ouvrir l’outil de vérification des URL canoniques, miroirs source et empreintes de page"><code>/verify/</code></a> recense l'<abbr title="Uniform Resource Locator">URL</abbr> canonique d'une page, son miroir source et son empreinte<br><a href="/source/" aria-label="Ouvrir les miroirs lisibles du code source de certains fichiers publics"><code>/source/</code></a> publie les miroirs lisibles d'une sélection de fichiers publics<br><a href="/integrity/releases/" aria-label="Ouvrir les instantanés figés et signés des publications"><code>/integrity/releases/</code></a> conserve les instantanés signés et figés |
| security.public_verification_summary | 5. Public verification surface | 5. Surface de vérification publique |
| security.s1_routes_note | Public inspection routes expose the signed manifest, page records, readable source mirrors and archived releases without exposing private infrastructure. | Les routes d'inspection publiques exposent le manifeste signé, les enregistrements de page, les miroirs source lisibles et les éditions archivées sans exposer l'infrastructure privée. |
| security.s1_summary | 1. Architecture | 1. Architecture |
| security.s2_body | The controls described here protect: | Les contrôles décrits ici protègent : |
| security.s2_list | Domain ownership<br>DNS integrity<br>Hosting account integrity<br>Public content integrity<br>The signing key used for release authenticity | La propriété du domaine<br>L’intégrité DNS<br>L’intégrité du compte d’hébergement<br>L’intégrité du contenu public<br>La clé de signature utilisée pour l’authenticité des versions |
| security.s2_summary | 2. Assets protected | 2. Actifs protégés |
| security.s3_admin_heading | Administrative abuse | Abus administratif |
| security.s3_admin_list | Credential stuffing<br>Automated vulnerability scanning | Credential stuffing<br>Analyse automatisée des vulnérabilités |
| security.s3_content_heading | Content tampering | Altération du contenu |
| security.s3_content_list | Post-deployment file modification<br>Malicious JavaScript injection<br>Silent alteration of static assets | Modification de fichiers après déploiement<br>Injection de JavaScript malveillant<br>Altération silencieuse des ressources statiques |
| security.s3_infra_heading | Infrastructure compromise | Compromission de l’infrastructure |
| security.s3_infra_list | Registrar account takeover<br><abbr title="Domain Name System">DNS</abbr> hijack<br>Hosting credential compromise | Prise de contrôle du compte registrar<br>Détournement <abbr title="Domain Name System">DNS</abbr><br>Compromission des identifiants d’hébergement |
| security.s3_noise_body | Continuous automated probing for common <abbr title="Content Management System">CMS</abbr> paths, configuration files, or known endpoints. These are treated as persistent background conditions rather than exceptional events. | Sondage automatisé continu pour les chemins <abbr title="Content Management System">CMS</abbr> courants, les fichiers de configuration ou les points d’entrée connus. Ces éléments sont traités comme des conditions de fond persistantes plutôt que comme des événements exceptionnels. |
| security.s3_noise_heading | Commodity internet noise | Bruit internet courant |
| security.s3_summary | 3. Threat model | 3. Modèle de menace |
| security.s4_content_heading | Public content | Contenu public |
| security.s4_content_list | Static architecture reduces server-side attack surface<br>Strict <abbr title="Content Security Policy">CSP</abbr> starting from <code>default-src 'none'</code><br>No external resource loading<br>No dynamic script execution | Architecture statique réduisant la surface d’attaque côté serveur<br><abbr title="Content Security Policy">CSP</abbr> stricte démarrant par <code>default-src 'none'</code><br>Aucun chargement de ressource externe<br>Aucune exécution de script dynamique |
| security.s4_hosting_heading | Hosting | Hébergement |
| security.s4_hosting_list | Multi-factor authentication enabled<br><abbr title="Secure File Transfer Protocol">SFTP</abbr>-only deployment<br>No <abbr title="Secure Shell">SSH</abbr> shell exposure<br>No scheduled background execution | Authentification multi-facteurs activée<br>Déploiement <abbr title="Secure File Transfer Protocol">SFTP</abbr> uniquement<br>Aucune exposition <abbr title="Secure Shell">SSH</abbr> shell<br>Aucune exécution en arrière-plan planifiée |
| security.s4_monitoring_heading | Monitoring | Surveillance |
| security.s4_monitoring_list | Structured log analysis<br>Pattern detection and anomaly scoring<br>File integrity drift detection against the signed release baseline | Analyse structurée des journaux<br>Détection de patterns et scoring des anomalies<br>Détection de dérive d’intégrité des fichiers par rapport à la base de référence signée |
| security.s4_registrar_heading | Registrar &amp; <abbr title="Domain Name System">DNS</abbr> | Registrar &amp; <abbr title="Domain Name System">DNS</abbr> |
| security.s4_registrar_list | <abbr title="Multi-Factor Authentication">MFA</abbr> enabled<br>Registrar lock active<br><abbr title="Domain Name System Security Extensions">DNSSEC</abbr> enabled and validated<br><abbr title="Certificate Authority Authorization">CAA</abbr> records restrict certificate issuance | <abbr title="Multi-Factor Authentication">MFA</abbr> activée<br>Verrouillage du registrar actif<br><abbr title="Domain Name System Security Extensions">DNSSEC</abbr> activé et validé<br>Enregistrements <abbr title="Certificate Authority Authorization">CAA</abbr> restreignant l’émission de certificats |
| security.s4_summary | 4. Controls | 4. Contrôles |
| security.s6_footer | The main risks remain domain, <abbr title="Domain Name System">DNS</abbr>, hosting and private key compromise. | Les risques principaux restent la compromission du domaine, du <abbr title="Domain Name System">DNS</abbr>, de l'hébergement et de la clé de signature privée. |
| security.s6_intro | This model does not attempt to address: | Ce modèle ne tente pas de traiter : |
| security.s6_list | Physical compromise of hosting infrastructure<br>Global <abbr title="Domain Name System">DNS</abbr> root compromise<br>Certificate authority (<abbr title="Certificate Authority">CA</abbr>) compromise<br>State-level adversaries<br>Zero-day browser exploits on client devices | Compromission physique de l’infrastructure d’hébergement<br>Compromission de la racine <abbr title="Domain Name System">DNS</abbr> mondiale<br>Compromission d’une autorité de certification (<abbr title="Certificate Authority">CA</abbr>)<br>Adversaires étatiques<br>Exploits navigateur zero-day sur les appareils clients |
| security.s6_protect_summary | This model protects the public static site. It does not protect against registrar compromise, hosting compromise, client-device compromise or private key compromise. | Ce modèle protège le site statique public. Il ne protège pas contre la compromission du bureau d’enregistrement, de l’hébergement, des appareils clients ou de la clé privée. |
| security.s6_summary | 6. Residual risk | 6. Risque résiduel |
| security.s7_body | Responsible disclosure is welcome. Security contact details and encrypted communication instructions are published at <a href="/.well-known/security.txt" aria-describedby="desc-security-contact"><code>/.well-known/security.txt</code></a>. | La divulgation responsable est la bienvenue. Les coordonnées de sécurité et les instructions de communication chiffrée sont publiées sur <a href="/.well-known/security.txt" aria-describedby="desc-security-contact"><code>/.well-known/security.txt</code></a>. |
| security.s7_summary | 7. Disclosure | 7. Divulgation |
| security.s8_list | Simplicity over complexity<br>Deterministic behaviour over dynamic systems<br>Transparency over obscurity<br>Verifiable integrity over trust assumptions | Simplicité plutôt que complexité<br>Comportement déterministe plutôt que systèmes dynamiques<br>Transparence plutôt qu’obscurité<br>Intégrité vérifiable plutôt qu’hypothèses de confiance |
| security.s8_summary | 8. Design principles | 8. Principes de conception |
| source.col.validated | Verified | Vérifié |
| source.curation_note | This index shows the principal public mirrors. Additional mirrored files may remain available by direct URL where they support verification, recovery, or release integrity. | Cet index présente les principaux miroirs publics. D’autres fichiers miroirs peuvent rester accessibles par URL directe lorsqu’ils soutiennent la vérification, la récupération ou l’intégrité des versions publiées. |
| source.download_checksums | Checksums | Sommes de contrôle |
| source.download_lede | Download the public source archive for the current edition | Télécharger l’archive source publique de l’édition courante |
| source.download_targz | TAR.GZ | TAR.GZ |
| source.download_zip | ZIP | ZIP |
| source.editions.eyebrow | Editions | Éditions |
| source.editions.note.current | Current signed release | Édition signée en cours |
| source.editions.note.earlier | Earlier signed release | Édition signée antérieure |
| source.editions.title | Edition lineage | Lignée des éditions |
| source.files.403_html_txt.description | Forbidden page. | Page interdite. |
| source.files.404_html_txt.description | Not found page. | Page introuvable. |
| source.files.500_html_txt.description | Server error page. | Page d'erreur serveur. |
| source.files.ai_usage_txt_txt.description | Statement of AI usage and policy for the site. | Déclaration sur l'usage de l'IA et politique pour le site. |
| source.files.app_enhance_js_txt.description | Progressive enhancement layer. Non-essential interactions, gracefully optional. | Couche d'amélioration progressive. Interactions non essentielles, gracieusement optionnelles. |
| source.files.app_js_txt.description | Authored runtime script. Navigation, language switch, citation drawer wiring. | Script d'exécution écrit à la source. Navigation, changement de langue, câblage du tiroir de citation. |
| source.files.assertion_txt_txt.description | Authorship assertion. Declaration of authorship and integrity intent. | Affirmation d'auteur. Déclaration d'auteur et d'intention d'intégrité. |
| source.files.attestations_json_txt.description | Public attestations. Verifiable claims about the site. | Attestations publiques. Revendications vérifiables sur le site. |
| source.files.changelog_txt_txt.description | Edition change log. Notable revisions to the public site. | Journal des éditions. Révisions notables du site public. |
| source.files.cite_js_txt.description | Cite-and-verify drawer. Surfaces canonical URL, page fingerprint and signature. | Tiroir de citation et vérification. Expose l'URL canonique, l'empreinte de la page et la signature. |
| source.files.fonts_full_css_txt.description | Webfont declarations. Subsets, formats and fallbacks. | Déclarations de polices web. Sous-ensembles, formats et fallbacks. |
| source.files.htaccess_txt.description | Apache configuration. Public-safety scanned before mirroring. | Configuration Apache. Vérifiée contre toute fuite avant publication. |
| source.files.humans_txt_txt.description | Credits and notes for the people behind the site. | Crédits et notes pour les personnes derrière le site. |
| source.files.i18n_core_js_txt.description | Editorial translation source. All five languages in one authored JSON. | Source éditoriale des traductions. Les cinq langues réunies dans un JSON unique. |
| source.files.i18n_de_js_txt.description | German translations. | Traductions allemandes. |
| source.files.i18n_es_js_txt.description | Spanish translations. | Traductions espagnoles. |
| source.files.i18n_it_js_txt.description | Italian translations. Deployed compact bytes. | Traductions italiennes. Octets compacts déployés. |
| source.files.index_html_txt.description | Home page. The editorial entry point. | Page d'accueil. Le point d'entrée éditorial. |
| source.files.integrity_index_html_txt.description | Integrity overview. The signed manifest, key and release authority. | Vue d'ensemble de l'intégrité. Le manifeste signé, la clé et l'autorité de publication. |
| source.files.integrity_releases_2026_05_09_index_html_txt.description | Frozen page record for the 2026-05-09 edition. | Fiche figée de la page pour l'édition 2026-05-09. |
| source.files.integrity_releases_archive_css_txt.description | Stylesheet used inside frozen release archives. Held alongside its release records. | Feuille de style utilisée dans les archives d'éditions figées. Conservée auprès de ses fiches d'édition. |
| source.files.integrity_releases_index_html_txt.description | Release index. The list of signed editions. | Index des éditions. La liste des éditions signées. |
| source.files.llms_txt_txt.description | Machine-readable guidance for language models and AI systems. | Indications lisibles par machine pour les modèles de langage et systèmes d'IA. |
| source.files.maintenance_html_txt.description | Maintenance notice. Used during planned downtime. | Avis de maintenance. Utilisé lors d'une interruption planifiée. |
| source.files.manifest_webmanifest_txt.description | Web app manifest. Installable surface metadata. | Manifeste d'application web. Métadonnées de la surface installable. |
| source.files.pgp_txt_txt.description | PGP statement. The signing key fingerprint and its use. | Déclaration PGP. Empreinte de la clé de signature et son usage. |
| source.files.print_css_txt.description | Print stylesheet. Layout rules for paper output. | Feuille de style d'impression. Règles de mise en page pour le rendu papier. |
| source.files.privacy_index_html_txt.description | Privacy statement. What is collected, retained and shared. | Déclaration de confidentialité. Ce qui est collecté, conservé et partagé. |
| source.files.readme_txt.description | Orientation note for the source tree. Same text shipped at the root of every release archive. | Note d'orientation pour l'arborescence source. Même texte livré à la racine de chaque archive d'édition. |
| source.files.robots_txt_txt.description | Crawler access policy and public indexing intent. | Politique d'accès des robots et intention d'indexation publique. |
| source.files.security_acknowledgments_index_html_txt.description | Acknowledgments for public security disclosures. | Remerciements pour les signalements de sécurité publics. |
| source.files.security_index_html_txt.description | Security posture. Architecture, headers and disclosure path. | Posture de sécurité. Architecture, en-têtes et voie de signalement. |
| source.files.site_metadata_json_txt.description | Site-level metadata. Edition, build, asset version. | Métadonnées du site. Édition, compilation, version des ressources. |
| source.files.sitemap_xml_sha256_txt.description | Source mirror of the SHA-256 checksum for sitemap.xml. | Miroir source de la somme de contrôle SHA-256 pour sitemap.xml. |
| source.files.sitemap_xml_txt.description | Public sitemap. URL inventory for crawlers. | Plan du site public. Inventaire d'URL pour les robots d'indexation. |
| source.files.source_manifest_json_txt.description | Manifest of the /source/ tree itself. Every mirrored file with its hash. | Manifeste de l'arborescence /source/ elle-même. Chaque fichier miroir avec son empreinte. |
| source.files.statement_txt_txt.description | Editorial statement. The site's authoring principles. | Déclaration éditoriale. Les principes d'écriture du site. |
| source.files.styles_css_txt.description | Authored stylesheet. Mirrored from source, not the minified deployed bytes. | Feuille de style écrite à la source. Miroir de la source, non des octets minifiés déployés. |
| source.files.sw_cache_manifest_json_txt.description | Service worker cache manifest. Files pinned for offline use. | Manifeste de cache du service worker. Fichiers épinglés pour usage hors ligne. |
| source.files.sw_js_txt.description | Service worker. Offline cache for the public site. | Service worker. Cache hors ligne du site public. |
| source.files.sw_reset_index_html_txt.description | Service worker reset. Clears the offline cache. | Réinitialisation du service worker. Vide le cache hors ligne. |
| source.files.verify_index_html_txt.description | Verification interface. Page-level fingerprint checks. | Interface de vérification. Contrôles d'empreinte au niveau de la page. |
| source.files.verify_verify_js_txt.description | Verification logic. Renders a page record from the verification map. | Logique de vérification. Rend une fiche de page à partir de la carte de vérification. |
| source.files.well_known_attribution_txt_txt.description | Author attribution. Names the responsible party for the public site. | Attribution d'auteur. Nomme la partie responsable du site public. |
| source.files.well_known_build_json_txt.description | Build record. Reproducibility data for the current edition. | Fiche de compilation. Données de reproductibilité de l'édition courante. |
| source.files.well_known_person_json_txt.description | Machine-readable identity in JSON-LD. The reference used by discovery, federation and verification. | Identité lisible par machine en JSON-LD. La référence utilisée par la découverte, la fédération et la vérification. |
| source.files.well_known_person_json_txt.role | Canonical identity record | Fiche d'identité canonique |
| source.files.well_known_pgp_key_asc_txt.description | ASCII-armoured public signing key. The publisher's signing identity. | Clé publique de signature en ASCII-armor. L'identité de signature de l'auteur. |
| source.files.well_known_publication_json_txt.description | Publication record. Describes the site as a self-managed editorial work. | Fiche de publication. Décrit le site comme un ouvrage éditorial auto-géré. |
| source.files.well_known_security_txt_txt.description | Coordinated disclosure policy. Standard /.well-known/security.txt contact and scope. | Politique de divulgation coordonnée. Contact et périmètre standard /.well-known/security.txt. |
| source.files.well_known_security_txt_txt.role | Public trust surface | Surface de confiance publique |
| source.files.well_known_webfinger_txt.description | WebFinger discovery surface. Resolves identity across federated protocols. | Surface de découverte WebFinger. Résout l'identité à travers les protocoles fédérés. |
| source.files.well_known_webfinger_txt.role | Identity discovery | Découverte d'identité |
| source.group.metadata | Metadata | Métadonnées |
| source.group.published-pages | Published pages | Pages publiées |
| source.group.scripts | Scripts | Scripts |
| source.group.trust-records | Trust records | Fiches de confiance |
| source.group_gloss.metadata | Server configuration and machine-readable records describing the site to crawlers, indexers and language models. | Configuration serveur et fiches lisibles par machine décrivant le site aux robots d'indexation et aux modèles de langage. |
| source.group_gloss.published-pages | Readable mirrors of the principal public pages, served as plain text so the bytes can be inspected without execution. | Miroirs lisibles des principales pages publiques, servis en texte brut afin que les octets puissent être inspectés sans exécution. |
| source.group_gloss.scripts | Authored stylesheets and JavaScript the page ships to the browser. Mirrored from source, not the minified deployed bytes. | Feuilles de style et JavaScript écrits à la source que la page envoie au navigateur. Miroirs de la source, non des octets minifiés déployés. |
| source.group_gloss.trust-records | Public commitments and identity surfaces. Who publishes the site, what is promised, where disclosure runs. | Engagements publics et surfaces d'identité. Qui publie le site, ce qui est promis, où passent les signalements. |
| source.heading | <span class="hero-line">Every public byte,</span><span class="hero-line">in plain text.</span> | <span class="hero-line">Chaque octet public,</span><span class="hero-line">en texte clair.</span> |
| source.intro_lede | Selected public files, published in readable form. For inspection, preservation, and machine readability. | Fichiers publics sélectionnés, publiés sous forme lisible. Pour inspection, conservation et lecture machine. |
| source.page_kicker | Source | Code source |
| source.print.card.01.body | HTML mirrors. CSS. JavaScript. Manifest files. .htaccess mirror. | Miroirs HTML. CSS. JavaScript. Fichiers manifeste. Miroir .htaccess. |
| source.print.card.01.label | 01 What is included | 01 Ce qui est inclus |
| source.print.card.01.title | What is included | Ce qui est inclus |
| source.print.card.02.body | Credentials. Private notes. Invoices. Backups. Generator internals unless explicitly public. | Identifiants. Notes privées. Factures. Sauvegardes. Internes du générateur, sauf publication explicite. |
| source.print.card.02.label | 02 What is excluded | 02 Ce qui est exclu |
| source.print.card.02.title | What is excluded | Ce qui est exclu |
| source.print.card.03.body | Sorted by file type, then name. Plain text mirrors. SHA-256 hashes. File sizes. | Trié par type de fichier, puis par nom. Miroirs en texte brut. Empreintes SHA-256. Tailles de fichier. |
| source.print.card.03.label | 03 How it is organised | 03 Organisation |
| source.print.card.03.title | How it is organised | Organisation |
| source.print.card.04.body | source-manifest.json · /integrity.json · detached signature · public key. | source-manifest.json · /integrity.json · signature détachée · clé publique. |
| source.print.card.04.label | 04 Verification | 04 Vérification |
| source.print.card.04.title | Verification | Vérification |
| source.print.card.05.body | styles.css.txt · app.js.txt · print.css.txt · htaccess.txt · source-manifest.json | styles.css.txt · app.js.txt · print.css.txt · htaccess.txt · source-manifest.json |
| source.print.card.05.label | 05 Files of note | 05 Fichiers notables |
| source.print.card.05.title | Files of note | Fichiers notables |
| source.print.card.06.body | Human readers first. Machine-readable files preserve identity, authorship and context. | Lecteurs humains d’abord. Les fichiers lisibles par machine préservent identité, auteur et contexte. |
| source.print.card.06.label | 06 Principle | 06 Principe |
| source.print.card.06.title | Principle | Principe |
| source.print.doc_title | Trent Power - Public Source Sheet | Trent Power - Vue source publique |
| source.print.footer.edition | Edition 2026-05-19 · trentpower.fr/source/ | Édition 2026-05-19 · trentpower.fr/source/ |
| source.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| source.print.kicker | Source | Source |
| source.print.lede | Selected public files are mirrored as plain text so the site can be inspected from any reader, including mobile. | Des fichiers publics sélectionnés sont copiés en texte brut afin que le site puisse être inspecté depuis n’importe quel lecteur, y compris mobile. |
| source.print.meta | Edition 2026-05-19 · trentpower.fr/source/ | Édition 2026-05-19 · trentpower.fr/source/ |
| source.print.qr.label | trentpower.fr/source/ | trentpower.fr/source/ |
| source.print.title | Public source view | Vue source publique |
| source_reader.action.back_to_top | Top | Haut |
| source_reader.action.canonical | Canonical | Canonique |
| source_reader.action.clear | Clear | Effacer |
| source_reader.action.copied | Copied | Copié |
| source_reader.action.copy | Copy | Copier |
| source_reader.action.copy_code | Copy code | Copier le code |
| source_reader.action.copy_failed | Copy unavailable | Copie indisponible |
| source_reader.action.copy_link | Copy link | Copier le lien |
| source_reader.action.count_line_one | 1 line | 1 ligne |
| source_reader.action.count_lines_many | {n} lines | {n} lignes |
| source_reader.action.line_selected | Line {n} selected | Ligne {n} sélectionnée |
| source_reader.action.lines_copied | {n} lines copied | {n} lignes copiées |
| source_reader.action.link_copied | Link copied | Lien copié |
| source_reader.action.link_copied_normalised | Link copied — normalised to lines {start} to {end} | Lien copié — normalisé aux lignes {start} à {end} |
| source_reader.action.plain_text | Raw | Brut |
| source_reader.action.range_selected | Lines {start} to {end} selected | Lignes {start} à {end} sélectionnées |
| source_reader.action.reading_mode | Reading mode | Mode de lecture |
| source_reader.action.selection_cleared | Selection cleared | Sélection effacée |
| source_reader.action.top | Top | Haut |
| source_reader.action.unwrap_lines | Unwrap lines | Sans retour à la ligne |
| source_reader.action.verify | Verify | Vérifier |
| source_reader.action.view_annotated | Annotated | Annoté |
| source_reader.action.view_rendered_page | View rendered page | Voir la page rendue |
| source_reader.action.view_source | Source | Source |
| source_reader.action.wrap_lines | Wrap lines | Retour à la ligne |
| source_reader.end.edition | Edition | Édition |
| source_reader.end.sha256 | SHA-256 | SHA-256 |
| source_reader.end.signed_release | Signed release | Publication signée |
| source_reader.end.title | End of source mirror | Fin du miroir source |
| source_reader.gloss.assets | stylesheets, scripts, icons, manifest. | feuilles de style, scripts, icônes, manifeste. |
| source_reader.gloss.base | reset and base element typography. | réinitialisation et typographie des éléments de base. |
| source_reader.gloss.components | reusable component styles. | styles de composants réutilisables. |
| source_reader.gloss.copy | clipboard interactions. | interactions avec le presse-papiers. |
| source_reader.gloss.discovery | indexing and referrer policy. | politique d'indexation et de référent. |
| source_reader.gloss.document | page title, description, canonical url. | titre de la page, description, URL canonique. |
| source_reader.gloss.events | event listeners and interaction wiring. | écouteurs d'événements et câblage des interactions. |
| source_reader.gloss.fonts | font face declarations and font assets. | déclarations @font-face et fichiers de police. |
| source_reader.gloss.footer | colophon, language switch, footer actions. | colophon, sélecteur de langue, actions de pied de page. |
| source_reader.gloss.foundations | character encoding, viewport, colour scheme. | encodage des caractères, fenêtre d'affichage, palette. |
| source_reader.gloss.head | document head — metadata, no rendered content. | en-tête du document — métadonnées, aucun contenu rendu. |
| source_reader.gloss.header | site header — wordmark and primary nav. | en-tête du site — sigle et navigation principale. |
| source_reader.gloss.i18n | translation lookup and language switching. | résolution des traductions et changement de langue. |
| source_reader.gloss.icons | platform icons and home-screen artwork. | icônes de plateforme et illustration d'écran d'accueil. |
| source_reader.gloss.identity | authorship, application name, attribution links. | auteur, nom de l'application, liens d'attribution. |
| source_reader.gloss.init | boot sequence — runs once on load. | séquence de démarrage — exécutée une fois au chargement. |
| source_reader.gloss.layout | page-level layout grammar. | grammaire de mise en page au niveau de la page. |
| source_reader.gloss.modals | overlay surfaces, dialogs, focus traps. | surfaces superposées, dialogues, pièges de focus. |
| source_reader.gloss.policy | declared site policies. | politiques déclarées du site. |
| source_reader.gloss.print | print stylesheet rules. | règles de feuille de style pour l'impression. |
| source_reader.gloss.records | editorial record entries. | fiches éditoriales. |
| source_reader.gloss.responsive | viewport-aware overrides. | ajustements selon la fenêtre d'affichage. |
| source_reader.gloss.script | site application logic. | logique applicative du site. |
| source_reader.gloss.social | open graph and twitter card metadata. | métadonnées open graph et twitter card. |
| source_reader.gloss.state | application state and runtime variables. | état applicatif et variables d'exécution. |
| source_reader.gloss.structured | json-ld schema, machine-readable identity. | schéma json-ld, identité lisible par machine. |
| source_reader.gloss.tokens | design tokens — colours, typography, spacing. | jetons de design — couleurs, typographie, espacements. |
| source_reader.gloss.verification | signed-manifest and cryptographic references. | manifeste signé et références cryptographiques. |
| source_reader.integrity.canonical | Canonical file | Fichier canonique |
| source_reader.integrity.edition | Edition | Édition |
| source_reader.integrity.sha256 | SHA-256 | SHA-256 |
| source_reader.integrity.signed_release | Signed release | Publication signée |
| source_reader.kind.apache | Apache configuration | Configuration Apache |
| source_reader.kind.asc | ASCII-armoured PGP key | Clé PGP en ASCII-armor |
| source_reader.kind.css | Cascading Style Sheets | Feuilles de style en cascade |
| source_reader.kind.html | HyperText Markup Language | Langage de balisage hypertexte |
| source_reader.kind.js | JavaScript | JavaScript |
| source_reader.kind.json | JavaScript Object Notation | Notation d'objet JavaScript |
| source_reader.kind.sig | Detached PGP signature | Signature PGP détachée |
| source_reader.kind.text | Plain text | Texte brut |
| source_reader.kind.xml | Extensible Markup Language | Langage de balisage extensible |
| source_reader.loading | Loading source… | Chargement du source… |
| source_reader.map_label.assets | Assets | Ressources |
| source_reader.map_label.base | Base | Base |
| source_reader.map_label.components | Components | Composants |
| source_reader.map_label.copy | Copy | Copie |
| source_reader.map_label.discovery | Discovery | Découvrabilité |
| source_reader.map_label.events | Events | Événements |
| source_reader.map_label.fonts | Fonts | Polices |
| source_reader.map_label.footer | Footer | Pied de page |
| source_reader.map_label.head | Head | Tête |
| source_reader.map_label.header | Header | En-tête |
| source_reader.map_label.i18n | i18n | i18n |
| source_reader.map_label.identity | Identity | Identité |
| source_reader.map_label.init | Init | Initialisation |
| source_reader.map_label.layout | Layout | Mise en page |
| source_reader.map_label.main | Main | Contenu principal |
| source_reader.map_label.modals | Modals | Modales |
| source_reader.map_label.policy | Policy | Politique |
| source_reader.map_label.print | Print | Impression |
| source_reader.map_label.records | Records | Enregistrements |
| source_reader.map_label.responsive | Responsive | Responsive |
| source_reader.map_label.social_preview | Social preview | Aperçu social |
| source_reader.map_label.state | State | État |
| source_reader.map_label.structured_data | Structured data | Données structurées |
| source_reader.map_label.tokens | Tokens | Jetons |
| source_reader.map_label.verification | Verification | Vérification |
| source_reader.meta.document_map | Document map | Plan du document |
| source_reader.meta.end_of_source | End of source mirror | Fin du miroir source |
| source_reader.meta.intent | This reader presents public source mirrors with structural annotations and signed publication references. | Ce lecteur présente les miroirs publics du code source, avec annotations structurelles et références de publication signées. |
| source_reader.meta.part_of | Related systems: | Systèmes liés : |
| source_reader.meta.validated | Verified | Vérifié |
| source_reader.mode.annotated | Annotated | Annoté |
| source_reader.mode.label | Reading mode | Mode de lecture |
| source_reader.mode.raw | Raw | Brut |
| source_reader.mode.source | Source | Source |
| source_reader.title | Source reader | Lecteur source |
| sw_reset.api_label | APIs | API |
| sw_reset.button | Reset local offline cache | Réinitialiser le cache hors-ligne local |
| sw_reset.button_done | Reset complete | Réinitialisation effectuée |
| sw_reset.card_state | Offline cache | Cache hors-ligne |
| sw_reset.card_state_cleared | Offline cache cleared | Cache hors-ligne effacé |
| sw_reset.clear_caches | Offline cache entries | Entrées du cache hors-ligne |
| sw_reset.clear_pref | Saved language preference | Préférence de langue enregistrée |
| sw_reset.clear_sw | Service Worker registrations | Enregistrements du Service Worker |
| sw_reset.clears_heading | Clears | Efface |
| sw_reset.detected_label | Detected | Détecté |
| sw_reset.edition_label | Cached edition | Édition en cache |
| sw_reset.edition_none | No cached edition detected | Aucune édition en cache détectée |
| sw_reset.footnote | Offline state is stored locally through the browser Cache Storage and Service Worker APIs. | L'état hors-ligne est conservé localement via les API Cache Storage et Service Worker du navigateur. |
| sw_reset.lede | Clears the local offline cache for this device only. The live publication and server are unaffected. | Efface le cache hors-ligne local de cet appareil uniquement. La publication en ligne et le serveur ne sont pas affectés. |
| sw_reset.link_home | Home | Accueil |
| sw_reset.link_reload | Reload current edition | Recharger l'édition actuelle |
| sw_reset.local_marker | LOCAL DEVICE ONLY | APPAREIL LOCAL UNIQUEMENT |
| sw_reset.page_title | Service Worker Reset | Réinitialisation du Service Worker |
| sw_reset.preserve_downloads | Downloads | Téléchargements |
| sw_reset.preserve_history | Browser history | Historique du navigateur |
| sw_reset.preserve_others | Other websites | Autres sites |
| sw_reset.preserve_server | Server content | Contenu du serveur |
| sw_reset.preserves_heading | Does not clear | N'efface pas |
| sw_reset.print.card.01.body | Unregisters the service worker and deletes every named cache for this origin. | Désenregistre le Service Worker et supprime chaque cache nommé de cette origine. |
| sw_reset.print.card.01.label | 01 Cache removal | 01 Suppression du cache |
| sw_reset.print.card.01.title | Cache removal | Suppression du cache |
| sw_reset.print.card.02.body | Used when a stale offline copy is serving an outdated signed edition. | Utilisé lorsqu’une copie hors-ligne périmée sert une édition signée obsolète. |
| sw_reset.print.card.02.label | 02 Offline recovery | 02 Récupération hors-ligne |
| sw_reset.print.card.02.title | Offline recovery | Récupération hors-ligne |
| sw_reset.print.card.03.body | Next page load fetches fresh HTML, CSS, JS, fonts, and integrity files. | Le chargement suivant récupère HTML, CSS, JS, polices et fichiers d’intégrité à neuf. |
| sw_reset.print.card.03.label | 03 Signed release refresh | 03 Actualisation de version signée |
| sw_reset.print.card.03.title | Signed release refresh | Actualisation de version signée |
| sw_reset.print.card.04.body | Works in any browser that supports Service Workers and the Cache API. | Fonctionne dans tout navigateur prenant en charge les Service Workers et l’API Cache. |
| sw_reset.print.card.04.label | 04 Browser compatibility | 04 Compatibilité navigateur |
| sw_reset.print.card.04.title | Browser compatibility | Compatibilité navigateur |
| sw_reset.print.card.05.body | Integrity manifest and signature remain unchanged - only cached copies are evicted. | Manifeste et signature inchangés - seules les copies en cache sont évincées. |
| sw_reset.print.card.05.label | 05 Verification continuity | 05 Continuité de vérification |
| sw_reset.print.card.05.title | Verification continuity | Continuité de vérification |
| sw_reset.print.card.06.body | Clears the cached language preference. Theme preference is preserved. | Efface la préférence de langue en cache. La préférence de thème est préservée. |
| sw_reset.print.card.06.label | 06 Local state reset | 06 Remise à zéro locale |
| sw_reset.print.card.06.title | Local state reset | Remise à zéro locale |
| sw_reset.print.doc_title | Trent Power - Service Worker Reset | Trent Power - Réinitialisation du Service Worker |
| sw_reset.print.footer.edition | Edition 2026-05-19 · trentpower.fr/sw-reset/ | Édition 2026-05-19 · trentpower.fr/sw-reset/ |
| sw_reset.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| sw_reset.print.kicker | Offline recovery | Récupération hors-ligne |
| sw_reset.print.lede | Recovery utility for clearing cached offline state and refreshing the current signed public release. | Utilitaire de récupération pour effacer l’état hors-ligne en cache et actualiser la version publique signée courante. |
| sw_reset.print.meta | Edition 2026-05-19 · trentpower.fr/sw-reset/ | Édition 2026-05-19 · trentpower.fr/sw-reset/ |
| sw_reset.print.qr.label | trentpower.fr/sw-reset/ | trentpower.fr/sw-reset/ |
| sw_reset.print.title | Service worker reset | Réinitialisation du Service Worker |
| sw_reset.scope_heading | Scope | Portée |
| sw_reset.secondary | If a recent edition is not appearing correctly, this utility refreshes the local publication cache. | Si une édition récente ne s'affiche pas correctement, cet utilitaire rafraîchit le cache local de la publication. |
| sw_reset.status_initial | Reading local state… | Lecture de l'état local… |
| sw_reset.status_label | Local cache status | État du cache local |
| trajectory.background_detail | Building online platforms and communities | Construire des plateformes et des communautés en ligne |
| trajectory.background_label | Background | Parcours initial |
| trajectory.background_span | 1997 — 2004 | 1997 — 2004 |
| trajectory.background_title | Web Entrepreneur | Entrepreneur web |
| trajectory.current_detail | Group-wide client strategy across Maisons and markets | Stratégie client à l’échelle du Groupe, à travers Maisons et marchés |
| trajectory.current_label | Current | Actuel |
| trajectory.current_org | <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr> | <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr> |
| trajectory.current_span | 2023 — now | 2023 — aujourd’hui |
| trajectory.current_title | Group Director, Client Development & Client Relations | Directeur Groupe, Développement Client & Relations Clients |
| trajectory.label | Trajectory | Parcours |
| trajectory.maisons_label | Maisons | Maisons |
| trajectory.maisons_org | BVLGARI | BVLGARI |
| trajectory.maisons_span | 2004 — 2017 | 2004 — 2017 |
| trajectory.maisons_title | Senior leadership across <a href="/#clienteling-definition" aria-label="Read the definition of Clienteling used on this site">Clienteling</a>, <abbr title="Customer Relationship Management">CRM</abbr> & Retail | Direction senior en <a href="/#clienteling-definition" aria-label="Lire la définition de Clienteling utilisée sur ce site">Clienteling</a>, <abbr title="Customer Relationship Management">CRM</abbr> & Retail |
| trajectory.previous_label | Previous | Précédent |
| trajectory.previous_org | <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr> | <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr> |
| trajectory.previous_span | 2017 — 2023 | 2017 — 2023 |
| trajectory.previous_title | Group Head of Clienteling | Responsable Groupe Clienteling |
| trust_routes.heading | Trust routes | Routes de confiance |
| trust_routes.integrity_desc | How releases are signed | Comment les éditions sont signées |
| trust_routes.integrity_label | Integrity | Intégrité |
| trust_routes.privacy_desc | What this site does not collect | Ce que ce site ne collecte pas |
| trust_routes.privacy_label | Privacy | Confidentialité |
| trust_routes.releases_desc | Frozen signed snapshots | Instantanés signés et figés |
| trust_routes.releases_label | Releases | Éditions |
| trust_routes.security_desc | How the site is protected | Comment le site est protégé |
| trust_routes.security_label | Security | Sécurité |
| trust_routes.source_desc | Readable mirrors of public files | Miroirs lisibles des fichiers publics |
| trust_routes.source_label | Source | Source |
| trust_routes.verify_desc | How a page can be checked | Comment une page peut être contrôlée |
| trust_routes.verify_label | Verify | Vérifier |
| verify.action.copied | Copied | Copié |
| verify.action.copy_canonical | Copy URL | Copier l’URL |
| verify.action.copy_command | Copy verification command | Copier la commande de vérification |
| verify.action.copy_fingerprint | Copy fingerprint | Copier l'empreinte |
| verify.action.copy_hash | Copy hash | Copier l’empreinte |
| verify.action.copy_manifest_command | Copy manifest command | Copier la commande manifeste |
| verify.action.copy_source_command | Copy source command | Copier la commande source |
| verify.action.open_key | Open public key | Ouvrir la clé publique |
| verify.action.open_manifest | Open manifest entry | Ouvrir l’entrée du manifeste |
| verify.action.open_signature | Open signature | Ouvrir la signature |
| verify.action.open_source | Open source mirror | Ouvrir le miroir source |
| verify.action.open_source_mirror | Open mirror | Ouvrir le miroir |
| verify.action.view_source_code | View source code | Voir le code source |
| verify.action.view_source_mirror | View source mirror | Voir le miroir source |
| verify.chooser.heading | Related records | Documents liés |
| verify.chooser.label.home | Homepage | Accueil |
| verify.chooser.label.integrity | Integrity | Intégrité |
| verify.chooser.label.privacy | Privacy | Confidentialité |
| verify.chooser.label.releases | Releases | Éditions |
| verify.chooser.label.security | Security | Sécurité |
| verify.chooser.label.source | Source | Source |
| verify.chooser.label.verify | Verify | Vérifier |
| verify.command.manifest_title | Verify the signed manifest | Vérifier le manifeste signé |
| verify.command.note | The signed manifest verifies the published file set. The second command hashes the source mirror so it can be compared against the expected SHA-256 above. | Le manifeste signé valide l’ensemble des fichiers publiés. La seconde commande calcule l’empreinte du miroir source pour la comparer au SHA-256 attendu ci-dessus. |
| verify.command.source_title | Verify the source mirror | Vérifier le miroir source |
| verify.doc_title | Trent Power - Verification Sheet | Trent Power - Fiche de vérification |
| verify.general.releases | Release archive | Archives des éditions |
| verify.general.source | Source viewer | Visualiseur source |
| verify.kicker | Verify | Vérification |
| verify.lede | A public route for checking source, hash, signature and canonical identity. | Une voie publique pour contrôler la source, l’empreinte, la signature et l’identité canonique. |
| verify.lede_v2 | Check a published page against its canonical location, source mirror, page fingerprint and signed release archive. | Contrôler une page publiée par rapport à son emplacement canonique, son miroir source, son empreinte de page et l'archive de version signée. |
| verify.local.closing | The signed manifest verifies the published file set. The source command hashes this page's mirror so it can be compared against the fingerprint above. | Le manifeste signé authentifie l'ensemble des fichiers publiés. La seconde commande calcule l'empreinte du miroir de cette page pour la comparer à l'empreinte ci-dessus. |
| verify.local.heading | Verify locally | Vérifier localement |
| verify.local.intro | Run two local checks: verify the signed manifest, then compare this page's source mirror against the expected fingerprint. | Effectuez deux contrôles locaux : vérifier le manifeste signé, puis comparer le miroir source de cette page à l'empreinte attendue. |
| verify.local.manifest_desc | Checks that /integrity.json was signed by the published public key. | Vérifie que /integrity.json a été signé avec la clé publique publiée. |
| verify.local.manifest_label | Verify the signed manifest | Vérifier le manifeste signé |
| verify.local.mirror_desc | Calculates the source mirror fingerprint so it can be compared with the expected value above. | Calcule l'empreinte du miroir source pour la comparer à la valeur attendue ci-dessus. |
| verify.local.mirror_label | Verify this page mirror | Vérifier le miroir de cette page |
| verify.local.subheading_manifest | Verify signed manifest | Vérifier le manifeste signé |
| verify.local.subheading_mirror | Verify source mirror | Vérifier le miroir source |
| verify.meta | Edition 2026-05-19 · trentpower.fr/verify/ | Édition 2026-05-19 · trentpower.fr/verify/ |
| verify.noscript_fallback | JavaScript is required to select and display a page record here. Source mirrors, the signed manifest and release archives remain available through <a href="/source/">Source</a> and <a href="/integrity/">Integrity</a>. | JavaScript est nécessaire pour sélectionner et afficher une fiche de page ici. Les miroirs source, le manifeste signé et les archives d’édition restent accessibles via <a href="/source/">Source</a> et <a href="/integrity/">Intégrité</a>. |
| verify.page_kicker | Verify page | Page de vérification |
| verify.selected.manifest | Integrity manifest | Manifeste d'intégrité |
| verify.selected.public_key | Public key | Clé publique |
| verify.selected.signature | Detached signature | Signature détachée |
| verify.status.found | Found in signed manifest | Présent dans le manifeste signé |
| verify.status.missing | Not found in current public manifest | Absent du manifeste public actuel |
| verify.thispage.group.archive | Release archive | Archive de version |
| verify.thispage.group.citation | Citation | Citation |
| verify.thispage.group.evidence | Source mirror | Miroir source |
| verify.thispage.group.fingerprint | Page fingerprint | Empreinte de page |
| verify.thispage.group.location | Canonical location | Emplacement canonique |
| verify.thispage.heading | This page | Cette page |
| verify.thispage.kicker | Page record | Document de page |
| verify.thispage.row.canonical | Canonical URL | URL canonique |
| verify.thispage.row.citation | Citation | Citation |
| verify.thispage.row.file | File | Fichier |
| verify.thispage.row.file_size | File size | Taille |
| verify.thispage.row.file_type | File type | Type de fichier |
| verify.thispage.row.manifest_status | Manifest status | Statut dans le manifeste |
| verify.thispage.row.release | Release archive | Archive de version |
| verify.thispage.row.route | Route | Route |
| verify.thispage.row.route_prefix | Route | Route |
| verify.thispage.row.sha256 | Page fingerprint | Empreinte de la page |
| verify.thispage.row.source | Source mirror | Miroir source |
| verify.thispage.row.title | Page title | Titre de la page |
| verify.thispage.row.validated | Last verified | Dernière vérification |
| verify.thispage.status.found_manifest | Found in signed manifest | Présent dans le manifeste signé |
| verify.thispage.status.release_archived | Release archived | Version archivée |
| verify.thispage.status.short.archived | Archive | Archives |
| verify.thispage.status.short.signed | Signed | Signé |
| verify.thispage.status.short.source | Mirrored | Miroir |
| verify.thispage.status.source_available | Source available | Source disponible |
| verify.thispage.validated_prefix | Verified | Vérifié |
| verify.title | Verify this page | Vérifier cette page |
| verify.title_default | <span class="hero-line">Check page against code, size &amp; signature</span> | <span class="hero-line">Vérifier la page · code, taille &amp; signature</span> |
| verify.title_prefix | Verify | Vérifier |
| verify.unknown.action.manifest | Integrity manifest | Manifeste d'intégrité |
| verify.unknown.action.releases | Release archive | Archive des éditions |
| verify.unknown.action.source | Source | Source |
| verify.unknown.body | This route is not in the public verification map. You can still inspect the public manifest, source view and signed releases. | Cette route ne figure pas dans la carte de vérification publique. Vous pouvez tout de même consulter le manifeste public, la vue source et les versions signées. |
| verify.unknown.title | Route not in the verification map | Route absente de la carte de vérification |
| verify_intro.archive | Edition archive | Archive d'édition |
| verify_intro.edition | Edition | Édition |
| verify_intro.manifest | Signed manifest | Manifeste signé |
| verify_intro.panel_label | Current edition | Édition actuelle |
| verify_intro.public_key | Public key | Clé publique |
| verify_intro.signature | Detached signature | Signature détachée |
| verify_intro.signing_key | Signing key | Clé de signature |
| verify_locally.body_close | The command imports the public key into a throw-away keyring, verifies the signed manifest, and removes the working files. No state is retained on the machine afterwards. | La commande importe la clé publique dans un trousseau jetable, vérifie le manifeste signé et supprime les fichiers de travail. Aucun état ne subsiste sur la machine ensuite. |
| verify_locally.body_intro | Detached verification notes for the signed integrity manifest. Run the check in a temporary keyring so the public signing key does not enter your default keychain. | Notes de vérification détachées pour le manifeste d'intégrité signé. Exécutez le contrôle dans un trousseau temporaire afin que la clé publique de signature n'entre pas dans votre trousseau principal. |
| verify_locally.page_kicker | Verify Locally | Vérification locale |
| verify_locally.page_title | <span class="hero-line">Get to</span><span class="hero-line">the terminal!</span> | <span class="hero-line">À votre</span><span class="hero-line">terminal !</span> |
| verify_locally.print.card.01.body | Use a temp GNUPGHOME so the import does not touch your main keyring. | Utilisez un GNUPGHOME temporaire pour ne pas toucher à votre trousseau principal. |
| verify_locally.print.card.01.label | 01 Temporary keyring | 01 Trousseau temporaire |
| verify_locally.print.card.01.title | Temporary keyring | Trousseau temporaire |
| verify_locally.print.card.02.body | curl /.well-known/pgp-key.asc · gpg --import pgp-key.asc. | curl /.well-known/pgp-key.asc · gpg --import pgp-key.asc. |
| verify_locally.print.card.02.label | 02 Import public key | 02 Importer la clé publique |
| verify_locally.print.card.02.title | Import public key | Importer la clé publique |
| verify_locally.print.card.03.body | gpg --verify integrity.json.sig integrity.json - expect Good signature. | gpg --verify integrity.json.sig integrity.json - attendre Good signature. |
| verify_locally.print.card.03.label | 03 Verify signature | 03 Vérifier la signature |
| verify_locally.print.card.03.title | Verify signature | Vérifier la signature |
| verify_locally.print.card.04.body | /integrity.json lists every public file with its SHA-256. | /integrity.json liste chaque fichier public avec son empreinte SHA-256. |
| verify_locally.print.card.04.label | 04 Check manifest | 04 Contrôler le manifeste |
| verify_locally.print.card.04.title | Check manifest | Contrôler le manifeste |
| verify_locally.print.card.05.body | Re-hash any file and compare against the manifest entry. | Re-hachez un fichier et comparez avec l’entrée du manifeste. |
| verify_locally.print.card.05.label | 05 Compare checksums | 05 Comparer les sommes |
| verify_locally.print.card.05.title | Compare checksums | Comparer les sommes |
| verify_locally.print.card.06.body | Each signed edition is frozen in /integrity/releases/. No mutable assets. | Chaque édition signée est figée dans /integrity/releases/. Aucun actif mutable. |
| verify_locally.print.card.06.label | 06 Reproducibility notes | 06 Notes de reproductibilité |
| verify_locally.print.card.06.title | Reproducibility notes | Notes de reproductibilité |
| verify_locally.print.doc_title | Trent Power - Verify Locally | Trent Power - Vérifier localement |
| verify_locally.print.footer.edition | Edition 2026-05-19 · trentpower.fr/integrity/verify-locally/ | Édition 2026-05-19 · trentpower.fr/integrity/verify-locally/ |
| verify_locally.print.footer.proof | Private · Static · Signed · No tracking | Privé · Statique · Signé · Sans suivi |
| verify_locally.print.kicker | Integrity verification | Vérification d’intégrité |
| verify_locally.print.lede | Detached verification notes for independently checking the signed integrity manifest using the published public key. | Notes de vérification détachée pour contrôler indépendamment le manifeste d’intégrité signé avec la clé publique publiée. |
| verify_locally.print.meta | Edition 2026-05-19 · trentpower.fr/integrity/verify-locally/ | Édition 2026-05-19 · trentpower.fr/integrity/verify-locally/ |
| verify_locally.print.qr.label | trentpower.fr/integrity/verify-locally/ | trentpower.fr/integrity/verify-locally/ |
| verify_locally.print.title | Verify locally | Vérifier localement |

---

## Change-tracking appendix

Use this section to draft rewrites, log approval status, or capture editorial notes against any `KEY` in this document. Each row is a free-form workspace for the reviewer.

| Key | Proposed change | Reviewer | Status | Notes |
|---|---|---|---|---|
| _example.key_ |  |  | _draft / approved / dropped_ |  |

