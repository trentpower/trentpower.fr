# trentpower.fr — Editorial Copy Review — English only

**Edition** 2026-05-09  
**Asset version** `2026-05-09.e851de57`  
**Generated** 2026-05-17  
**Languages** English  
**Entries** 1040 total (0 also exist in four other languages — see the multilingual document)  

Master editorial copy file for trentpower.fr. Every public-facing string the site renders, organised by surface and section. Multilingual where the source supports it.

_A leaner review document for English-only copywriters. The full multilingual master remains at `editorial-copy-review.md` / `.html` / `.docx` / `.pdf`._

---

## Editorial principles

### Tone of voice

Calm, declarative, archival. The site speaks once, in a low confident register. Avoid marketing register, avoid hedging. Sentences should be complete and rhythmic, not punchy.

### Privacy-first posture

The site collects nothing and delivers no analytics, cookies, trackers, third-party requests, or external runtime. Copy that reinforces this — privacy page, security page, cite/verify overlays — should be precise and uncluttered. Never overclaim; describe.

### Architectural / editorial relationship

The site itself is part of the artefact. Copy is published, signed, and versioned alongside the code. A copy edit ships the same way a code change ships: through tools/i18n/strings.json into a build, then into a signed release. The deployed bytes are the canonical text.

---

## Part 01 · Global navigation and chrome

_69 entries._

_STRING · Cite & verify overlay · copied_  
`cite.copied`

#### Copied

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Cite & verify overlay · edition_label_  
`cite.edition_label`

#### Edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · hover_  
`cite.hover`

#### Copy citation

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Cite & verify overlay_  
`cite.label.action`

#### Cite & verify

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.close`

#### Close

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.copy_citation`

#### Copy citation

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.open_source`

#### View source

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.print_home`

#### Print profile

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.print_page`

#### Print profile

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.print_sheet`

#### Print profile

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.verify`

#### Verify this page

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.action.view_integrity`

#### View integrity record

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.footer_signed`

#### Edition {edition} · Signed SHA256

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Cite & verify overlay · overlay_  
`cite.overlay.kicker`

#### This page

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Cite & verify overlay · overlay_  
`cite.overlay.lede`

#### Canonical publication record.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.acknowledgments`

#### Security acknowledgements

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.forbidden`

#### Access not available

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.home`

#### Client Strategy & Growth Systems

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.integrity`

#### Integrity record

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.integrity-verify-locally`

#### Verify locally

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.maintenance`

#### Down for maintenance

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.not-found`

#### Page not found

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.privacy`

#### Privacy statement

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.release-archive`

#### Release archive · 2026-05-09

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.releases`

#### Release archive

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.security`

#### Security posture

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.server-error`

#### Temporary server error

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.source`

#### Source reader

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.source-reader`

#### Source reader

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.sw-reset`

#### Service worker reset

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Cite & verify overlay · overlay_  
`cite.overlay.page_title.verify`

#### Verify page

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Cite & verify overlay · overlay_  
`cite.overlay.toast.citation_copied`

#### Citation copied

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Cite & verify overlay · site_label_  
`cite.site_label`

#### Personal Site

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Copy-to-clipboard labels · command_  
`copy.command`

#### Copy command

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Copy-to-clipboard labels · copied_  
`copy.copied`

#### Copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Copy-to-clipboard labels · failed_  
`copy.failed`

#### Copy failed

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · lang_toggle_  
`footer.lang_toggle`

#### FR

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · location_  
`footer.location`

#### Paris, France

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · privacy_  
`footer.privacy`

#### Privacy

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.edition`

#### Edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.last_verified`

#### Verified

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.days`

#### {n} days ago

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.months`

#### {n} months ago

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.today`

#### today

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.years`

#### {n} years ago

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.relative.yesterday`

#### yesterday

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Global footer · proof_  
`footer.proof.sha_title`

#### View this page's entry in the signed integrity manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · proof_  
`footer.proof.signed`

#### SHA256

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · theme_  
`footer.theme.auto`

#### Auto

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · theme_  
`footer.theme.dark`

#### Dark

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · theme_  
`footer.theme.light`

#### Light

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Global footer · verify_  
`footer.verify`

#### Verify

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Modal overlay · close_  
`modal.close`

#### Close

> Aria-label for the modal close button.

<sub>source · `tools/i18n/strings.json`</sub>


_BUTTON · Modal overlay · cta_aria_  
`modal.cta_aria`

#### Request access by email

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Modal overlay · cta_label_  
`modal.cta_label`

#### Access by request

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Modal overlay · text_  
`modal.text`

#### This is a personal project. If you'd like to see it, I'd be happy to share access.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · heading_  
`trust_routes.heading`

#### Trust routes

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · integrity_desc_  
`trust_routes.integrity_desc`

#### How releases are signed

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Trust-chain route labels · integrity_label_  
`trust_routes.integrity_label`

#### Integrity

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · privacy_desc_  
`trust_routes.privacy_desc`

#### What this site does not collect

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Trust-chain route labels · privacy_label_  
`trust_routes.privacy_label`

#### Privacy

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · releases_desc_  
`trust_routes.releases_desc`

#### Frozen signed snapshots

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Trust-chain route labels · releases_label_  
`trust_routes.releases_label`

#### Releases

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · security_desc_  
`trust_routes.security_desc`

#### How the site is protected

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Trust-chain route labels · security_label_  
`trust_routes.security_label`

#### Security

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · source_desc_  
`trust_routes.source_desc`

#### Readable mirrors of public files

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Trust-chain route labels · source_label_  
`trust_routes.source_label`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Trust-chain route labels · verify_desc_  
`trust_routes.verify_desc`

#### How a page can be checked

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Trust-chain route labels · verify_label_  
`trust_routes.verify_label`

#### Verify

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 02 · Homepage

_54 entries._

_BODY · Homepage — Approach · adoption_body_  
`approach.adoption_body`

#### A strategy or technology only creates value when teams trust it and choose to use it. Trust must be earned, and utility must be proven. Client Advisors are first-line Clients and vital collaborators.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Approach · adoption_title_  
`approach.adoption_title`

#### Adoption matters more than tools

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Approach · ai_body_  
`approach.ai_body`

#### Authenticity is a human advantage, and it cannot be automated. Trust, empathy, and judgement are built in the moment through tone and presence. I use AI to remove friction so people can show up more relevant, more consistent and more human, at scale.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Approach · ai_title_  
`approach.ai_title`

#### AI should amplify human relationships

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Approach · clienteling_detail_  
`approach.clienteling_detail`

#### <dfn id="clienteling-definition" itemprop="name">Clienteling</dfn> <span itemprop="description">is a discipline. It is the practice of transforming what a Client Advisor knows into something a Client feels. The moment interactions become mechanical, it stops being Clienteling.</span>

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Approach · clienteling_title_  
`approach.clienteling_title`

#### Clienteling converts transaction into meaning

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Approach · governance_body_  
`approach.governance_body`

#### Clear ownership, cadence, and priorities create alignment, accelerate decisions, and enable scale.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Approach · governance_title_  
`approach.governance_title`

#### Governance creates momentum

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Approach · growth_body_  
`approach.growth_body`

#### Lasting growth follows when elegant systems are in place.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Approach · growth_title_  
`approach.growth_title`

#### Client growth takes discipline

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Approach_  
`approach.label`

#### Approach

> Section anchor label.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Approach · taste_body_  
`approach.taste_body`

#### Discernment, and cultural awareness shape interactions into something valuable and memorable.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Approach · taste_title_  
`approach.taste_title`

#### Taste is a strategic advantage

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Contact · email_aria_  
`contact.email_aria`

#### Email Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Contact_  
`contact.label`

#### Contact

> Section anchor label.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage hero_  
`hero.body`

#### I lead client strategy at Group level, focusing on the systems, governance, and ways of working that turn client relationships into long-term value. My work sits at the intersection of strategy, technology, and human relationships, with a focus on impact that scales and endures.

> Supporting paragraph. ~3–5 sentences, calm voice, no marketing register.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage hero · statement_  
`hero.statement`

#### Client strategy, <mark>growth systems</mark>, and cultural adoption at global scale.

> Primary identity statement. Keep declarative, restrained, one sentence.

<sub>source · `tools/i18n/strings.json`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.0`

#### Career chronology

> Screen-reader-only label or image alt text.

<sub>source · `public/index.html`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.1`

#### Site footer

> Screen-reader-only label or image alt text.

<sub>source · `public/index.html`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.2`

#### Footer

> Screen-reader-only label or image alt text.

<sub>source · `public/index.html`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.3`

#### Language

> Screen-reader-only label or image alt text.

<sub>source · `public/index.html`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.4`

#### Publication integrity

> Screen-reader-only label or image alt text.

<sub>source · `public/index.html`</sub>


_A11y · Accessibility text (aria / alt) · homepage_  
`home.aria.label.5`

#### Appearance

> Screen-reader-only label or image alt text.

<sub>source · `public/index.html`</sub>


_STRING · Homepage · trust_no_tracking_  
`home.trust_no_tracking`

#### no tracking

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage · trust_privacy_  
`home.trust_privacy`

#### privacy-first

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage · trust_signed_  
`home.trust_signed`

#### signed releases

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage · trust_static_  
`home.trust_static`

#### static

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Projects_  
`projects.label`

#### Projects

> Section anchor label.

<sub>source · `tools/i18n/strings.json`</sub>


_BUTTON · Homepage — Projects · paris_cta_  
`projects.paris_cta`

#### View project

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Projects · paris_desc_  
`projects.paris_desc`

#### A private cultural intelligence system for Paris, combining location, effort, editorial judgement and personal taste into a calmer way to decide what is worth leaving home for.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Projects · paris_preview_caption_  
`projects.paris_preview_caption`

#### A sample cultural intelligence selection for one week, one neighbourhood.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Projects · paris_preview_header_  
`projects.paris_preview_header`

#### This week near Jourdain, 20th

<sub>source · `tools/i18n/strings.json`</sub>


_SUBLINE · Homepage — Projects · paris_subline_  
`projects.paris_subline`

#### A personal experiment in taste systems, local relevance and human-scale recommendation.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Projects · tier_bike_  
`projects.tier_bike`

#### bike

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Projects · tier_metro_  
`projects.tier_metro`

#### metro

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Projects · tier_walk_  
`projects.tier_walk`

#### walk

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Trajectory · background_detail_  
`trajectory.background_detail`

#### Building online platforms and communities

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Trajectory · background_label_  
`trajectory.background_label`

#### Background

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · background_span_  
`trajectory.background_span`

#### 1997 — 2004

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Trajectory · background_title_  
`trajectory.background_title`

#### Web Entrepreneur

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Homepage — Trajectory · current_detail_  
`trajectory.current_detail`

#### Group-wide client strategy across Maisons and markets

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Trajectory · current_label_  
`trajectory.current_label`

#### Current

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · current_org_  
`trajectory.current_org`

#### <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr>

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · current_span_  
`trajectory.current_span`

#### 2023 — now

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Trajectory · current_title_  
`trajectory.current_title`

#### Group Director, Client Development & Client Relations

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Trajectory_  
`trajectory.label`

#### Trajectory

> Section anchor label.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Trajectory · maisons_label_  
`trajectory.maisons_label`

#### Maisons

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · maisons_org_  
`trajectory.maisons_org`

#### BVLGARI

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · maisons_span_  
`trajectory.maisons_span`

#### 2004 — 2017

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Trajectory · maisons_title_  
`trajectory.maisons_title`

#### Senior leadership across Clienteling, <abbr title="Customer Relationship Management">CRM</abbr> & Retail

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Homepage — Trajectory · previous_label_  
`trajectory.previous_label`

#### Previous

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · previous_org_  
`trajectory.previous_org`

#### <abbr title="Louis Vuitton Moët Hennessy">LVMH</abbr>

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Homepage — Trajectory · previous_span_  
`trajectory.previous_span`

#### 2017 — 2023

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Homepage — Trajectory · previous_title_  
`trajectory.previous_title`

#### Group Head of Clienteling

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 03 · Print profile

_47 entries._

_STRING · Print profile · arch_  
`print.arch.archive`

#### Archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · arch_  
`print.arch.browser`

#### Browser

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · arch_  
`print.arch.cache`

#### Offline Cache

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · arch_  
`print.arch.caption`

#### Static, privacy-first, signed and inspectable

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · arch_  
`print.arch.files`

#### Site Files

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · arch_  
`print.arch.host`

#### Static Host

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · arch_  
`print.arch.trust`

#### Trust

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile_  
`print.body`

#### I lead client strategy at Group level, focusing on the systems, governance and ways of working that turn client relationships into long-term value. My work sits at the intersection of strategy, technology and human relationships, with a focus on impact that scales and endures.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · contact_  
`print.contact.linkedin`

#### LinkedIn · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · credentials_  
`print.credentials.exec_detail`

#### Ongoing senior-level learning across artificial intelligence, consumer behaviour, organisational transformation, and leadership coaching.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · credentials_  
`print.credentials.exec_title`

#### Selective executive education

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · credentials_  
`print.credentials.label`

#### Credentials

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · credentials_  
`print.credentials.sydney_detail`

#### Master’s degree, 2009.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · credentials_  
`print.credentials.sydney_title`

#### University of Sydney

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · doc_title_  
`print.doc_title`

#### Trent Power - Client Strategy Executive Profile

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · focus_  
`print.focus.01.body`

#### Lasting growth follows when strong systems are in place.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · focus_  
`print.focus.01.label`

#### 01 Focus

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · focus_  
`print.focus.01.title`

#### Client growth takes discipline

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · focus_  
`print.focus.02.body`

#### Technology creates value when teams trust it, choose it and use it.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · focus_  
`print.focus.02.label`

#### 02 Adoption

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · focus_  
`print.focus.02.title`

#### Adoption matters more than tools

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · focus_  
`print.focus.03.body`

#### Authenticity remains a human advantage; automation must strengthen context, memory and care.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · focus_  
`print.focus.03.label`

#### 03 Human relationships

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · focus_  
`print.focus.03.title`

#### AI should amplify human relationships

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · focus_  
`print.focus.04.body`

#### Clear ownership and disciplined priorities create alignment and scale.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · focus_  
`print.focus.04.label`

#### 04 Governance

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · focus_  
`print.focus.04.title`

#### Governance creates momentum

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · footer_  
`print.footer.citation`

#### Trent Power. Personal Site. Paris, France.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · footer_  
`print.footer.edition`

#### Edition <time datetime="2026-05-09">2026-05-09</time> · https://trentpower.fr/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · footer_  
`print.footer.evidence`

#### Public record · HTML · Edition 9 May 2026

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · footer_  
`print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Print profile_  
`print.kicker`

#### trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · name_  
`print.name`

#### Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · place_  
`print.place`

#### Personal Site · Paris, France

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · project_  
`print.project.body`

#### A private cultural intelligence system for Paris, combining location, effort, editorial judgement and personal taste into a calmer way to decide what is worth leaving home for.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · project_  
`print.project.label`

#### Proof point

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · project_  
`print.project.note`

#### A personal experiment in taste systems, local relevance and human-scale recommendation.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile · project_  
`print.project.title`

#### What’s On in Paris

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Print profile · role_  
`print.role`

#### Client strategy, growth systems and cultural adoption

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Print profile_  
`print.title`

#### Client strategy, growth systems and cultural adoption at global scale

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · trajectory_  
`print.trajectory.background.body`

#### Early digital and entrepreneurial work building online platforms and communities

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.background.label`

#### Background

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · trajectory_  
`print.trajectory.current.body`

#### Group Director, Client Development & Client Relations · LVMH

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.current.label`

#### Current

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.label`

#### Trajectory

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Print profile · trajectory_  
`print.trajectory.previous.body`

#### Senior leadership across Clienteling, CRM and Client Development

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Print profile · trajectory_  
`print.trajectory.previous.label`

#### Previous

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 04 · Privacy

_32 entries._

_BODY · Privacy page · body_detail_  
`privacy.body_detail`

#### External links are ordinary references. They are contacted only if you choose to open them. The only browser storage used is a local language preference. It stays on your device and is never transmitted.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · body_intro_  
`privacy.body_intro`

#### No tracking, analytics, cookies, profiling, embedded third-party services, or third-party requests while you browse. No personal data is collected for analytics, advertising, or profiling. Any limited technical data the server processes is used only to keep the site secure and operating correctly.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · body_records_  
`privacy.body_records`

#### Public inspection and verification records are published separately. You can read the <a href="/security/" aria-describedby="desc-security-threat-model">Security & threat model</a> for the full posture.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Privacy page · page_h1_  
`privacy.page_h1`

#### <span class="hero-line">Nothing tracked.</span><span class="hero-line">Nothing to delete.</span>

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Privacy page · page_kicker_  
`privacy.page_kicker`

#### Privacy & Trust

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · page_title_  
`privacy.page_title`

#### Privacy & Trust

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.01.body`

#### No analytics. No cookies. No profiling. No third-party requests while browsing.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.01.label`

#### 01 No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.01.title`

#### No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.02.body`

#### No public forms. No visitor accounts. No behavioural tracking. No advertising infrastructure.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.02.label`

#### 02 No data collection

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.02.title`

#### No data collection

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.03.body`

#### Integrity page. Security page. Public manifest. Source view.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.03.label`

#### 03 Verification route

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.03.title`

#### Verification route

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.04.body`

#### Privacy is not a compliance layer. It is part of the site’s editorial and professional posture.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.04.label`

#### 04 Design principle

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.04.title`

#### Privacy as posture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.05.body`

#### View source. Read /integrity.json. Verify the signature. Inspect the security headers.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.05.label`

#### 05 What you can check

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.05.title`

#### What you can check

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.card.06.body`

#### trent@trentpower.fr · canonical route trentpower.fr/privacy/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.card.06.label`

#### 06 Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.card.06.title`

#### Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.doc_title`

#### Trent Power - Privacy Trust Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Privacy page · print_  
`privacy.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/privacy/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Privacy page · print_  
`privacy.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Privacy page · print_  
`privacy.print.kicker`

#### Privacy & Trust

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Privacy page · print_  
`privacy.print.lede`

#### This site is intentionally simple and privacy-respectful. It uses no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Privacy page · print_  
`privacy.print.meta`

#### Edition 2026-05-09 · trentpower.fr/privacy/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Privacy page · print_  
`privacy.print.qr.label`

#### trentpower.fr/privacy/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Privacy page · print_  
`privacy.print.title`

#### Privacy-first by design

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 05 · Integrity & Releases

_122 entries._

_BODY · Integrity page · body_intro_  
`integrity.body_intro`

#### Every public file is hashed and listed in a manifest, signed with a detached <abbr title="Pretty Good Privacy">PGP</abbr> signature so each release can be checked against the publisher's key - independently, on your own machine, without trust in this server. You can <a href="/integrity/verify-locally/" aria-describedby="desc-verify-locally">verify locally here</a>.

<sub>source · `tools/i18n/strings.json`</sub>


_BUTTON · Integrity page · copy_button_  
`integrity.copy_button`

#### Copy

<sub>source · `tools/i18n/strings.json`</sub>


_BUTTON · Integrity page · copy_button_done_  
`integrity.copy_button_done`

#### Copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · file_integrity_  
`integrity.file_integrity`

#### /integrity.json · SHA-256 hashes of all public assets

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · file_key_  
`integrity.file_key`

#### /.well-known/pgp-key.asc · public signing key

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · file_sig_  
`integrity.file_sig`

#### /integrity.json.sig · detached PGP signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · fingerprint_copied_  
`integrity.fingerprint_copied`

#### Copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · fingerprint_copy_  
`integrity.fingerprint_copy`

#### Copy fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · page_h1_  
`integrity.page_h1`

#### <span class="hero-line">Signed.</span><span class="hero-line">Verifiable.</span><span class="hero-line">Reproducible.</span>

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Integrity page · page_kicker_  
`integrity.page_kicker`

#### Integrity

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · page_title_  
`integrity.page_title`

#### Integrity

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.01.body`

#### <code>/integrity.json</code> - <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> hashes of every intentional public file.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.01.label`

#### 01 Manifest

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.01.title`

#### Manifest

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.02.body`

#### /integrity.json.sig - detached <abbr title="Pretty Good Privacy">PGP</abbr> signature that verifies the manifest.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.02.label`

#### 02 Signature

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.02.title`

#### Detached signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.03.body`

#### /.well-known/pgp-key.asc - fingerprint A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.03.label`

#### 03 Public key

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.03.title`

#### Public key

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.04.body`

#### /integrity/releases/ - public snapshots: February 2026 and May 2026.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.04.label`

#### 04 Releases

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.04.title`

#### Frozen releases

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.05.body`

#### /source/ - public text view of selected source files. No secrets, no private artefacts.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.05.label`

#### 05 Source route

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.05.title`

#### Source route

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.card.06.body`

#### curl -O trentpower.fr/integrity.json && curl -O trentpower.fr/integrity.json.sig && gpg --verify integrity.json.sig integrity.json

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.card.06.label`

#### 06 Verification

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.card.06.title`

#### Verification

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.doc_title`

#### Trent Power - Integrity Verification Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · print_  
`integrity.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/integrity/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · print_  
`integrity.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Integrity page · print_  
`integrity.print.kicker`

#### Integrity

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Integrity page · print_  
`integrity.print.lede`

#### Published files are listed in a public manifest and signed with a detached <abbr title="Pretty Good Privacy">PGP</abbr> signature so updates can be verified independently.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · print_  
`integrity.print.meta`

#### Edition 2026-05-09 · trentpower.fr/integrity/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · print_  
`integrity.print.qr.label`

#### trentpower.fr/integrity/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · print_  
`integrity.print.title`

#### Signed public verification

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.action.view_manifest`

#### View manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.action.view_releases`

#### View releases

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.archives`

#### Signed public source release

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.checksums`

#### Signed checksum list for archive downloads

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.manifest`

#### <abbr title="Secure Hash Algorithm, 256-bit">SHA-256</abbr> hashes of public files

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.public_key`

#### Public signing key

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.desc.signature`

#### Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.group.archives`

#### Source archives

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.group.fingerprint`

#### Release fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.group.verification`

#### Verification records

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Integrity page · record_  
`integrity.record.kicker`

#### Signed release

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.archives`

#### Archives

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.checksums`

#### Archive checksums

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.fingerprint`

#### Fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.manifest`

#### Manifest

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.public_key`

#### Public key

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Integrity page · record_  
`integrity.record.label.signature`

#### Detached signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · record_  
`integrity.record.status_short`

#### Manifest · Signature · Public key

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Integrity page · record_  
`integrity.record.title`

#### <time datetime="2026-05">May 2026</time>

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · verify_release_local_  
`integrity.verify_release_local.note`

#### Run the signed manifest check in a temporary keyring.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Integrity page · verify_release_local_  
`integrity.verify_release_local.summary`

#### Advanced local verification

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · aria_  
`releases.aria.actions_archive`

#### Release record

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · aria_  
`releases.aria.actions_current`

#### Current release downloads and verification

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · body_intro_  
`releases.body_intro`

#### Each <dfn id="signed-release">release</dfn> is a frozen, signed snapshot of the public site at the time of publication. Source archives can be downloaded, and checksums and signatures are provided for local verification.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sha`

#### SHA-256 checksum

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sig`

#### Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sums`

#### SHA-256 list for release archives

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.sums_sig`

#### Detached <abbr title="Pretty Good Privacy">PGP</abbr> signature over SHA256SUMS

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.targz`

#### Technical preservation archive

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.desc.zip`

#### Portable public source snapshot

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.kicker`

#### Release files

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.sums`

#### Checksum list

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.sums_sig`

#### Checksum list signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.targz`

#### TAR.GZ

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.targz_sha`

#### TAR.GZ checksum

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.targz_sig`

#### TAR.GZ signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.zip`

#### ZIP

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.zip_sha`

#### ZIP checksum

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.label.zip_sig`

#### ZIP signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.card.status`

#### ZIP · TAR.GZ · Checksums · Signatures

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · detail_  
`releases.detail.card.title`

#### 9 May 2026

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.intro`

#### Signed release archives for the 9 May 2026 edition. A signed checksum list verifies the archive set; checksums verify the downloaded files; detached signatures verify each archive directly. The signed manifest at /integrity.json remains the live-site authority.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · detail_  
`releases.detail.note`

#### Archive binaries are not included in /integrity.json to avoid recursive hashing. They are verified separately through the signed checksum list, individual SHA-256 checksums and detached signatures. <a href="/integrity/">Integrity</a> remains the live-site authority.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · detail_  
`releases.detail.page_title`

#### May 2026

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · download_checksums_sig_  
`releases.download_checksums_sig`

#### Checksums & signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · download_targz_  
`releases.download_targz`

#### Download TAR.GZ

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · download_zip_  
`releases.download_zip`

#### Download ZIP

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_feb_  
`releases.edition_feb`

#### February 2026 · initial signed release

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_feb_date_  
`releases.edition_feb_date`

#### February 2026

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_feb_desc_  
`releases.edition_feb_desc`

#### <cite>Initial signed release</cite>

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_feb_meta_  
`releases.edition_feb_meta`

#### Signed snapshot · Initial release

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_may09_date_  
`releases.edition_may09_date`

#### 9 May 2026

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_may09_desc_  
`releases.edition_may09_desc`

#### <cite>Final May edition</cite>

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · edition_may09_meta_  
`releases.edition_may09_meta`

#### Signed snapshot · Current release

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · editions_heading_  
`releases.editions_heading`

#### Editions

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · group_  
`releases.group.archive`

#### Archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · group_  
`releases.group.current`

#### Current release

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · page_title_  
`releases.page_title`

#### Releases

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.card.01.body`

#### Final May edition. Signed source archives, deterministic ZIP and TAR.GZ, aggregated SHA256SUMS. Clean active filenames. One-page print profile. Trust sheets.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.card.01.label`

#### 01 9 May 2026

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.card.01.title`

#### 9 May 2026

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.card.02.body`

#### Initial signed release. Earlier visual system. Preserved as a historical archive.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.card.02.label`

#### 02 February 2026

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.card.02.title`

#### February 2026

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.card.03.body`

#### Frozen assets. Local CSS and fonts. No live mutable style dependency.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.card.03.label`

#### 03 Archive principle

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.card.03.title`

#### Archive principle

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.card.04.body`

#### /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.card.04.label`

#### 04 Integrity route

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.card.04.title`

#### Integrity route

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.card.05.body`

#### Verifiability. Authorship. Continuity. Public trust.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.card.05.label`

#### 05 Why it matters

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.card.05.title`

#### Why it matters

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.card.06.body`

#### /integrity/releases/2026-05-09/ · /integrity/releases/2026-02/ · /source/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.card.06.label`

#### 06 Where to inspect

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.card.06.title`

#### Where to inspect

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.doc_title`

#### Trent Power - Release Archive Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · print_  
`releases.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/integrity/releases/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · print_  
`releases.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Releases index · print_  
`releases.print.kicker`

#### Releases

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Releases index · print_  
`releases.print.lede`

#### Public release snapshots preserve selected editions of the site with local assets so their design and integrity can be inspected over time.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · print_  
`releases.print.meta`

#### Edition 2026-05-09 · trentpower.fr/integrity/releases/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Releases index · print_  
`releases.print.qr.label`

#### trentpower.fr/integrity/releases/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Releases index · print_  
`releases.print.title`

#### Frozen public editions

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Releases index · view_release_  
`releases.view_release`

#### View release

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 06 · Security & Acknowledgements

_110 entries._

_BODY · Security acknowledgements · body_intro_  
`acknowledgments.body_intro`

#### This page records responsible security disclosures that have been verified and resolved.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security acknowledgements · integrity_link_  
`acknowledgments.integrity_link`

#### Site integrity statement

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security acknowledgements · none_  
`acknowledgments.none`

#### There are no acknowledgements at present. This reflects the absence of reportable disclosures to date, not the absence of review or maintenance.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · page_title_  
`acknowledgments.page_title`

#### Security acknowledgements

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.01.body`

#### Coordinated, time-bounded, with credit on request.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.01.label`

#### 01 Disclosure model

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.01.title`

#### Disclosure model

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.02.body`

#### trent@trentpower.fr · PGP-signed reports preferred · public key at /.well-known/pgp-key.asc.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.02.label`

#### 02 Reporting policy

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.02.title`

#### Reporting policy

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.03.body`

#### Acknowledge within 72 hours. Patch, verify, publish notes if material.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.03.label`

#### 03 Coordinated remediation

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.03.title`

#### Coordinated remediation

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.04.body`

#### Reproduce, hash, sign, and record in the next signed release.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.04.label`

#### 04 Verification process

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.04.title`

#### Verification process

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.05.body`

#### trent@trentpower.fr · fingerprint A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.05.label`

#### 05 Security contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.05.title`

#### Security contact

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.card.06.body`

#### Acknowledgement page is the canonical record; updates accompany each signed edition.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.card.06.label`

#### 06 Publication status

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.card.06.title`

#### Publication status

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.doc_title`

#### Trent Power - Security Acknowledgments

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security acknowledgements · print_  
`acknowledgments.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/security/acknowledgments/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security acknowledgements · print_  
`acknowledgments.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Security acknowledgements · print_  
`acknowledgments.print.kicker`

#### Security acknowledgments

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security acknowledgements · print_  
`acknowledgments.print.lede`

#### Acknowledgements for individuals and researchers who contributed responsibly to the security posture of this site.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security acknowledgements · print_  
`acknowledgments.print.meta`

#### Edition 2026-05-09 · trentpower.fr/security/acknowledgments/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security acknowledgements · print_  
`acknowledgments.print.qr.label`

#### trentpower.fr/security/acknowledgments/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security acknowledgements · print_  
`acknowledgments.print.title`

#### Responsible disclosure record

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security acknowledgements · report_  
`acknowledgments.report`

#### If you believe you have found a security issue with this site, please report it responsibly. Contact details and disclosure preferences are listed in security.txt.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.archive_body`

#### Frozen signed releases

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.archive_label`

#### Archive

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.browser_body`

#### <abbr title="HyperText Transfer Protocol Secure">HTTPS</abbr> · no cookies · no analytics

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.browser_label`

#### Browser

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.cache_body`

#### Service worker · local cache after first visit

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.cache_label`

#### Offline cache

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.files_body`

#### <abbr title="HyperText Markup Language">HTML</abbr> · <abbr title="Cascading Style Sheets">CSS</abbr> · vanilla JS · self-hosted fonts

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.files_label`

#### Site files

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.host_body`

#### Apache · Gandi · Paris · <abbr title="Secure File Transfer Protocol">SFTP</abbr> deployment

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.host_label`

#### Static host

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Security page · architecture_card_  
`security.architecture_card.kicker`

#### Architecture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · architecture_card_  
`security.architecture_card.trust_body`

#### Integrity · Verify · Source · Releases

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · architecture_card_  
`security.architecture_card.trust_label`

#### Trust

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · body_intro_  
`security.body_intro`

#### How this site is hosted, what it protects, what it doesn't - and how anyone can verify it independently.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · page_h1_  
`security.page_h1`

#### <span class="hero-line">Static.</span><span class="hero-line">Self-managed.</span><span class="hero-line">Verification-led.</span>

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Security page · page_kicker_  
`security.page_kicker`

#### Security & Threat Model

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · page_title_  
`security.page_title`

#### Security & Threat Model

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.card.01.body`

#### Static HTML, CSS, vanilla JavaScript. Self-managed deployment on Apache (Gandi, Paris). No public database.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.card.01.label`

#### 01 Architecture

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.card.01.title`

#### Architecture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.card.02.body`

#### <abbr title="Content Security Policy">CSP</abbr> default-deny. <abbr title="HTTP Strict Transport Security">HSTS</abbr>. <abbr title="Cross-Origin Opener Policy">COOP</abbr> / <abbr title="Cross-Origin Embedder Policy">COEP</abbr> / <abbr title="Cross-Origin Resource Policy">CORP</abbr>. Referrer-Policy no-referrer. Locked-down Permissions-Policy.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.card.02.label`

#### 02 Headers

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.card.02.title`

#### Security headers

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.card.03.body`

#### Identity. Published content. Public verification files. Source integrity.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.card.03.label`

#### 03 Assets protected

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.card.03.title`

#### Assets protected

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.card.04.body`

#### Content injection. Hosting credential compromise. Spoofed identity. Stale or tampered files.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.card.04.label`

#### 04 Threat model

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.card.04.title`

#### Threat model

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.card.05.body`

#### No third-party scripts. No public forms. Signed integrity manifest. Restricted file exposure. Service-worker-controlled cache.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.card.05.label`

#### 05 Controls

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.card.05.title`

#### Controls

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.card.06.body`

#### Hosting and registrar risk remain. Static-site exposure is reduced, not eliminated. Responsible disclosure route is published.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.card.06.label`

#### 06 Residual risk

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.card.06.title`

#### Residual risk

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.doc_title`

#### Trent Power - Security Threat Model Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · print_  
`security.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/security/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · print_  
`security.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Security page · print_  
`security.print.kicker`

#### Security & Threat Model

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · print_  
`security.print.lede`

#### The public site is static HTML, CSS and vanilla JavaScript, with strict headers, no runtime server logic, no public database and no third-party scripts.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · print_  
`security.print.meta`

#### Edition 2026-05-09 · trentpower.fr/security/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Security page · print_  
`security.print.qr.label`

#### trentpower.fr/security/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Security page · print_  
`security.print.title`

#### Static, self-managed, verification-led

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · public_verification_footer_  
`security.public_verification_footer`

#### These routes support inspection and provenance. They do not remove the need to protect <abbr title="Domain Name System">DNS</abbr>, hosting credentials and the private signing key.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · public_verification_intro_  
`security.public_verification_intro`

#### The site exposes public inspection routes so published content can be checked without private infrastructure access.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · public_verification_list_  
`security.public_verification_list`

#### <a href="/integrity/" aria-label="Open the integrity archive for signed releases, public key and manifest"><code>/integrity/</code></a> records signed releases, public key and manifest <a href="/verify/" aria-label="Open the page verification tool for canonical URLs, source mirrors and fingerprints"><code>/verify/</code></a> records one page’s canonical <abbr title="Uniform Resource Locator">URL</abbr>, source mirror and fingerprint <a href="/source/" aria-label="Open readable source mirrors of selected public files"><code>/source/</code></a> publishes readable mirrors of selected public files <a href="/integrity/releases/" aria-label="Open frozen signed release snapshots"><code>/integrity/releases/</code></a> preserves frozen signed snapshots

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · public_verification_summary_  
`security.public_verification_summary`

#### 5. Public verification surface

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s1_routes_note_  
`security.s1_routes_note`

#### Public inspection routes expose the signed manifest, page records, readable source mirrors and archived releases without exposing private infrastructure.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s1_summary_  
`security.s1_summary`

#### 1. Architecture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · s2_body_  
`security.s2_body`

#### The controls described here protect:

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s2_list_  
`security.s2_list`

#### Domain ownership DNS integrity Hosting account integrity Public content integrity The signing key used for release authenticity

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s2_summary_  
`security.s2_summary`

#### 2. Assets protected

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_admin_heading_  
`security.s3_admin_heading`

#### Administrative abuse

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_admin_list_  
`security.s3_admin_list`

#### Credential stuffing Automated vulnerability scanning

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_content_heading_  
`security.s3_content_heading`

#### Content tampering

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_content_list_  
`security.s3_content_list`

#### Post-deployment file modification Malicious JavaScript injection Silent alteration of static assets

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_infra_heading_  
`security.s3_infra_heading`

#### Infrastructure compromise

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_infra_list_  
`security.s3_infra_list`

#### Registrar account takeover <abbr title="Domain Name System">DNS</abbr> hijack Hosting credential compromise

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · s3_noise_body_  
`security.s3_noise_body`

#### Continuous automated probing for common <abbr title="Content Management System">CMS</abbr> paths, configuration files, or known endpoints. These are treated as persistent background conditions rather than exceptional events.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_noise_heading_  
`security.s3_noise_heading`

#### Commodity internet noise

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s3_summary_  
`security.s3_summary`

#### 3. Threat model

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_content_heading_  
`security.s4_content_heading`

#### Public content

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_content_list_  
`security.s4_content_list`

#### Static architecture reduces server-side attack surface Strict <abbr title="Content Security Policy">CSP</abbr> starting from <code>default-src 'none'</code> No external resource loading No dynamic script execution

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_hosting_heading_  
`security.s4_hosting_heading`

#### Hosting

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_hosting_list_  
`security.s4_hosting_list`

#### Multi-factor authentication enabled <abbr title="Secure File Transfer Protocol">SFTP</abbr>-only deployment No <abbr title="Secure Shell">SSH</abbr> shell exposure No scheduled background execution

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_monitoring_heading_  
`security.s4_monitoring_heading`

#### Monitoring

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_monitoring_list_  
`security.s4_monitoring_list`

#### Structured log analysis Pattern detection and anomaly scoring File integrity drift detection against the signed release baseline

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_registrar_heading_  
`security.s4_registrar_heading`

#### Registrar &amp; <abbr title="Domain Name System">DNS</abbr>

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_registrar_list_  
`security.s4_registrar_list`

#### <abbr title="Multi-Factor Authentication">MFA</abbr> enabled Registrar lock active <abbr title="Domain Name System Security Extensions">DNSSEC</abbr> enabled and validated <abbr title="Certificate Authority Authorization">CAA</abbr> records restrict certificate issuance

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s4_summary_  
`security.s4_summary`

#### 4. Controls

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s6_footer_  
`security.s6_footer`

#### The main risks remain domain, <abbr title="Domain Name System">DNS</abbr>, hosting and private key compromise.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s6_intro_  
`security.s6_intro`

#### This model does not attempt to address:

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s6_list_  
`security.s6_list`

#### Physical compromise of hosting infrastructure Global <abbr title="Domain Name System">DNS</abbr> root compromise Certificate authority (<abbr title="Certificate Authority">CA</abbr>) compromise State-level adversaries Zero-day browser exploits on client devices

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s6_protect_summary_  
`security.s6_protect_summary`

#### This model protects the public static site. It does not protect against registrar compromise, hosting compromise, client-device compromise or private key compromise.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s6_summary_  
`security.s6_summary`

#### 6. Residual risk

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Security page · s7_body_  
`security.s7_body`

#### Responsible disclosure is welcome. Security contact details and encrypted communication instructions are published at <a href="/.well-known/security.txt" aria-describedby="desc-security-contact"><code>/.well-known/security.txt</code></a>.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s7_summary_  
`security.s7_summary`

#### 7. Disclosure

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s8_list_  
`security.s8_list`

#### Simplicity over complexity Deterministic behaviour over dynamic systems Transparency over obscurity Verifiable integrity over trust assumptions

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Security page · s8_summary_  
`security.s8_summary`

#### 8. Design principles

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 07 · Source & Verification

_190 entries._

_STRING · Source page · col_  
`source.col.validated`

#### Verified

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · curation_note_  
`source.curation_note`

#### This index shows the principal public mirrors. Additional mirrored files may remain available by direct URL where they support verification, recovery, or release integrity.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · download_checksums_  
`source.download_checksums`

#### Checksums

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · download_lede_  
`source.download_lede`

#### Download the public source archive for the current edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · download_targz_  
`source.download_targz`

#### TAR.GZ

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · download_zip_  
`source.download_zip`

#### ZIP

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · editions_  
`source.editions.eyebrow`

#### Editions

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · editions_  
`source.editions.note.current`

#### Current signed release

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · editions_  
`source.editions.note.earlier`

#### Earlier signed release

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · editions_  
`source.editions.title`

#### Edition lineage

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.403_html_txt.description`

#### Forbidden page.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.404_html_txt.description`

#### Not found page.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.500_html_txt.description`

#### Server error page.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.ai_usage_txt_txt.description`

#### Statement of AI usage and policy for the site.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.app_enhance_js_txt.description`

#### Progressive enhancement layer. Non-essential interactions, gracefully optional.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.app_js_txt.description`

#### Authored runtime script. Navigation, language switch, citation drawer wiring.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.assertion_txt_txt.description`

#### Authorship assertion. Declaration of authorship and integrity intent.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.attestations_json_txt.description`

#### Public attestations. Verifiable claims about the site.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.changelog_txt_txt.description`

#### Edition change log. Notable revisions to the public site.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.cite_js_txt.description`

#### Cite-and-verify drawer. Surfaces canonical URL, page fingerprint and signature.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.fonts_full_css_txt.description`

#### Webfont declarations. Subsets, formats and fallbacks.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.htaccess_txt.description`

#### Apache configuration. Public-safety scanned before mirroring.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.humans_txt_txt.description`

#### Credits and notes for the people behind the site.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_core_js_txt.description`

#### Editorial translation source. All five languages in one authored JSON.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_de_js_txt.description`

#### German translations.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_es_js_txt.description`

#### Spanish translations.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.i18n_it_js_txt.description`

#### Italian translations. Deployed compact bytes.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.index_html_txt.description`

#### Home page. The editorial entry point.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_index_html_txt.description`

#### Integrity overview. The signed manifest, key and release authority.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_releases_2026_05_09_index_html_txt.description`

#### Frozen page record for the 2026-05-09 edition.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_releases_archive_css_txt.description`

#### Stylesheet used inside frozen release archives. Held alongside its release records.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.integrity_releases_index_html_txt.description`

#### Release index. The list of signed editions.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.llms_txt_txt.description`

#### Machine-readable guidance for language models and AI systems.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.maintenance_html_txt.description`

#### Maintenance notice. Used during planned downtime.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.manifest_webmanifest_txt.description`

#### Web app manifest. Installable surface metadata.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.pgp_txt_txt.description`

#### PGP statement. The signing key fingerprint and its use.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.print_css_txt.description`

#### Print stylesheet. Layout rules for paper output.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.privacy_index_html_txt.description`

#### Privacy statement. What is collected, retained and shared.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.readme_txt.description`

#### Orientation note for the source tree. Same text shipped at the root of every release archive.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.robots_txt_txt.description`

#### Crawler access policy and public indexing intent.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.security_acknowledgments_index_html_txt.description`

#### Acknowledgments for public security disclosures.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.security_index_html_txt.description`

#### Security posture. Architecture, headers and disclosure path.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.site_metadata_json_txt.description`

#### Site-level metadata. Edition, build, asset version.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sitemap_xml_sha256_txt.description`

#### Source mirror of the SHA-256 checksum for sitemap.xml.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sitemap_xml_txt.description`

#### Public sitemap. URL inventory for crawlers.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.source_manifest_json_txt.description`

#### Manifest of the /source/ tree itself. Every mirrored file with its hash.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.statement_txt_txt.description`

#### Editorial statement. The site's authoring principles.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.styles_css_txt.description`

#### Authored stylesheet. Mirrored from source, not the minified deployed bytes.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sw_cache_manifest_json_txt.description`

#### Service worker cache manifest. Files pinned for offline use.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sw_js_txt.description`

#### Service worker. Offline cache for the public site.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.sw_reset_index_html_txt.description`

#### Service worker reset. Clears the offline cache.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.verify_index_html_txt.description`

#### Verification interface. Page-level fingerprint checks.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.verify_verify_js_txt.description`

#### Verification logic. Renders a page record from the verification map.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_attribution_txt_txt.description`

#### Author attribution. Names the responsible party for the public site.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_build_json_txt.description`

#### Build record. Reproducibility data for the current edition.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_person_json_txt.description`

#### Machine-readable identity in JSON-LD. The reference used by discovery, federation and verification.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · files_  
`source.files.well_known_person_json_txt.role`

#### Canonical identity record

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_pgp_key_asc_txt.description`

#### ASCII-armoured public signing key. The publisher's signing identity.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_publication_json_txt.description`

#### Publication record. Describes the site as a self-managed editorial work.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_security_txt_txt.description`

#### Coordinated disclosure policy. Standard /.well-known/security.txt contact and scope.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · files_  
`source.files.well_known_security_txt_txt.role`

#### Public trust surface

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Source page · files_  
`source.files.well_known_webfinger_txt.description`

#### WebFinger discovery surface. Resolves identity across federated protocols.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · files_  
`source.files.well_known_webfinger_txt.role`

#### Identity discovery

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_  
`source.group.metadata`

#### Metadata

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_  
`source.group.published-pages`

#### Published pages

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_  
`source.group.scripts`

#### Scripts

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_  
`source.group.trust-records`

#### Trust records

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.metadata`

#### Server configuration and machine-readable records describing the site to crawlers, indexers and language models.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.published-pages`

#### Readable mirrors of the principal public pages, served as plain text so the bytes can be inspected without execution.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.scripts`

#### Authored stylesheets and JavaScript the page ships to the browser. Mirrored from source, not the minified deployed bytes.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · group_gloss_  
`source.group_gloss.trust-records`

#### Public commitments and identity surfaces. Who publishes the site, what is promised, where disclosure runs.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · heading_  
`source.heading`

#### <span class="hero-line">Every public byte,</span><span class="hero-line">in plain text.</span>

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · intro_lede_  
`source.intro_lede`

#### Selected public files, published in readable form. For inspection, preservation, and machine readability.

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Source page · page_kicker_  
`source.page_kicker`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.card.01.body`

#### HTML mirrors. CSS. JavaScript. Manifest files. .htaccess mirror.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.card.01.label`

#### 01 What is included

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.card.01.title`

#### What is included

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.card.02.body`

#### Credentials. Private notes. Invoices. Backups. Generator internals unless explicitly public.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.card.02.label`

#### 02 What is excluded

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.card.02.title`

#### What is excluded

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.card.03.body`

#### Sorted by file type, then name. Plain text mirrors. SHA-256 hashes. File sizes.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.card.03.label`

#### 03 How it is organised

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.card.03.title`

#### How it is organised

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.card.04.body`

#### source-manifest.json · /integrity.json · detached signature · public key.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.card.04.label`

#### 04 Verification

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.card.04.title`

#### Verification

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.card.05.body`

#### styles.css.txt · app.js.txt · print.css.txt · htaccess.txt · source-manifest.json

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.card.05.label`

#### 05 Files of note

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.card.05.title`

#### Files of note

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.card.06.body`

#### Human readers first. Machine-readable files preserve identity, authorship and context.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.card.06.label`

#### 06 Principle

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.card.06.title`

#### Principle

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.doc_title`

#### Trent Power - Public Source Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · print_  
`source.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/source/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · print_  
`source.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Source page · print_  
`source.print.kicker`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Source page · print_  
`source.print.lede`

#### Selected public files are mirrored as plain text so the site can be inspected from any reader, including mobile.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Source page · print_  
`source.print.meta`

#### Edition 2026-05-09 · trentpower.fr/source/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Source page · print_  
`source.print.qr.label`

#### trentpower.fr/source/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Source page · print_  
`source.print.title`

#### Public source view

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copied`

#### Copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copy_canonical`

#### Copy URL

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copy_command`

#### Copy verification command

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copy_fingerprint`

#### Copy fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copy_hash`

#### Copy hash

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copy_manifest_command`

#### Copy manifest command

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.copy_source_command`

#### Copy source command

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.open_key`

#### Open public key

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.open_manifest`

#### Open manifest entry

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.open_signature`

#### Open signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.open_source`

#### Open source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.open_source_mirror`

#### Open mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.view_source_code`

#### View source code

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · action_  
`verify.action.view_source_mirror`

#### View source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · chooser_  
`verify.chooser.heading`

#### Related records

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.home`

#### Homepage

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.integrity`

#### Integrity

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.privacy`

#### Privacy

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.releases`

#### Releases

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.security`

#### Security

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.source`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · chooser_  
`verify.chooser.label.verify`

#### Verify

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · command_  
`verify.command.manifest_title`

#### Verify the signed manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · command_  
`verify.command.note`

#### The signed manifest verifies the published file set. The second command hashes the source mirror so it can be compared against the expected SHA-256 above.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · command_  
`verify.command.source_title`

#### Verify the source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · doc_title_  
`verify.doc_title`

#### Trent Power - Verification Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · general_  
`verify.general.releases`

#### Release archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · general_  
`verify.general.source`

#### Source viewer

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Verify page_  
`verify.kicker`

#### Verify

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Verify page · lede_  
`verify.lede`

#### A public route for checking source, hash, signature and canonical identity.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Verify page · lede_v2_  
`verify.lede_v2`

#### Check a published page against its canonical location, source mirror, page fingerprint and signed release archive.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.closing`

#### The signed manifest verifies the published file set. The source command hashes this page's mirror so it can be compared against the fingerprint above.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.heading`

#### Verify locally

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.intro`

#### Run two local checks: verify the signed manifest, then compare this page's source mirror against the expected fingerprint.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.manifest_desc`

#### Checks that /integrity.json was signed by the published public key.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · local_  
`verify.local.manifest_label`

#### Verify the signed manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.mirror_desc`

#### Calculates the source mirror fingerprint so it can be compared with the expected value above.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify page · local_  
`verify.local.mirror_label`

#### Verify this page mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.subheading_manifest`

#### Verify signed manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · local_  
`verify.local.subheading_mirror`

#### Verify source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · meta_  
`verify.meta`

#### Edition 2026-05-09 · trentpower.fr/verify/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · noscript_fallback_  
`verify.noscript_fallback`

#### JavaScript is required to select and display a page record here. Source mirrors, the signed manifest and release archives remain available through <a href="/source/">Source</a> and <a href="/integrity/">Integrity</a>.

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Verify page · page_kicker_  
`verify.page_kicker`

#### Verify page

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · selected_  
`verify.selected.manifest`

#### Integrity manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · selected_  
`verify.selected.public_key`

#### Public key

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · selected_  
`verify.selected.signature`

#### Detached signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · status_  
`verify.status.found`

#### Found in signed manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · status_  
`verify.status.missing`

#### Not found in current public manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.archive`

#### Release archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.citation`

#### Citation

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.evidence`

#### Source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.fingerprint`

#### Page fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.group.location`

#### Canonical location

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.heading`

#### This page

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Verify page · thispage_  
`verify.thispage.kicker`

#### Page record

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.canonical`

#### Canonical URL

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.citation`

#### Citation

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.file`

#### File

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.file_size`

#### File size

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.file_type`

#### File type

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.manifest_status`

#### Manifest status

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.release`

#### Release archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.route`

#### Route

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.route_prefix`

#### Route

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.sha256`

#### Page fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.source`

#### Source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · thispage_  
`verify.thispage.row.title`

#### Page title

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.row.validated`

#### Last verified

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.found_manifest`

#### Found in signed manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.release_archived`

#### Release archived

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.short.archived`

#### Archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.short.signed`

#### Signed

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.short.source`

#### Mirrored

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.status.source_available`

#### Source available

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · thispage_  
`verify.thispage.validated_prefix`

#### Verified

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page_  
`verify.title`

#### Verify this page

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · title_default_  
`verify.title_default`

#### <span class="hero-line">Check page against code, size &amp; signature</span>

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · title_prefix_  
`verify.title_prefix`

#### Verify

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · unknown_  
`verify.unknown.action.manifest`

#### Integrity manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · unknown_  
`verify.unknown.action.releases`

#### Release archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify page · unknown_  
`verify.unknown.action.source`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Verify page · unknown_  
`verify.unknown.body`

#### This route is not in the public verification map. You can still inspect the public manifest, source view and signed releases.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Verify page · unknown_  
`verify.unknown.title`

#### Route not in the verification map

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify — current edition panel · archive_  
`verify_intro.archive`

#### Edition archive

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify — current edition panel · edition_  
`verify_intro.edition`

#### Edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify — current edition panel · manifest_  
`verify_intro.manifest`

#### Signed manifest

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Verify — current edition panel · panel_label_  
`verify_intro.panel_label`

#### Current edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify — current edition panel · public_key_  
`verify_intro.public_key`

#### Public key

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify — current edition panel · signature_  
`verify_intro.signature`

#### Detached signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Verify — current edition panel · signing_key_  
`verify_intro.signing_key`

#### Signing key

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 08 · Recovery surfaces

_166 entries._

_BODY · Generic error · 403_  
`error.403.print.card.01.body`

#### Some paths are intentionally unavailable. Private, backup and operational files are blocked.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.01.label`

#### 01 Access boundary

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.01.title`

#### Access boundary

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.02.body`

#### Homepage. Privacy & Trust. Integrity. Security. Source.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.02.label`

#### 02 Public routes

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.02.title`

#### Public routes

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.03.body`

#### Reduces accidental exposure. Keeps public files intentional. Supports privacy and trust posture.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.03.label`

#### 03 Why this matters

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.03.title`

#### Why this matters

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.04.body`

#### Inspect /integrity.json. View selected source files. Check /.well-known/security.txt.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.04.label`

#### 04 Verification

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.04.title`

#### Verification

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.05.body`

#### No public database. No visitor accounts. No forms. No tracking.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.05.label`

#### 05 Static posture

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.05.title`

#### Static posture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 403_  
`error.403.print.card.06.body`

#### trent@trentpower.fr · responsible disclosure via /security/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.card.06.label`

#### 06 Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.card.06.title`

#### Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.doc_title`

#### Trent Power - Access Boundary Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 403_  
`error.403.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 403_  
`error.403.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Generic error · 403_  
`error.403.print.kicker`

#### 403

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 403_  
`error.403.print.lede`

#### This path is not publicly accessible. The public site exposes only intentional files and pages.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 403_  
`error.403.print.meta`

#### Edition 2026-05-09 · trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 403_  
`error.403.print.qr.label`

#### trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 403_  
`error.403.print.title`

#### Access not available

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.01.body`

#### The requested route does not resolve to a public page. The site remains available through the homepage.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.01.label`

#### 01 What happened

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.01.title`

#### What happened

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.02.body`

#### Homepage. Privacy & Trust. Integrity. Security.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.02.label`

#### 02 Where to go

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.02.title`

#### Where to go

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.03.body`

#### Public manifest. Source view. Signed releases.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.03.label`

#### 03 Verification

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.03.title`

#### Verification

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.04.body`

#### Check the URL. Remove outdated path fragments. Try the canonical homepage.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.04.label`

#### 04 If this was expected

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.04.title`

#### If expected

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.05.body`

#### Static site. No tracking. No forms. No third-party scripts.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.05.label`

#### 05 Public posture

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.05.title`

#### Public posture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.card.06.body`

#### trent@trentpower.fr · LinkedIn · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.card.06.label`

#### 06 Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.card.06.title`

#### Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.doc_title`

#### Trent Power - Page Not Found Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 404_  
`error.404.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 404_  
`error.404.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Generic error · 404_  
`error.404.print.kicker`

#### 404

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 404_  
`error.404.print.lede`

#### The address may have changed, or the page may no longer be part of the public site.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 404_  
`error.404.print.meta`

#### Edition 2026-05-09 · trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 404_  
`error.404.print.qr.label`

#### trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 404_  
`error.404.print.title`

#### Page not found

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.01.body`

#### The server could not complete the request. Try again shortly.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.01.label`

#### 01 What happened

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.01.title`

#### What happened

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.02.body`

#### Homepage. Integrity. Security. Source.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.02.label`

#### 02 Stable routes

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.02.title`

#### Stable routes

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.03.body`

#### /integrity.json · /integrity.json.sig · /.well-known/pgp-key.asc

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.03.label`

#### 03 Public verification

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.03.title`

#### Public verification

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.04.body`

#### Static HTML, CSS and JavaScript. No runtime public application. No public database.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.04.label`

#### 04 Architecture

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.04.title`

#### Architecture

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.05.body`

#### Refresh later. Return to homepage. Contact if persistent.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.05.label`

#### 05 What to do

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.05.title`

#### What to do

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.card.06.body`

#### trent@trentpower.fr · LinkedIn · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.card.06.label`

#### 06 Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.card.06.title`

#### Contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.doc_title`

#### Trent Power - Temporary Server Error Sheet

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 500_  
`error.500.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 500_  
`error.500.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Generic error · 500_  
`error.500.print.kicker`

#### 500

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Generic error · 500_  
`error.500.print.lede`

#### Something unexpected happened while serving this page. The public site is static, so this is likely a hosting or routing issue rather than an application failure.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Generic error · 500_  
`error.500.print.meta`

#### Edition 2026-05-09 · trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Generic error · 500_  
`error.500.print.qr.label`

#### trentpower.fr

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Generic error · 500_  
`error.500.print.title`

#### Temporary server error

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · 404 page_  
`error_404.body`

#### The page you’re looking for doesn’t exist or has moved.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · 404 page · page_title_  
`error_404.page_title`

#### Page not found

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · 500 page_  
`error_500.body`

#### The server encountered an error. Try again shortly, or return to the homepage.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · 500 page · page_title_  
`error_500.page_title`

#### Something went wrong

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page_  
`maintenance.body`

#### The signed manifest, source mirrors and frozen release archives remain available throughout maintenance. Verification continues to work.

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Maintenance page_  
`maintenance.kicker`

#### Maintenance

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · lede_  
`maintenance.lede`

#### We're doing some work here. Check back shortly, or return to the homepage.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · page_title_  
`maintenance.page_title`

#### Down for maintenance

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.01.body`

#### A signed release or infrastructure update is in progress.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.01.label`

#### 01 Deployment state

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.01.title`

#### Deployment state

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.02.body`

#### The previous signed edition remains downloadable in /integrity/releases/.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.02.label`

#### 02 Integrity preservation

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.02.title`

#### Integrity preservation

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.03.body`

#### Service returns automatically when the new edition is signed and verified.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.03.label`

#### 03 Public availability

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.03.title`

#### Public availability

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.04.body`

#### Archived editions stay reachable independently of this maintenance window.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.04.label`

#### 04 Signed releases

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.04.title`

#### Signed releases

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.05.body`

#### trent@trentpower.fr - for inquiries during extended unavailability.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.05.label`

#### 05 Maintenance contact

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.05.title`

#### Maintenance contact

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.card.06.body`

#### Canonical URLs are preserved across editions; bookmarks remain valid.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.card.06.label`

#### 06 Expected continuity

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.card.06.title`

#### Expected continuity

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.doc_title`

#### Trent Power - Maintenance

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Maintenance page · print_  
`maintenance.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/maintenance.html

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Maintenance page · print_  
`maintenance.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Maintenance page · print_  
`maintenance.print.kicker`

#### Maintenance status

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Maintenance page · print_  
`maintenance.print.lede`

#### This site is temporarily unavailable while a new signed edition or infrastructure update is being deployed.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Maintenance page · print_  
`maintenance.print.meta`

#### Edition 2026-05-09 · trentpower.fr/maintenance.html

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Maintenance page · print_  
`maintenance.print.qr.label`

#### trentpower.fr/maintenance.html

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page · print_  
`maintenance.print.title`

#### Temporary maintenance mode

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Maintenance page_  
`maintenance.title`

#### Down for maintenance

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · api_label_  
`sw_reset.api_label`

#### APIs

<sub>source · `tools/i18n/strings.json`</sub>


_BUTTON · Service Worker reset page_  
`sw_reset.button`

#### Reset local offline cache

<sub>source · `tools/i18n/strings.json`</sub>


_BUTTON · Service Worker reset page · button_done_  
`sw_reset.button_done`

#### Reset complete

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · card_state_  
`sw_reset.card_state`

#### Offline cache

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · card_state_cleared_  
`sw_reset.card_state_cleared`

#### Offline cache cleared

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · clear_caches_  
`sw_reset.clear_caches`

#### Offline cache entries

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · clear_pref_  
`sw_reset.clear_pref`

#### Saved language preference

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · clear_sw_  
`sw_reset.clear_sw`

#### Service Worker registrations

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · clears_heading_  
`sw_reset.clears_heading`

#### Clears

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · detected_label_  
`sw_reset.detected_label`

#### Detected

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · edition_label_  
`sw_reset.edition_label`

#### Cached edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · edition_none_  
`sw_reset.edition_none`

#### No cached edition detected

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · footnote_  
`sw_reset.footnote`

#### Offline state is stored locally through the browser Cache Storage and Service Worker APIs.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · lede_  
`sw_reset.lede`

#### Clears the local offline cache for this device only. The live publication and server are unaffected.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · link_home_  
`sw_reset.link_home`

#### Home

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · link_reload_  
`sw_reset.link_reload`

#### Reload current edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · local_marker_  
`sw_reset.local_marker`

#### LOCAL DEVICE ONLY

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · page_title_  
`sw_reset.page_title`

#### Service Worker Reset

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · preserve_downloads_  
`sw_reset.preserve_downloads`

#### Downloads

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · preserve_history_  
`sw_reset.preserve_history`

#### Browser history

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · preserve_others_  
`sw_reset.preserve_others`

#### Other websites

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · preserve_server_  
`sw_reset.preserve_server`

#### Server content

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · preserves_heading_  
`sw_reset.preserves_heading`

#### Does not clear

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.01.body`

#### Unregisters the service worker and deletes every named cache for this origin.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.01.label`

#### 01 Cache removal

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.01.title`

#### Cache removal

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.02.body`

#### Used when a stale offline copy is serving an outdated signed edition.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.02.label`

#### 02 Offline recovery

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.02.title`

#### Offline recovery

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.03.body`

#### Next page load fetches fresh HTML, CSS, JS, fonts, and integrity files.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.03.label`

#### 03 Signed release refresh

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.03.title`

#### Signed release refresh

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.04.body`

#### Works in any browser that supports Service Workers and the Cache API.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.04.label`

#### 04 Browser compatibility

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.04.title`

#### Browser compatibility

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.05.body`

#### Integrity manifest and signature remain unchanged - only cached copies are evicted.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.05.label`

#### 05 Verification continuity

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.05.title`

#### Verification continuity

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.card.06.body`

#### Clears the cached language preference. Theme preference is preserved.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.card.06.label`

#### 06 Local state reset

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.card.06.title`

#### Local state reset

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.doc_title`

#### Trent Power - Service Worker Reset

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · print_  
`sw_reset.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/sw-reset/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · print_  
`sw_reset.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · Service Worker reset page · print_  
`sw_reset.print.kicker`

#### Offline recovery

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · Service Worker reset page · print_  
`sw_reset.print.lede`

#### Recovery utility for clearing cached offline state and refreshing the current signed public release.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · print_  
`sw_reset.print.meta`

#### Edition 2026-05-09 · trentpower.fr/sw-reset/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · print_  
`sw_reset.print.qr.label`

#### trentpower.fr/sw-reset/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Service Worker reset page · print_  
`sw_reset.print.title`

#### Service worker reset

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · scope_heading_  
`sw_reset.scope_heading`

#### Scope

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · secondary_  
`sw_reset.secondary`

#### If a recent edition is not appearing correctly, this utility refreshes the local publication cache.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · Service Worker reset page · status_initial_  
`sw_reset.status_initial`

#### Reading local state…

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · Service Worker reset page · status_label_  
`sw_reset.status_label`

#### Local cache status

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 09 · Metadata (titles · descriptions · Open Graph)

_28 entries._

_DESCRIPTION · Page metadata (titles, descriptions, OG) · 403_  
`meta.403.description`

#### Access not permitted.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · 403_  
`meta.403.title`

#### Forbidden · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · 404_  
`meta.404.description`

#### Page not found.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · 404_  
`meta.404.title`

#### Page not found · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · 500_  
`meta.500.description`

#### Something went wrong.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · 500_  
`meta.500.title`

#### Something went wrong · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · acknowledgments_  
`meta.acknowledgments.description`

#### Responsible security disclosures verified and resolved for trentpower.fr.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · acknowledgments_  
`meta.acknowledgments.title`

#### Security acknowledgements · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · home_  
`meta.home.description`

#### Client strategy, growth systems and cultural adoption at global scale

> 150–160 chars. Search snippet and Open Graph fallback.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · home_  
`meta.home.og_description`

#### Client strategy, growth systems and cultural adoption at global scale

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · home_  
`meta.home.og_title`

#### Client Strategy & Growth Systems · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · home_  
`meta.home.title`

#### Client Strategy & Growth Systems · Trent Power

> Browser tab title and search-result heading. Keep concise; this is the brand line.

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · integrity_  
`meta.integrity.description`

#### Signed public releases, integrity manifest, detached signature and public signing key

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · integrity_  
`meta.integrity.title`

#### Integrity · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · maintenance_  
`meta.maintenance.description`

#### Down for maintenance.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · maintenance_  
`meta.maintenance.title`

#### Down for maintenance · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · privacy_  
`meta.privacy.description`

#### A simple, privacy-respectful site with no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · privacy_  
`meta.privacy.title`

#### Privacy & Trust · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · releases_  
`meta.releases.description`

#### Frozen, signed snapshots of the public site

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · releases_  
`meta.releases.title`

#### Releases · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · security_  
`meta.security.description`

#### Security architecture, operational controls, public verification surfaces and residual risks

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · security_  
`meta.security.title`

#### Security & Threat Model · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · source_  
`meta.source.description`

#### Readable public mirrors of selected site files

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · source_  
`meta.source.title`

#### Source mirrors · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · verify_  
`meta.verify.description`

#### A public page record showing the canonical URL, source mirror, page fingerprint and signed release archive

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · verify_  
`meta.verify.title`

#### Verify this page · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


_DESCRIPTION · Page metadata (titles, descriptions, OG) · verify_locally_  
`meta.verify_locally.description`

#### Detached verification notes: signed manifest check from a temporary keyring

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · Page metadata (titles, descriptions, OG) · verify_locally_  
`meta.verify_locally.title`

#### Verify locally · Trent Power

<sub>source · `tools/i18n/strings.json`</sub>


---

## Part 10 · Structured data (Schema.org)

_33 entries._

_Schema · Structured data (Schema.org) · 403_  
`jsonld.403.WebPage.description`

#### Access not available.

> WebPage node for /403/.

<sub>source · `public/403.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · 403_  
`jsonld.403.WebPage.name`

#### 403 — access not available · Trent Power

> WebPage node for /403/.

<sub>source · `public/403.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · 404_  
`jsonld.404.WebPage.description`

#### Page not found.

> WebPage node for /404/.

<sub>source · `public/404.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · 404_  
`jsonld.404.WebPage.name`

#### 404 — page not found · Trent Power

> WebPage node for /404/.

<sub>source · `public/404.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · 500_  
`jsonld.500.WebPage.description`

#### Temporary server error.

> WebPage node for /500/.

<sub>source · `public/500.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · 500_  
`jsonld.500.WebPage.name`

#### 500 — temporary server error · Trent Power

> WebPage node for /500/.

<sub>source · `public/500.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.DefinedTerm.description`

#### Clienteling is a discipline. It is the practice of transforming what a Client Advisor knows into something a Client feels. The moment interactions become mechanical, it stops being Clienteling.

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.DefinedTerm.name`

#### Clienteling

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.description`

#### Client strategy, growth systems and cultural adoption at global scale

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.disambiguatingDescription`

#### Client strategy, growth systems and cultural adoption at global scale

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.image.copyrightNotice`

#### © David Arous

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.image.creditText`

#### David Arous

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.jobTitle`

#### Group Director, Client Development & Client Relations

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.Person.name`

#### Trent Power

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.ProfilePage.name`

#### Trent Power — Profile

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.WebSite.description`

#### Client strategy, growth systems and cultural adoption at global scale

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · homepage_  
`jsonld.home.WebSite.name`

#### Trent Power

> Surfaces in search engine rich results and AI assistants.

<sub>source · `public/index.html (JSON-LD @graph)`</sub>


_Schema · Structured data (Schema.org) · integrity_  
`jsonld.integrity.WebPage.description`

#### Signed public releases, integrity manifest, detached signature and public signing key

> WebPage node for /integrity/.

<sub>source · `public/integrity/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · integrity_  
`jsonld.integrity.WebPage.name`

#### Integrity · Trent Power

> WebPage node for /integrity/.

<sub>source · `public/integrity/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · maintenance_  
`jsonld.maintenance.WebPage.description`

#### Down for maintenance.

> WebPage node for /maintenance/.

<sub>source · `public/maintenance.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · maintenance_  
`jsonld.maintenance.WebPage.name`

#### Maintenance · Trent Power

> WebPage node for /maintenance/.

<sub>source · `public/maintenance.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · privacy_  
`jsonld.privacy.WebPage.description`

#### A simple, privacy-respectful site with no tracking, analytics, cookies, profiling, or embedded third-party requests while you browse

> WebPage node for /privacy/.

<sub>source · `public/privacy/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · privacy_  
`jsonld.privacy.WebPage.name`

#### Privacy · Trent Power

> WebPage node for /privacy/.

<sub>source · `public/privacy/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · security_  
`jsonld.security.WebPage.description`

#### Security architecture, operational controls, public verification surfaces and residual risks

> WebPage node for /security/.

<sub>source · `public/security/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · security_  
`jsonld.security.WebPage.name`

#### Security · Trent Power

> WebPage node for /security/.

<sub>source · `public/security/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · security_acknowledgments_  
`jsonld.security_acknowledgments.WebPage.description`

#### Responsible security disclosures verified and resolved for trentpower.fr.

> WebPage node for /security_acknowledgments/.

<sub>source · `public/security/acknowledgments/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · security_acknowledgments_  
`jsonld.security_acknowledgments.WebPage.name`

#### Security acknowledgements · Trent Power

> WebPage node for /security_acknowledgments/.

<sub>source · `public/security/acknowledgments/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · source_  
`jsonld.source.TechArticle.description`

#### Public source mirrors. Plain-text inspection of every active publishable byte.

> WebPage node for /source/.

<sub>source · `public/source/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · source_  
`jsonld.source.TechArticle.headline`

#### Source · Trent Power

> WebPage node for /source/.

<sub>source · `public/source/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · sw_reset_  
`jsonld.sw_reset.WebPage.description`

#### Local recovery utility. Clears the offline cache for trentpower.fr on this device only.

> WebPage node for /sw_reset/.

<sub>source · `public/sw-reset/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · sw_reset_  
`jsonld.sw_reset.WebPage.name`

#### Service Worker Reset · Trent Power

> WebPage node for /sw_reset/.

<sub>source · `public/sw-reset/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · verify_  
`jsonld.verify.WebPage.description`

#### Per-page verification - check source mirror, signed manifest hash, and detached signature for any active route.

> WebPage node for /verify/.

<sub>source · `public/verify/index.html (JSON-LD)`</sub>


_Schema · Structured data (Schema.org) · verify_  
`jsonld.verify.WebPage.name`

#### Verify · Trent Power

> WebPage node for /verify/.

<sub>source · `public/verify/index.html (JSON-LD)`</sub>


---

## Part 11 · Other strings

_189 entries._

_BODY · credentials · exec_detail_  
`credentials.exec_detail`

#### Ongoing senior-level learning across artificial intelligence, consumer behaviour, organisational transformation, and leadership coaching.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · credentials · exec_title_  
`credentials.exec_title`

#### Selective executive education

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · credentials_  
`credentials.label`

#### Credentials

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · credentials · sydney_detail_  
`credentials.sydney_detail`

#### Master’s degree, 2009.

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · credentials · sydney_title_  
`credentials.sydney_title`

#### University of Sydney

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · checksums_  
`linkdesc.checksums`

#### Download the SHA-256 checksums for the signed release archives

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · cite_  
`linkdesc.cite`

#### Open citation and verification details for this page

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · email_  
`linkdesc.email`

#### Contact Trent Power by email

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · home_  
`linkdesc.home`

#### Return to the homepage

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · integrity_  
`linkdesc.integrity`

#### Open the public integrity record, including hashes, signatures, and release verification

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · lang_en_  
`linkdesc.lang_en`

#### Read this site in English

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · lang_fr_  
`linkdesc.lang_fr`

#### Lire ce site en français

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · linkedin_  
`linkdesc.linkedin`

#### Open Trent Power’s LinkedIn profile in a new tab without sending referrer data

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · manifest_  
`linkdesc.manifest`

#### Download the signed integrity manifest (JSON listing every public file and its SHA-256)

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · now_  
`linkdesc.now`

#### Read what Trent Power is currently focused on

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · privacy_  
`linkdesc.privacy`

#### Read how this site avoids analytics, cookies, profiling, tracking, and third-party assets

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · public_key_  
`linkdesc.public_key`

#### Download the public PGP key used to sign releases

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · security_contact_  
`linkdesc.security_contact`

#### Read the security.txt disclosure policy for this site

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · security_threat_model_  
`linkdesc.security_threat_model`

#### Read the security architecture and threat model for this site

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · signature_  
`linkdesc.signature`

#### Download the detached PGP signature for the integrity manifest

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · source_  
`linkdesc.source`

#### View the public source mirror of this site, with readable annotations and line references

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · targz_  
`linkdesc.targz`

#### Download the source archive as a TAR.GZ file

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · theme_auto_  
`linkdesc.theme_auto`

#### Match the system appearance setting

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · theme_dark_  
`linkdesc.theme_dark`

#### Switch to the dark appearance

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · theme_light_  
`linkdesc.theme_light`

#### Switch to the light appearance

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · verify_  
`linkdesc.verify`

#### Check the current page against the published integrity data

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · verify_locally_  
`linkdesc.verify_locally`

#### Read the instructions to verify the publication locally with command-line tools

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · linkdesc · zip_  
`linkdesc.zip`

#### Download the source archive as a ZIP file

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.01.body`

#### /integrity.json - SHA-256 hashes of every intentional public file at edition time.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.01.label`

#### 01 Manifest

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.01.title`

#### Manifest

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.02.body`

#### /integrity.json.sig - PGP detached signature over the manifest.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.02.label`

#### 02 Detached signature

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.02.title`

#### Detached signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.03.body`

#### /integrity/releases/2026-05-09/SHA256SUMS - sums for ZIP and TAR.GZ.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.03.label`

#### 03 Archive checksums

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.03.title`

#### Archive checksums

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.04.body`

#### trentpower-fr-2026-05-09.zip · trentpower-fr-2026-05-09.tar.gz - deterministic.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.04.label`

#### 04 Source archive

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.04.title`

#### Source archive

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.05.body`

#### gpg --verify integrity.json.sig integrity.json against the public key.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.05.label`

#### 05 Verification status

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.05.title`

#### Verification status

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.card.06.body`

#### Signed by A729 591B 450D 3F59 3694 98BD 8299 1F25 04AE 0263.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.card.06.label`

#### 06 Release fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.card.06.title`

#### Release fingerprint

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.doc_title`

#### Trent Power - Release Archive 2026-05-09

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · release_archive · print_  
`release_archive.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/integrity/releases/2026-05-09/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · release_archive · print_  
`release_archive.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · release_archive · print_  
`release_archive.print.kicker`

#### Signed release archive

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · release_archive · print_  
`release_archive.print.lede`

#### Public release archive for the May 2026 signed edition, including manifests, checksums, detached signatures, and reproducible source records.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · release_archive · print_  
`release_archive.print.meta`

#### Edition 2026-05-09 · trentpower.fr/integrity/releases/2026-05-09/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · release_archive · print_  
`release_archive.print.qr.label`

#### trentpower.fr/integrity/releases/2026-05-09/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · release_archive · print_  
`release_archive.print.title`

#### Edition 2026-05-09

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.back_to_top`

#### Top

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.canonical`

#### Canonical

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.clear`

#### Clear

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.copied`

#### Copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy`

#### Copy

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy_code`

#### Copy code

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.copy_link`

#### Copy link

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.count_line_one`

#### 1 line

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.count_lines_many`

#### {n} lines

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.line_selected`

#### Line {n} selected

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.lines_copied`

#### {n} lines copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.link_copied`

#### Link copied

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.link_copied_normalised`

#### Link copied — normalised to lines {start} to {end}

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.plain_text`

#### Raw

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.range_selected`

#### Lines {start} to {end} selected

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.reading_mode`

#### Reading mode

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.selection_cleared`

#### Selection cleared

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.top`

#### Top

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.unwrap_lines`

#### Unwrap lines

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.verify`

#### Verify

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.view_annotated`

#### Annotated

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.view_rendered_page`

#### View rendered page

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.view_source`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · action_  
`source_reader.action.wrap_lines`

#### Wrap lines

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · end_  
`source_reader.end.edition`

#### Edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · end_  
`source_reader.end.sha256`

#### SHA-256

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · end_  
`source_reader.end.signed_release`

#### Signed release

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · source_reader · end_  
`source_reader.end.title`

#### End of source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.assets`

#### stylesheets, scripts, icons, manifest.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.base`

#### reset and base element typography.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.components`

#### reusable component styles.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.copy`

#### clipboard interactions.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.discovery`

#### indexing and referrer policy.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.document`

#### page title, description, canonical url.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.events`

#### event listeners and interaction wiring.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.fonts`

#### font face declarations and font assets.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.footer`

#### colophon, language switch, footer actions.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.foundations`

#### character encoding, viewport, colour scheme.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.head`

#### document head — metadata, no rendered content.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.header`

#### site header — wordmark and primary nav.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.i18n`

#### translation lookup and language switching.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.icons`

#### platform icons and home-screen artwork.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.identity`

#### authorship, application name, attribution links.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.init`

#### boot sequence — runs once on load.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.layout`

#### page-level layout grammar.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.modals`

#### overlay surfaces, dialogs, focus traps.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.policy`

#### declared site policies.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.print`

#### print stylesheet rules.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.records`

#### editorial record entries.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.responsive`

#### viewport-aware overrides.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.script`

#### site application logic.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.social`

#### open graph and twitter card metadata.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.state`

#### application state and runtime variables.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.structured`

#### json-ld schema, machine-readable identity.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.tokens`

#### design tokens — colours, typography, spacing.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · gloss_  
`source_reader.gloss.verification`

#### signed-manifest and cryptographic references.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.canonical`

#### Canonical file

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.edition`

#### Edition

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.sha256`

#### SHA-256

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · integrity_  
`source_reader.integrity.signed_release`

#### Signed release

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.apache`

#### Apache configuration

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.asc`

#### ASCII-armoured PGP key

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.css`

#### Cascading Style Sheets

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.html`

#### HyperText Markup Language

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.js`

#### JavaScript

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.json`

#### JavaScript Object Notation

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.sig`

#### Detached PGP signature

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.text`

#### Plain text

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · kind_  
`source_reader.kind.xml`

#### Extensible Markup Language

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · loading_  
`source_reader.loading`

#### Loading source…

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.assets`

#### Assets

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.base`

#### Base

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.components`

#### Components

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.copy`

#### Copy

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.discovery`

#### Discovery

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.events`

#### Events

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.fonts`

#### Fonts

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.footer`

#### Footer

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.head`

#### Head

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.header`

#### Header

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.i18n`

#### i18n

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.identity`

#### Identity

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.init`

#### Init

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.layout`

#### Layout

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.main`

#### Main

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.modals`

#### Modals

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.policy`

#### Policy

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.print`

#### Print

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.records`

#### Records

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.responsive`

#### Responsive

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.social_preview`

#### Social preview

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.state`

#### State

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.structured_data`

#### Structured data

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.tokens`

#### Tokens

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · map_label_  
`source_reader.map_label.verification`

#### Verification

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.document_map`

#### Document map

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.end_of_source`

#### End of source mirror

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.intent`

#### This reader presents public source mirrors with structural annotations and signed publication references.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.part_of`

#### Related systems:

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · meta_  
`source_reader.meta.validated`

#### Verified

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · mode_  
`source_reader.mode.annotated`

#### Annotated

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · source_reader · mode_  
`source_reader.mode.label`

#### Reading mode

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · mode_  
`source_reader.mode.raw`

#### Raw

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · source_reader · mode_  
`source_reader.mode.source`

#### Source

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · source_reader_  
`source_reader.title`

#### Source reader

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · body_close_  
`verify_locally.body_close`

#### The command imports the public key into a throw-away keyring, verifies the signed manifest, and removes the working files. No state is retained on the machine afterwards.

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · body_intro_  
`verify_locally.body_intro`

#### Detached verification notes for the signed integrity manifest. Run the check in a temporary keyring so the public signing key does not enter your default keychain.

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · verify_locally · page_kicker_  
`verify_locally.page_kicker`

#### Verify Locally

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · page_title_  
`verify_locally.page_title`

#### <span class="hero-line">Get to</span><span class="hero-line">the terminal!</span>

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.01.body`

#### Use a temp GNUPGHOME so the import does not touch your main keyring.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.01.label`

#### 01 Temporary keyring

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.01.title`

#### Temporary keyring

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.02.body`

#### curl /.well-known/pgp-key.asc · gpg --import pgp-key.asc.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.02.label`

#### 02 Import public key

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.02.title`

#### Import public key

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.03.body`

#### gpg --verify integrity.json.sig integrity.json - expect Good signature.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.03.label`

#### 03 Verify signature

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.03.title`

#### Verify signature

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.04.body`

#### /integrity.json lists every public file with its SHA-256.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.04.label`

#### 04 Check manifest

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.04.title`

#### Check manifest

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.05.body`

#### Re-hash any file and compare against the manifest entry.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.05.label`

#### 05 Compare checksums

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.05.title`

#### Compare checksums

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.card.06.body`

#### Each signed edition is frozen in /integrity/releases/. No mutable assets.

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.card.06.label`

#### 06 Reproducibility notes

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.card.06.title`

#### Reproducibility notes

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.doc_title`

#### Trent Power - Verify Locally

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · verify_locally · print_  
`verify_locally.print.footer.edition`

#### Edition 2026-05-09 · trentpower.fr/integrity/verify-locally/

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · verify_locally · print_  
`verify_locally.print.footer.proof`

#### Private · Static · Signed · No tracking

<sub>source · `tools/i18n/strings.json`</sub>


_KICKER · verify_locally · print_  
`verify_locally.print.kicker`

#### Integrity verification

<sub>source · `tools/i18n/strings.json`</sub>


_BODY · verify_locally · print_  
`verify_locally.print.lede`

#### Detached verification notes for independently checking the signed integrity manifest using the published public key.

<sub>source · `tools/i18n/strings.json`</sub>


_STRING · verify_locally · print_  
`verify_locally.print.meta`

#### Edition 2026-05-09 · trentpower.fr/integrity/verify-locally/

<sub>source · `tools/i18n/strings.json`</sub>


_LABEL · verify_locally · print_  
`verify_locally.print.qr.label`

#### trentpower.fr/integrity/verify-locally/

<sub>source · `tools/i18n/strings.json`</sub>


_TITLE · verify_locally · print_  
`verify_locally.print.title`

#### Verify locally

<sub>source · `tools/i18n/strings.json`</sub>


---

## Change-tracking appendix

Use this section to draft rewrites, log approval status, or capture editorial notes against any `KEY` in this document. Each row is a free-form workspace for the reviewer.

| Key | Proposed change | Reviewer | Status | Notes |
|---|---|---|---|---|
| _example.key_ |  |  | _draft / approved / dropped_ |  |

