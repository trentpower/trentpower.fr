trentpower.fr — public source archive
edition 2026-05-09

What This Is
------------
a frozen, signed snapshot of the public website at
https://trentpower.fr as it stood on 2026-05-09. static html,
css and vanilla javascript; no build step is required to read
or serve it.

How To Read
-----------
open index.html in any browser. or serve the directory with
any static server, e.g. `python3 -m http.server 8000`.

Verification
------------
see VERIFY.txt for the exact verification chain. every byte in
this archive is covered by either an inline signature or a hash
in SHA256SUMS.

What Is Not Included
--------------------
proprietary font binaries from klim type foundry are omitted;
their licence does not permit redistribution. pages render with
the declared css fallback stack. see FONT-LICENSE-NOTICE.txt
for details.

Source
------
Canonical Site:        https://trentpower.fr
Per-file Source View:  https://trentpower.fr/source/
Release Index:         https://trentpower.fr/integrity/releases/
Integrity Manifest:    https://trentpower.fr/integrity.json
Public Signing Key:    https://trentpower.fr/.well-known/pgp-key.asc

Licence
-------
site content © trent power. published for reading and study.
reuse of writing or imagery should preserve attribution. code
patterns may be referenced freely.
